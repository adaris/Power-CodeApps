/**
 * String identifier for a registered visual type (e.g., 'clusteredBarChart', 'lineChart').
 */
export type VisualType = string;
/**
 * Data role kind.
 */
export type DataRoleKind = 'Grouping' | 'Measure' | 'GroupingOrMeasure';
/**
 * Cartesian kind for axis-related data roles.
 */
export type CartesianKind = 'X' | 'Y';
/**
 * Describes a data role that a visual type supports.
 */
export interface DataRoleDescriptor {
    readonly name: string;
    readonly kind: DataRoleKind;
    readonly displayName: string;
    readonly displayOrder?: number;
    readonly description?: string;
    readonly isRequired?: boolean;
    readonly maxPerRole?: number;
    readonly cartesianKind?: CartesianKind;
    readonly joinPredicate?: number;
    readonly kindPreference?: number;
    readonly noDuplicates?: boolean;
    readonly preferDateColumn?: boolean;
    readonly disallowedWithVisualCalculations?: boolean;
    readonly supportsSparklines?: boolean;
    readonly preferredTypes?: readonly unknown[];
    readonly requiredTypes?: readonly unknown[];
}
/**
 * A single enum member value.
 */
export interface EnumMember {
    readonly value: string | number;
    readonly displayName?: string;
}
/**
 * A sub-property within the value object for an image-typed property.
 */
export interface ImageSubPropertyDescriptor {
    readonly type: 'expr';
    readonly required: boolean;
}
/**
 * Image-typed property metadata.
 */
export interface ImageTypeDescriptor {
    readonly subProperties?: Record<string, ImageSubPropertyDescriptor>;
}
/**
 * Property type descriptor from capabilities.json.
 * Common fields are typed explicitly; additional fields are
 * accessible via the index signature for forward compatibility.
 */
export interface PropertyTypeDescriptor {
    readonly bool?: boolean;
    readonly numeric?: boolean;
    readonly integer?: boolean;
    readonly dateTime?: boolean;
    readonly text?: boolean | {
        readonly richText?: boolean;
    };
    readonly fill?: {
        readonly solid?: {
            readonly color?: boolean | {
                readonly nullable?: boolean;
            };
        };
    };
    readonly fillRule?: Record<string, unknown>;
    readonly formatting?: Record<string, unknown>;
    readonly enumeration?: EnumMember[] | {
        readonly allMembers?: EnumMember[];
    };
    readonly flagsEnumeration?: Record<string, unknown>;
    readonly image?: ImageTypeDescriptor;
    readonly variant?: Record<string, unknown>;
    readonly variantDeleteEmpty?: Record<string, unknown>;
    readonly scripting?: Record<string, unknown>;
    readonly filter?: Record<string, unknown>;
    readonly expression?: Record<string, unknown>;
    readonly [key: string]: unknown;
}
/**
 * Property descriptor within a formatting object.
 */
export interface ObjectPropertyDescriptor {
    readonly displayName?: string;
    readonly description?: string;
    readonly placeHolderText?: string;
    readonly type?: PropertyTypeDescriptor;
}
/**
 * Describes a formatting object with its properties.
 */
export interface ObjectDescriptor {
    readonly displayName?: string;
    readonly description?: string;
    readonly properties: Record<string, ObjectPropertyDescriptor>;
}
/**
 * Map of objectName → array of selector instance IDs.
 * Example: `{ "dataPoint": ["default", "hover"], "fill": ["default"] }`
 */
export type VisualSelectorMap = Record<string, string[]>;
/**
 * Map of instance-selector key → object-name → selector instance IDs.
 *
 * The key is usually a visual type identifier (e.g. `actionButton`), but
 * can also be a non-visual element (e.g. `filterCard`) that exposes
 * state-keyed formatting buckets without being a visual.
 */
export type InstanceSelectorCatalog = Record<string, VisualSelectorMap>;
/**
 * Legacy alias for {@link InstanceSelectorCatalog}.
 *
 * @deprecated Prefer `InstanceSelectorCatalog`. The keys may be visuals
 *   or non-visual elements; the old name was misleading.
 */
export type InstanceSelectorsByVisualType = InstanceSelectorCatalog;
/**
 * Hint describing how a specific object is selected within a visual or
 * other instance-selector key.
 */
export interface SelectorHint {
    readonly objectName: string;
    readonly selectorIds: string[];
}
/**
 * Full capabilities for a visual type, as extracted by the
 * extract-visual-capabilities executor. Common fields are typed
 * explicitly; less-common behavioral flags are accessible via
 * the index signature.
 *
 * Note: instance selectors live in a separate catalog and are not
 * folded into this descriptor. See {@link InstanceSelectorCatalog}.
 */
export interface VisualCapabilities {
    readonly dataRoles?: readonly DataRoleDescriptor[];
    readonly objects?: Record<string, ObjectDescriptor>;
    readonly sharedCapabilitiesWith?: readonly string[];
    readonly dataViewMappings?: readonly unknown[];
    readonly sorting?: unknown;
    readonly drilldown?: unknown;
    readonly tooltips?: unknown;
    readonly annotationTemplates?: readonly unknown[];
    readonly suppressDefaultTitle?: boolean;
    readonly suppressDefaultPadding?: boolean;
    readonly supportsSelection?: boolean;
    readonly supportsVisualLink?: boolean;
    readonly supportsHighlight?: boolean;
    readonly supportsKeyboardFocus?: boolean;
    readonly supportsMultiVisualSelection?: boolean;
    readonly supportsOnObjectFormatting?: boolean;
    readonly supportsEmptyDataView?: boolean;
    readonly supportsLandingPage?: boolean;
    readonly supportsDataDrivenAlerts?: boolean;
    readonly disableFormatMode?: boolean;
    readonly disableFocusMode?: boolean;
    readonly ariaRole?: string;
    readonly [key: string]: unknown;
}
/**
 * Map of visual type identifier to its capabilities.
 */
export type CapabilitiesByVisualType = Record<string, VisualCapabilities>;
/**
 * String identifier for a registered VCO object name
 * (e.g., 'title', 'background', 'border').
 */
export type VcoKey = string;
/**
 * Property type for a VCO property.
 */
export interface VcoPropertyType {
    readonly bool?: boolean;
    readonly numeric?: boolean;
    readonly integer?: boolean;
    readonly text?: boolean | {
        readonly richText?: boolean;
    };
    readonly fill?: {
        readonly solid?: {
            readonly color?: boolean;
        };
    };
    readonly formatting?: Record<string, unknown>;
    readonly enumeration?: VcoEnumMember[] | {
        readonly allMembers?: VcoEnumMember[];
    };
}
/**
 * A single enum member value in a VCO property.
 */
export interface VcoEnumMember {
    readonly value: string | number;
    readonly displayName?: string;
}
/**
 * Describes a single property within a VCO object.
 */
export interface VcoProperty {
    readonly displayName?: string;
    readonly description?: string;
    readonly type?: VcoPropertyType;
}
/**
 * Full descriptor for a visual container object.
 */
export interface VcoCatalogEntry {
    readonly displayName?: string;
    readonly description?: string;
    readonly properties: Record<string, VcoProperty>;
}
/**
 * Map of VCO object name to its full catalog entry.
 */
export type VcoCatalog = Record<string, VcoCatalogEntry>;
