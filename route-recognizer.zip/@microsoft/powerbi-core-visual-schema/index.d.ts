export { listVisualTypes, getCapabilities } from './lib/visual-catalog.js';
export { listVcoKeys, getVcoCapabilities } from './lib/vco-catalog.js';
export { listInstanceSelectorKeys, getInstanceSelectors, getSelectorHints, } from './lib/instance-selectors.js';
export type { VisualType, DataRoleKind, CartesianKind, DataRoleDescriptor, EnumMember, ImageSubPropertyDescriptor, ImageTypeDescriptor, PropertyTypeDescriptor, ObjectPropertyDescriptor, ObjectDescriptor, VisualSelectorMap, SelectorHint, InstanceSelectorCatalog, InstanceSelectorsByVisualType, VisualCapabilities, CapabilitiesByVisualType, VcoKey, VcoCatalogEntry, VcoProperty, VcoPropertyType, VcoEnumMember, VcoCatalog, } from './types/index.js';
