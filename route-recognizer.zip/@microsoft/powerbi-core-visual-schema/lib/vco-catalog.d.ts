import type { VcoKey, VcoCatalogEntry } from '../types/index.js';
/**
 * Returns an array of all registered VCO object name keys.
 *
 * @example
 * ```ts
 * const keys = listVcoKeys();
 * // → ['title', 'subTitle', 'divider', 'background', 'border', 'dropShadow', ...]
 * ```
 */
export declare function listVcoKeys(): VcoKey[];
/**
 * Returns the full catalog entry for a given VCO object name,
 * including its display name, description, and all properties
 * with their type descriptors.
 *
 * Returns `undefined` if the object name is not registered.
 *
 * @example
 * ```ts
 * const title = getVcoCapabilities('title');
 * // → {
 * //     displayName: 'Title',
 * //     properties: {
 * //       show: { displayName: 'Show', type: { bool: true } },
 * //       text: { displayName: 'Title text', type: { text: true } },
 * //       fontColor: { displayName: 'Font color', type: { fill: { solid: { color: true } } } },
 * //       ...
 * //     }
 * //   }
 * ```
 */
export declare function getVcoCapabilities(objectName: string): VcoCatalogEntry | undefined;
