import type { VisualType, VisualCapabilities } from '../types/index.js';
/**
 * Returns a sorted array of all registered visual type identifiers.
 *
 * Only real visual types are returned. Non-visual instance-selector
 * keys (e.g. `filterCard`) live in a separate catalog — see
 * `listInstanceSelectorKeys()`.
 *
 * @example
 * ```ts
 * const types = listVisualTypes();
 * // → ['actionButton', 'areaChart', 'barChart', 'card', ...]
 * ```
 */
export declare function listVisualTypes(): VisualType[];
/**
 * Returns the full capabilities descriptor for a given visual type,
 * including its formatting objects, data roles, and behavioral flags.
 *
 * Returns `undefined` if the visual type is not registered.
 *
 * @example
 * ```ts
 * const caps = getCapabilities('lineChart');
 * // → { dataRoles: [...], objects: { dataPoint: { ... }, ... }, ... }
 * ```
 */
export declare function getCapabilities(visualType: VisualType): VisualCapabilities | undefined;
