import type { VisualSelectorMap } from '../types/index.js';
/**
 * Returns a sorted array of all registered instance-selector keys.
 *
 * Most keys are visual type identifiers (e.g. `actionButton`,
 * `pageNavigator`), but the catalog can also include non-visual
 * elements that expose state-keyed formatting buckets — for example
 * `filterCard`, whose `Available` / `Applied` states style the filter
 * pane.
 *
 * @example
 * ```ts
 * const keys = listInstanceSelectorKeys();
 * // → ['actionButton', 'advancedSlicerVisual', 'bookmarkNavigator',
 * //    'cardVisual', 'filterCard', 'pageNavigator', ...]
 * ```
 */
export declare function listInstanceSelectorKeys(): string[];
/**
 * Returns the instance-selector map for a given key.
 *
 * Each map entry is an object name → array of selector instance IDs
 * (e.g., `["default", "hover", "selected"]`).
 *
 * Returns `undefined` if the key is not registered.
 *
 * @example
 * ```ts
 * const selectors = getInstanceSelectors('actionButton');
 * // → { fill: ["default", "hover", "selected", "disabled"], outline: [...], ... }
 *
 * const filterStates = getInstanceSelectors('filterCard');
 * // → { filterCard: ["Available", "Applied"] }
 * ```
 */
export declare function getInstanceSelectors(key: string): VisualSelectorMap | undefined;
/**
 * Convenience: returns selector hints for specific object names within
 * an instance-selector key. Each hint pairs an object name with its
 * available selector IDs.
 *
 * Returns an empty array if the key is not registered or if none of
 * the requested object names have selectors.
 *
 * @example
 * ```ts
 * const hints = getSelectorHints('pageNavigator', ['fill', 'text']);
 * // → [
 * //     { objectName: 'fill', selectorIds: ['default', 'hover', 'selected', 'disabled'] },
 * //     { objectName: 'text', selectorIds: ['default', 'hover', 'selected', 'disabled'] },
 * //   ]
 * ```
 */
export declare function getSelectorHints(key: string, objectNames: readonly string[]): {
    objectName: string;
    selectorIds: string[];
}[];
