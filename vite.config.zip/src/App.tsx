import { useEffect, useMemo, useState } from 'react'
import { getContext } from '@microsoft/power-apps/app'
import './App.css'
import {
  Capps_catalogitemsService,
  Capps_orderidsService,
  Capps_catalogitemsModel,
  Capps_orderidsModel,
} from './generated'

const STATUS_BADGES: Record<string, string> = {
  Submitted: 'badge badge--gray',
  Approved: 'badge badge--blue',
  'In Progress': 'badge badge--yellow',
  Ordered: 'badge badge--purple',
  Delivered: 'badge badge--green',
  Denied: 'badge badge--red',
}

function App() {
  const [page, setPage] = useState<'catalog' | 'orders'>('catalog')
  const [catalogItems, setCatalogItems] = useState<Capps_catalogitemsModel.Capps_catalogitems[]>([])
  const [orders, setOrders] = useState<Capps_orderidsModel.Capps_orderids[]>([])
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('All')
  const [selectedItem, setSelectedItem] = useState<Capps_catalogitemsModel.Capps_catalogitems | null>(null)
  const [quantity, setQuantity] = useState(1)
  const [neededBy, setNeededBy] = useState('')
  const [deliveryLocation, setDeliveryLocation] = useState('')
  const [notes, setNotes] = useState('')
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [toast, setToast] = useState('')
  const [userName, setUserName] = useState('Current User')

  useEffect(() => {
    const loadData = async () => {
      setLoading(true)
      try {
        const context = await getContext().catch(() => null)
        if (context?.user?.fullName) {
          setUserName(context.user.fullName)
        }

        const catalogResult = await Capps_catalogitemsService.getAll({
          select: ['capps_catalogitemid', 'capps_itemname', 'capps_category', 'capps_categoryname', 'capps_available', 'capps_availablename'],
          orderBy: ['capps_itemname'],
        })
        if (catalogResult.success) {
          setCatalogItems(catalogResult.data ?? [])
        }

        const ordersResult = await Capps_orderidsService.getAll({
          select: ['capps_orderidid', 'capps_orderid1', 'capps_itemname', 'capps_quantity', 'capps_orderdate', 'capps_neededby', 'capps_orderstatus', 'capps_orderstatusname', 'createdbyname', 'ownerid', 'owneridtype', '_createdby_value', '_owninguser_value'],
          orderBy: ['capps_orderdate desc'],
        })

        if (ordersResult.success) {
          const currentUserId = context?.user?.objectId
          const currentUserName = context?.user?.fullName
          const filtered = (ordersResult.data ?? []).filter((order) => {
            const ownerMatches = order.ownerid === currentUserId || order._owninguser_value === currentUserId
            const creatorMatches = order.createdbyname === currentUserName || order._createdby_value === currentUserId
            return ownerMatches || creatorMatches
          })
          setOrders(filtered)
        }
      } catch (error) {
        console.error(error)
      } finally {
        setLoading(false)
      }
    }

    void loadData()
  }, [])

  useEffect(() => {
    if (!toast) return
    const timer = window.setTimeout(() => setToast(''), 2400)
    return () => window.clearTimeout(timer)
  }, [toast])

  const categories = useMemo(
    () => ['All', ...Array.from(new Set(catalogItems.map((item) => item.capps_categoryname || 'Other')))],
    [catalogItems],
  )

  const filteredCatalog = useMemo(() => {
    return catalogItems.filter((item) => {
      const matchesSearch = item.capps_itemname?.toLowerCase().includes(search.toLowerCase()) ?? false
      const matchesCategory = category === 'All' || (item.capps_categoryname ?? 'Other') === category
      return matchesSearch && matchesCategory
    })
  }, [catalogItems, category, search])

  const sortedOrders = useMemo(() => {
    return [...orders].sort((a, b) => new Date(b.capps_orderdate ?? '').getTime() - new Date(a.capps_orderdate ?? '').getTime())
  }, [orders])

  const openOrderModal = (item: Capps_catalogitemsModel.Capps_catalogitems) => {
    setSelectedItem(item)
    setQuantity(1)
    setNeededBy(new Date().toISOString().slice(0, 10))
    setDeliveryLocation('')
    setNotes('')
  }

  const handleCreateOrder = async (event: React.FormEvent) => {
    event.preventDefault()
    if (!selectedItem) return

    setSubmitting(true)
    try {
      const context = await getContext().catch(() => null)
      const currentUserId = context?.user?.objectId || ''
      const record = {
        capps_internalorder1: `Order for ${selectedItem.capps_itemname ?? 'Catalog item'}${notes ? ` | Notes: ${notes}` : ''}`,
        'capps_Item@odata.bind': `/capps_catalogitems(${selectedItem.capps_catalogitemid})`,
        capps_orderdate: new Date().toISOString(),
        capps_neededby: neededBy ? new Date(neededBy).toISOString() : undefined,
        capps_quantity: Number(quantity) || 1,
        capps_deliverlocation: deliveryLocation || undefined,
        capps_orderstatus: 917650000,
        ownerid: currentUserId,
        owneridtype: 'systemuser',
        statecode: 0,
        statuscode: 1,
      }

      const result = await Capps_orderidsService.create(record as never)
      if (result.success) {
        setToast('Order submitted successfully.')
        setSelectedItem(null)
        const refreshed = await Capps_orderidsService.getAll({
          select: ['capps_orderidid', 'capps_orderid1', 'capps_itemname', 'capps_quantity', 'capps_orderdate', 'capps_neededby', 'capps_orderstatus', 'capps_orderstatusname', 'createdbyname', 'ownerid', 'owneridtype', '_createdby_value', '_owninguser_value'],
          orderBy: ['capps_orderdate desc'],
        })
        if (refreshed.success) {
          const currentUserIdNow = context?.user?.objectId
          const currentUserNameNow = context?.user?.fullName
          setOrders(
            (refreshed.data ?? []).filter((order) => {
              const ownerMatches = order.ownerid === currentUserIdNow || order._owninguser_value === currentUserIdNow
              const creatorMatches = order.createdbyname === currentUserNameNow || order._createdby_value === currentUserIdNow
              return ownerMatches || creatorMatches
            }),
          )
        }
      } else {
        setToast('Unable to create the order right now.')
      }
    } catch (error) {
      console.error(error)
      setToast('Unable to create the order right now.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div>
          <p className="eyebrow">Operations</p>
          <h2 className="sidebar-title">Supply Hub</h2>
          <p className="sidebar-copy">Track catalog items and your internal orders in one place.</p>
        </div>

        <nav className="nav-list">
          <button className={page === 'catalog' ? 'nav-button active' : 'nav-button'} onClick={() => setPage('catalog')}>
            Catalog
          </button>
          <button className={page === 'orders' ? 'nav-button active' : 'nav-button'} onClick={() => setPage('orders')}>
            My Orders
          </button>
        </nav>
      </aside>

      <main className="content-panel">
        <header className="topbar">
          <div>
            <p className="eyebrow">Welcome back</p>
            <h1>Supply Hub</h1>
          </div>
          <div className="user-chip">{userName}</div>
        </header>

        {page === 'catalog' ? (
          <section className="page-section">
            <div className="section-heading">
              <div>
                <p className="eyebrow">Catalog</p>
                <h2>Available items</h2>
              </div>
              <div className="filter-row">
                <input
                  type="search"
                  placeholder="Search item name"
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                />
                <select value={category} onChange={(event) => setCategory(event.target.value)}>
                  {categories.map((option) => (
                    <option key={option} value={option}>{option}</option>
                  ))}
                </select>
              </div>
            </div>

            {loading ? (
              <p className="empty-state">Loading catalog items…</p>
            ) : filteredCatalog.length === 0 ? (
              <p className="empty-state">No catalog items match your filters.</p>
            ) : (
              <div className="card-grid">
                {filteredCatalog.map((item) => (
                  <article className="catalog-card" key={item.capps_catalogitemid}>
                    <p className="pill">{item.capps_categoryname || 'Other'}</p>
                    <h3>{item.capps_itemname}</h3>
                    <p className="muted">Availability: {item.capps_available ? 'Yes' : 'No'}</p>
                    <button
                      className="primary-button"
                      onClick={() => openOrderModal(item)}
                      disabled={!item.capps_available}
                    >
                      {item.capps_available ? 'Order' : 'Unavailable'}
                    </button>
                  </article>
                ))}
              </div>
            )}
          </section>
        ) : (
          <section className="page-section">
            <div className="section-heading">
              <div>
                <p className="eyebrow">My Orders</p>
                <h2>Your submitted requests</h2>
              </div>
            </div>

            {loading ? (
              <p className="empty-state">Loading your orders…</p>
            ) : sortedOrders.length === 0 ? (
              <p className="empty-state">You have no orders yet.</p>
            ) : (
              <div className="table-wrap">
                <table className="order-table">
                  <thead>
                    <tr>
                      <th>Order ID</th>
                      <th>Item</th>
                      <th>Quantity</th>
                      <th>Order Date</th>
                      <th>Needed By</th>
                      <th>Status</th>
                      <th>Assigned To</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sortedOrders.map((order) => (
                      <tr key={order.capps_orderidid}>
                        <td>{order.capps_orderid1 || order.capps_orderidid}</td>
                        <td>{order.capps_itemname || 'Catalog item'}</td>
                        <td>{order.capps_quantity ?? 1}</td>
                        <td>{order.capps_orderdate ? new Date(order.capps_orderdate).toLocaleDateString() : '—'}</td>
                        <td>{order.capps_neededby ? new Date(order.capps_neededby).toLocaleDateString() : '—'}</td>
                        <td>
                          <span className={STATUS_BADGES[order.capps_orderstatusname ?? 'Submitted'] || 'badge badge--gray'}>
                            {order.capps_orderstatusname || 'Submitted'}
                          </span>
                        </td>
                        <td>{order.owneridname || order.createdbyname || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        )}

        {selectedItem && (
          <div className="modal-backdrop" onClick={() => setSelectedItem(null)}>
            <div className="modal-card" onClick={(event) => event.stopPropagation()}>
              <div className="modal-header">
                <div>
                  <p className="eyebrow">New order</p>
                  <h3>Order {selectedItem.capps_itemname}</h3>
                </div>
                <button className="ghost-button" onClick={() => setSelectedItem(null)}>Close</button>
              </div>

              <form className="order-form" onSubmit={handleCreateOrder}>
                <label>
                  Item
                  <input value={selectedItem.capps_itemname || ''} readOnly />
                </label>
                <label>
                  Quantity
                  <input type="number" min="1" value={quantity} onChange={(event) => setQuantity(Number(event.target.value) || 1)} />
                </label>
                <label>
                  Needed By
                  <input type="date" value={neededBy} onChange={(event) => setNeededBy(event.target.value)} />
                </label>
                <label>
                  Delivery Location
                  <input value={deliveryLocation} onChange={(event) => setDeliveryLocation(event.target.value)} placeholder="Room / Site / Desk" />
                </label>
                <label>
                  Notes
                  <textarea value={notes} onChange={(event) => setNotes(event.target.value)} rows={4} placeholder="Optional instructions" />
                </label>

                <div className="modal-actions">
                  <button type="button" className="ghost-button" onClick={() => setSelectedItem(null)}>Cancel</button>
                  <button type="submit" className="primary-button" disabled={submitting}>
                    {submitting ? 'Submitting…' : 'Submit Order'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {toast && <div className="toast">{toast}</div>}
      </main>
    </div>
  )
}

export default App
