/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 * This file is auto-generated. Do not modify it manually.
 * Changes to this file may be overwritten.
 */

export const dataSourcesInfo = {
  "capps_catalogitem1s": {
    "tableId": "",
    "version": "",
    "primaryKey": "capps_catalogitem1id",
    "dataSourceType": "Dataverse",
    "apis": {}
  },
  "capps_orderids": {
    "tableId": "",
    "version": "",
    "primaryKey": "capps_orderidid",
    "dataSourceType": "Dataverse",
    "apis": {}
  },
  "capps_supplyorders": {
    "tableId": "",
    "version": "",
    "primaryKey": "capps_supplyorderid",
    "dataSourceType": "Dataverse",
    "apis": {}
  }
};
