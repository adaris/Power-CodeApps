/*
 * NevWare21 Solutions LLC - ts-utils Polyfills, v0.15.0
 * https://github.com/nevware21/ts-utils
 * Copyright (c) NevWare21 Solutions LLC and contributors. All rights reserved.
 * Licensed under the MIT license.
 */
this.nevware21 = this.nevware21 || {};
this.nevware21["ts-utils"] = (function (exports) {
    'use strict';

    /*#__NO_SIDE_EFFECTS__*/
    function _pureAssign(func1, func2) {
        return func1 || func2;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _pureRef(value, name) {
        return value !== null && value !== undefined ? value[name] : undefined;
    }

    var UNDEF_VALUE = undefined;
    var NULL_VALUE = null;
    var EMPTY = "";
    var FUNCTION = "function";
    var OBJECT = "object";
    var PROTOTYPE = "prototype";
    var __PROTO__ = "__proto__";
    var UNDEFINED = "undefined";
    var SYMBOL = "Symbol";
    var LENGTH = "length";
    var CALL = "call";
    var TO_STRING = "toString";
    var GET_OWN_PROPERTY_DESCRIPTOR = "getOwnPropertyDescriptor";
    var GET_OWN_PROPERTY_NAMES = "getOwnPropertyNames";
    var ObjClass = (/*#__PURE__*/_pureAssign(Object));
    var ObjProto = (/*#__PURE__*/_pureRef(ObjClass, PROTOTYPE));
    var StrCls = (/*#__PURE__*/_pureAssign(String));
    var StrProto = (/*#__PURE__*/_pureRef(StrCls, PROTOTYPE));
    var MathCls = (/*#__PURE__*/_pureAssign(Math));
    var ArrCls = (/*#__PURE__*/_pureAssign(Array));
    var ArrProto = (/*#__PURE__*/_pureRef(ArrCls, PROTOTYPE));
    var ArrSlice = (/*#__PURE__*/_pureRef(ArrProto, "slice"));

    var POLYFILL_TAG = "_polyfill";
    var POLYFILL_TYPE_NAME = "__nw21$polytype__";
    /*#__NO_SIDE_EFFECTS__*/
    function makePolyFn(poly) {
        return function () {
            var theArgs = [this];
            for (var lp = 0; lp < arguments[LENGTH]; lp++) {
                theArgs[lp + 1] = arguments[lp];
            }
            return poly.apply(this, theArgs);
        };
    }

    function safe(func, argArray) {
        try {
            return {
                v: func.apply(this, argArray)
            };
        }
        catch (e) {
            return { e: e };
        }
    }

    /*#__NO_SIDE_EFFECTS__*/
    function _createIs(theType) {
        return function (value) {
            return typeof value === theType;
        };
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _createObjIs(theName) {
        var theType = "[object " + theName + "]";
        return function (value) {
            return !!(value && objToString(value) === theType);
        };
    }
    /*#__NO_SIDE_EFFECTS__*/
    function objToString(value) {
        return ObjProto[TO_STRING].call(value);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isUndefined(value) {
        return typeof value === UNDEFINED || value === UNDEFINED;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isStrictUndefined(arg) {
        return arg === UNDEF_VALUE;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isNullOrUndefined(value) {
        return value === NULL_VALUE || isUndefined(value);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isStrictNullOrUndefined(value) {
        return value === NULL_VALUE || value === UNDEF_VALUE;
    }
    var isString = (/*#__PURE__*/_createIs("string"));
    var isFunction = (/*#__PURE__*/_createIs(FUNCTION));
    /*#__NO_SIDE_EFFECTS__*/
    function isObject(value) {
        if (!value && isNullOrUndefined(value)) {
            return false;
        }
        return !!value && typeof value === OBJECT;
    }
    var isArray = (/*#__PURE__*/_pureRef(ArrCls, "isArray"));
    /*#__NO_SIDE_EFFECTS__*/
    function isArrayLike(arg) {
        return !isStrictNullOrUndefined(arg) && !isFunction(arg) && isNumber(arg[LENGTH]) && arg[LENGTH] >= 0;
    }
    var isNumber = (/*#__PURE__*/_createIs("number"));
    var isRegExp = (/*#__PURE__*/_createObjIs("RegExp"));

    function arrForEach(theArray, callbackfn, thisArg) {
        if (theArray) {
            var len = theArray[LENGTH] >>> 0;
            for (var idx = 0; idx < len; idx++) {
                if (idx in theArray) {
                    if (callbackfn[CALL](isStrictNullOrUndefined(thisArg) ? theArray : thisArg, theArray[idx], idx, theArray) === -1) {
                        break;
                    }
                }
            }
        }
    }

    var asString = (/*#__PURE__*/_pureAssign(StrCls));

    var ERROR_TYPE = "[object Error]";
    /*#__NO_SIDE_EFFECTS__*/
    function dumpObj(object, format) {
        var propertyValueDump = EMPTY;
        var objType = ObjProto[TO_STRING][CALL](object);
        if (objType === ERROR_TYPE) {
            object = { stack: asString(object.stack), message: asString(object.message), name: asString(object.name) };
        }
        try {
            propertyValueDump = JSON.stringify(object, NULL_VALUE, format ? ((typeof format === "number") ? format : 4) : UNDEF_VALUE);
            propertyValueDump = (propertyValueDump ? propertyValueDump.replace(/"(\w+)"\s*:\s{0,1}/g, "$1: ") : NULL_VALUE) || asString(object);
        }
        catch (e) {
            propertyValueDump = " - " + dumpObj(e, format);
        }
        return objType + ": " + propertyValueDump;
    }

    function throwTypeError(message) {
        throw new TypeError(message);
    }
    function throwRangeError(message) {
        throw new RangeError(message);
    }

    var _unwrapFunction = _unwrapFunctionWithPoly;
    /*#__NO_SIDE_EFFECTS__*/
    function _unwrapFunctionWithPoly(funcName, clsProto, polyFunc) {
        var clsFn = clsProto ? clsProto[funcName] : NULL_VALUE;
        return function (thisArg) {
            var theFunc = (thisArg ? thisArg[funcName] : NULL_VALUE) || clsFn;
            if (theFunc || polyFunc) {
                var theArgs = arguments;
                return (theFunc || polyFunc).apply(thisArg, theFunc ? ArrSlice[CALL](theArgs, 1) : theArgs);
            }
            throwTypeError("\"" + asString(funcName) + "\" not defined for " + dumpObj(thisArg));
        };
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _unwrapProp(propName) {
        return function (thisArg) {
            return thisArg[propName];
        };
    }

    var arrIndexOf = (/*#__PURE__*/_unwrapFunction("indexOf", ArrProto));

    var arrMap = (/*#__PURE__*/_unwrapFunction("map", ArrProto));

    function arrSlice(theArray, start, end) {
        return ((theArray ? theArray["slice"] : NULL_VALUE) || ArrSlice).apply(theArray, ArrSlice[CALL](arguments, 1));
    }

    function fnApply(fn, thisArg, argArray) {
        return fn.apply(thisArg, argArray);
    }
    function fnCall(fn, thisArg) {
        return fn.apply(thisArg, ArrSlice[CALL](arguments, 2));
    }

    function _returnNothing() {
        return;
    }
    function _returnEmptyArray() {
        return [];
    }

    function _throwIfNullOrUndefined(obj) {
        if (isStrictNullOrUndefined(obj)) {
            throwTypeError("Cannot convert undefined or null to object");
        }
    }
    function _throwIfNotString(value) {
        if (!isString(value)) {
            throwTypeError("'" + dumpObj(value) + "' is not a string");
        }
    }

    /*#__NO_SIDE_EFFECTS__*/
    function objHasOwnProperty(obj, prop) {
        return !!obj && ObjProto.hasOwnProperty[CALL](obj, prop);
    }

    var _objGetOwnPropertyDescriptor$2 = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, GET_OWN_PROPERTY_DESCRIPTOR)), _returnNothing));
    var objHasOwn = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, "hasOwn")), polyObjHasOwn));
    /*#__NO_SIDE_EFFECTS__*/
    function polyObjHasOwn(obj, prop) {
        _throwIfNullOrUndefined(obj);
        return objHasOwnProperty(obj, prop) || !!_objGetOwnPropertyDescriptor$2(obj, prop);
    }

    function objForEachKey(theObject, callbackfn, thisArg) {
        if (theObject && (isObject(theObject) || isFunction(theObject))) {
            for (var prop in theObject) {
                if (objHasOwn(theObject, prop)) {
                    if (callbackfn[CALL](isStrictNullOrUndefined(thisArg) ? theObject : thisArg, prop, theObject[prop]) === -1) {
                        break;
                    }
                }
            }
        }
    }

    var _objGetOwnPropertyDescriptor$1 = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, GET_OWN_PROPERTY_DESCRIPTOR)), _returnNothing));
    var propMap = {
        e: "enumerable",
        c: "configurable",
        v: "value",
        w: "writable",
        g: "get",
        s: "set"
    };
    /*#__NO_SIDE_EFFECTS__*/
    function _createProp(value) {
        var prop = {};
        prop[propMap["c"]] = true;
        prop[propMap["e"]] = true;
        if (value.l) {
            prop.get = function () { return value.l.v; };
            var desc = _objGetOwnPropertyDescriptor$1(value.l, "v");
            if (desc && desc.set) {
                prop.set = function (newValue) {
                    value.l.v = newValue;
                };
            }
        }
        objForEachKey(value, function (key, value) {
            prop[propMap[key]] = isStrictUndefined(value) ? prop[propMap[key]] : value;
        });
        return prop;
    }
    var objDefineProp = (/*#__PURE__*/_pureRef(ObjClass, "defineProperty"));
    var objDefineProperties = (/*#__PURE__*/_pureRef(ObjClass, "defineProperties"));
    function objDefine(target, key, propDesc) {
        return objDefineProp(target, key, _createProp(propDesc));
    }

    /*#__NO_SIDE_EFFECTS__*/
    function createCachedValue(value) {
        return objDefineProp({
            toJSON: function () { return value; }
        }, "v", { value: value });
    }

    /*#__NO_SIDE_EFFECTS__*/
    function _createKeyValueMap(values, keyType, valueType, completeFn, writable) {
        var theMap = {};
        objForEachKey(values, function (key, value) {
            _assignMapValue(theMap, key, key);
            _assignMapValue(theMap, value, key);
        });
        return completeFn ? completeFn(theMap) : theMap;
    }
    function _assignMapValue(theMap, key, value, writable) {
        objDefineProp(theMap, key, {
            value: value,
            enumerable: true,
            writable: false
        });
    }

    function _objIterateEntries(obj, mapper) {
        var result = [];
        objForEachKey(obj, function (key, val) {
            result.push(mapper(key, val));
        });
        return result;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyObjKeys(obj) {
        _throwIfNullOrUndefined(obj);
        if (!isObject(obj)) {
            throwTypeError("non-object " + dumpObj(obj));
        }
        return _objIterateEntries(obj, function (k, _) { return k; });
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyObjEntries(value) {
        return _objIterateEntries(value, function (k, v) { return [k, v]; });
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyObjValues(value) {
        return _objIterateEntries(value, function (_, v) { return v; });
    }

    function polyObjIs(value1, value2) {
        if (value1 !== value1) {
            return value2 !== value2;
        }
        if (value1 === 0 && value2 === 0) {
            return 1 / value1 === 1 / value2;
        }
        return value1 === value2;
    }

    var _objFreeze = (/*#__PURE__*/_pureRef(ObjClass, "freeze"));
    function _doNothing(value) {
        return value;
    }
    var objFreeze = (/*#__PURE__*/_pureAssign(_objFreeze, _doNothing));

    /*#__NO_SIDE_EFFECTS__*/
    function createEnumKeyMap(values) {
        return _createKeyValueMap(values, 0 , 0 , objFreeze);
    }

    var _wellKnownSymbolMap = (/*#__PURE__*/createEnumKeyMap({
        asyncIterator: 0 ,
        hasInstance: 1 ,
        isConcatSpreadable: 2 ,
        iterator: 3 ,
        match: 4 ,
        matchAll: 5 ,
        replace: 6 ,
        search: 7 ,
        species: 8 ,
        split: 9 ,
        toPrimitive: 10 ,
        toStringTag: 11 ,
        unscopables: 12
    }));

    var GLOBAL_CONFIG_KEY = "__tsUtils$gblCfg";
    var _globalCfg;
    /*#__NO_SIDE_EFFECTS__*/
    function _getGlobalValue() {
        var result;
        if (typeof globalThis !== UNDEFINED) {
            result = globalThis;
        }
        if (!result && typeof self !== UNDEFINED) {
            result = self;
        }
        if (!result && typeof window !== UNDEFINED) {
            result = window;
        }
        if (!result && typeof global !== UNDEFINED) {
            result = global;
        }
        return result;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _getGlobalConfig() {
        if (!_globalCfg) {
            var gbl = safe(_getGlobalValue).v || {};
            _globalCfg = gbl[GLOBAL_CONFIG_KEY] = gbl[GLOBAL_CONFIG_KEY] || {};
        }
        return _globalCfg;
    }

    var mathMin = (/*#__PURE__*/_pureRef(MathCls, "min"));
    var mathMax = (/*#__PURE__*/_pureRef(MathCls, "max"));

    var strSlice = (/*#__PURE__*/_unwrapFunction("slice", StrProto));

    var strSubstring = (/*#__PURE__*/_unwrapFunction("substring", StrProto));
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrSubstr(value, start, length) {
        _throwIfNullOrUndefined(value);
        if (length < 0) {
            return EMPTY;
        }
        start = start || 0;
        if (start < 0) {
            start = mathMax(start + value[LENGTH], 0);
        }
        if (isUndefined(length)) {
            return strSlice(value, start);
        }
        return strSlice(value, start, start + length);
    }

    function _tagAsPolyfill(target, polyfillTypeName) {
        if (target) {
            safe(function () {
                target[POLYFILL_TAG] = true;
                target[POLYFILL_TYPE_NAME] = polyfillTypeName;
            });
            safe(objDefine, [target, POLYFILL_TAG, {
                    v: true,
                    w: false,
                    e: false
                }]);
            safe(objDefine, [target, POLYFILL_TYPE_NAME, {
                    v: polyfillTypeName,
                    w: false,
                    e: false
                }]);
        }
        return target;
    }

    var objCreate = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, "create")), polyObjCreate));
    /*#__NO_SIDE_EFFECTS__*/
    function polyObjCreate(obj, properties) {
        var newObj = null;
        function tempFunc() { }
        if (!isStrictNullOrUndefined(obj)) {
            var type = typeof obj;
            if (type !== OBJECT && type !== FUNCTION) {
                throwTypeError("Prototype must be an Object or function: " + dumpObj(obj));
            }
            tempFunc[PROTOTYPE] = obj;
            safe(function () {
                tempFunc[__PROTO__] = obj;
            });
            newObj = new tempFunc();
        }
        else {
            newObj = {};
        }
        if (properties) {
            safe(objDefineProperties, [newObj, properties]);
        }
        return newObj;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function utcNow() {
        return (Date.now || polyUtcNow)();
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyUtcNow() {
        return new Date().getTime();
    }

    var _globalLazyTestHooks;
    function _initTestHooks() {
        _globalLazyTestHooks = _getGlobalConfig();
    }
    /*#__NO_SIDE_EFFECTS__*/
    function getLazy(cb, argArray) {
        var lazyValue = {};
        !_globalLazyTestHooks && _initTestHooks();
        lazyValue.b = _globalLazyTestHooks.lzy;
        objDefineProp(lazyValue, "v", {
            configurable: true,
            get: function () {
                var result = fnApply(cb, null, argArray);
                if (!_globalLazyTestHooks.lzy) {
                    objDefineProp(lazyValue, "v", {
                        value: result
                    });
                }
                lazyValue.b = _globalLazyTestHooks.lzy;
                return result;
            }
        });
        return lazyValue;
    }

    var mathRandom = (/*#__PURE__*/_pureRef(MathCls, "random"));

    var _uniqueInstanceId = (/*#__PURE__*/getLazy(function () {
        var value = (utcNow().toString(36).slice(2));
        while (value.length < 16) {
            value += mathRandom().toString(36).slice(2);
        }
        value = value.substring(0, 16);
        return value;
    }));

    var POLY_SYM = "$nw21sym";
    var _polyId = 0;
    var _wellKnownSymbolCache;
    /*#__NO_SIDE_EFFECTS__*/
    function polyNewSymbol(description) {
        var uniqueId = "_" + _polyId++ + "_" + _uniqueInstanceId.v;
        var symString = SYMBOL + "(" + description + ")";
        function _setProp(name, value) {
            objDefine(theSymbol, name, {
                v: value,
                e: false,
                w: false
            });
        }
        var theSymbol = objCreate(null);
        _setProp("description", asString(description));
        _setProp(TO_STRING, function () { return symString + POLY_SYM + uniqueId; });
        _setProp("valueOf", function () { return theSymbol; });
        _setProp("v", symString);
        _setProp("_uid", uniqueId);
        return _tagAsPolyfill(theSymbol, "symbol");
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyGetKnownSymbol(name) {
        !_wellKnownSymbolCache && (_wellKnownSymbolCache = {});
        var result;
        var knownName = _wellKnownSymbolMap[name];
        if (knownName) {
            result = _wellKnownSymbolCache[knownName] = _wellKnownSymbolCache[knownName] || polyNewSymbol(SYMBOL + "." + knownName);
        }
        return result;
    }

    var WINDOW = "window";
    var _cachedGlobal;
    function getGlobal(useCached) {
        !_globalLazyTestHooks && _initTestHooks();
        if (!_cachedGlobal || useCached === false || _globalLazyTestHooks.lzy) {
            _cachedGlobal = createCachedValue(safe(_getGlobalValue).v || NULL_VALUE);
        }
        return _cachedGlobal.v;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function getInst(name, useCached) {
        var gbl;
        if (!_cachedGlobal || useCached === false) {
            gbl = getGlobal(useCached);
        }
        else {
            gbl = _cachedGlobal.v;
        }
        if (gbl && gbl[name]) {
            return gbl[name];
        }
        if (name === WINDOW) {
            try {
                return window;
            }
            catch (e) {
            }
        }
        return NULL_VALUE;
    }

    var _symbol;
    /*#__NO_SIDE_EFFECTS__*/
    function _initSymbol() {
        _symbol = (/*#__PURE__*/createCachedValue(safe((getInst), [SYMBOL]).v));
        return _symbol;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function getKnownSymbol(name, noPoly) {
        var knownName = _wellKnownSymbolMap[name];
        !_globalLazyTestHooks && _initTestHooks();
        var sym = ((!_globalLazyTestHooks.lzy ? _symbol : 0) || _initSymbol());
        return sym.v ? sym.v[knownName || name] : (polyGetKnownSymbol(name) );
    }

    /*#__NO_SIDE_EFFECTS__*/
    function isIterator(value) {
        return !!value && isFunction(value.next);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isIterable(value) {
        return !isStrictNullOrUndefined(value) && isFunction(value[getKnownSymbol(3 )]);
    }

    var _iterSymbol;
    function iterForOf(iter, callbackfn, thisArg) {
        if (iter) {
            if (!isIterator(iter)) {
                !_iterSymbol && (_iterSymbol = createCachedValue(getKnownSymbol(3 )));
                iter = iter[_iterSymbol.v] ? iter[_iterSymbol.v]() : NULL_VALUE;
            }
            if (isIterator(iter)) {
                var err = UNDEF_VALUE;
                var iterResult = UNDEF_VALUE;
                try {
                    var count = 0;
                    while (!(iterResult = iter.next()).done) {
                        if (callbackfn[CALL](isStrictNullOrUndefined(thisArg) ? iter : thisArg, iterResult.value, count, iter) === -1) {
                            break;
                        }
                        count++;
                    }
                }
                catch (failed) {
                    err = { e: failed };
                    if (iter.throw) {
                        iterResult = NULL_VALUE;
                        iter.throw(err);
                    }
                }
                finally {
                    try {
                        if (iterResult && !iterResult.done) {
                            iter.return && iter.return(iterResult);
                        }
                    }
                    finally {
                        if (err) {
                            throw err.e;
                        }
                    }
                }
            }
        }
    }

    /*#__NO_SIDE_EFFECTS__*/
    function polyIsArray(value) {
        if (isNullOrUndefined(value)) {
            return false;
        }
        return objToString(value) === "[object Array]";
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyArrIncludes(theArray, searchElement, fromIndex) {
        return arrIndexOf(theArray, searchElement, fromIndex) !== -1;
    }
    function polyArrFind(theArray, callbackFn, thisArg) {
        var result;
        var idx = polyArrFindIndex(theArray, callbackFn, thisArg);
        return idx !== -1 ? theArray[idx] : result;
    }
    function polyArrFindIndex(theArray, callbackFn, thisArg) {
        var result = -1;
        arrForEach(theArray, function (value, index) {
            if (callbackFn[CALL](isStrictNullOrUndefined(thisArg) ? theArray : thisArg, value, index, theArray)) {
                result = index;
                return -1;
            }
        });
        return result;
    }
    function polyArrFindLast(theArray, callbackFn, thisArg) {
        var result;
        var idx = polyArrFindLastIndex(theArray, callbackFn, thisArg);
        return idx !== -1 ? theArray[idx] : result;
    }
    function polyArrFindLastIndex(theArray, callbackFn, thisArg) {
        var result = -1;
        var len = theArray[LENGTH] >>> 0;
        for (var idx = len - 1; idx >= 0; idx--) {
            if (idx in theArray && callbackFn[CALL](isStrictNullOrUndefined(thisArg) ? theArray : thisArg, theArray[idx], idx, theArray)) {
                result = idx;
                break;
            }
        }
        return result;
    }
    function polyArrFrom(theValue, mapFn, thisArg) {
        if (isArray(theValue)) {
            var result_1 = arrSlice(theValue);
            return mapFn ? arrMap(result_1, mapFn, thisArg) : result_1;
        }
        var result = [];
        iterForOf(theValue, function (value, cnt) {
            return result.push(mapFn ? mapFn[CALL](thisArg, value, cnt) : value);
        });
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function polyStrStartsWith(value, searchString, position) {
        _throwIfNotString(value);
        var searchValue = isString(searchString) ? searchString : asString(searchString);
        var pos = position > 0 ? position : 0;
        return strSubstring(value, pos, pos + searchValue[LENGTH]) === searchValue;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function polyStrEndsWith(value, searchString, length) {
        _throwIfNotString(value);
        var searchValue = isString(searchString) ? searchString : asString(searchString);
        var end = (!isUndefined(length) && length < value[LENGTH]) ? length : value[LENGTH];
        return strSubstring(value, end - searchValue[LENGTH], end) === searchValue;
    }

    var strReplace = (/*#__PURE__*/_unwrapFunction("replace", StrProto));

    /*#__NO_SIDE_EFFECTS__*/
    function _createTrimFn(exp) {
        return function _doTrim(value) {
            _throwIfNullOrUndefined(value);
            value = asString(value);
            if (value) {
                value = strReplace(value, exp, EMPTY);
            }
            return value;
        };
    }
    var polyStrTrim = (/*#__PURE__*/_createTrimFn(/^\s+|(?=\s)\s+$/g));
    var polyStrTrimStart = (/*#__PURE__*/_createTrimFn(/^\s+/g));
    var polyStrTrimEnd = (/*#__PURE__*/_createTrimFn(/(?=\s)\s+$/g));

    var mathFloor = (/*#__PURE__*/_pureRef(MathCls, "floor"));
    var mathCeil = (/*#__PURE__*/_pureRef(MathCls, "ceil"));

    var mathTrunc = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(MathCls, "trunc")), polyMathTrunc));
    /*#__NO_SIDE_EFFECTS__*/
    function polyMathTrunc(value) {
        var theValue = +value;
        return (theValue > 0 ? mathFloor : mathCeil)(theValue);
    }

    /*#__NO_SIDE_EFFECTS__*/
    function mathToInt(value, throwInfinity) {
        var result = +value;
        if (throwInfinity && (result === Infinity || result == Infinity)) {
            throwRangeError("invalid value [" + dumpObj(value) + "]");
        }
        return result !== result || result === 0 ? 0 : mathTrunc(result);
    }

    var strRepeat = (/*#__PURE__*/_unwrapFunctionWithPoly("repeat", StrProto, polyStrRepeat));
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrRepeat(value, count) {
        _throwIfNullOrUndefined(value);
        count = mathToInt(count, true);
        if (count < 0) {
            throwRangeError("invalid count must be >= 0 && < Infinity");
        }
        var pad = isString(value) ? value : asString(value);
        var result = EMPTY;
        for (; count > 0; (count >>>= 1) && (pad += pad)) {
            if (count & 1) {
                result += pad;
            }
        }
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function _padValue(value, targetLength, padString) {
        var result = EMPTY;
        targetLength = mathToInt(targetLength, true);
        targetLength >>= 0;
        var len = value[LENGTH];
        if (len < targetLength) {
            result = isNullOrUndefined(padString) ? " " : asString(padString);
            targetLength = targetLength - len;
            if (targetLength > result[LENGTH]) {
                result = strRepeat(result, mathCeil(targetLength / result[LENGTH]));
            }
            if (result[LENGTH] > targetLength) {
                result = strSubstring(result, 0, targetLength);
            }
        }
        return result;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrPadStart(value, targetLength, padString) {
        return _padValue(value, targetLength, padString) + value;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrPadEnd(value, targetLength, padString) {
        return value + _padValue(value, targetLength, padString);
    }

    var strIndexOf = (/*#__PURE__*/_unwrapFunction("indexOf", StrProto));

    /*#__NO_SIDE_EFFECTS__*/
    function polyStrIncludes(value, searchString, position) {
        if (isRegExp(searchString)) {
            throwTypeError("'searchString' must not be a regular expression" + dumpObj(searchString));
        }
        return strIndexOf(value, asString(searchString), position) !== -1;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function createLiteralRegex(matcher) {
        return new RegExp(strReplace(asString(matcher), /[.*+?^${}()|[\]\\]/g, "\\$&") || "(?:)", "g");
    }

    /*#__NO_SIDE_EFFECTS__*/
    function polyStrReplaceAll(value, searchValue, replaceValue) {
        _throwIfNullOrUndefined(value);
        var matchSymbol = getKnownSymbol(4 );
        var replaceSymbol = getKnownSymbol(6 );
        var replaceFn;
        var matcher;
        var isRegex = isRegExp(searchValue);
        var theValue = isString(value) ? value : asString(value);
        var isSearchNotNull = searchValue || !isStrictNullOrUndefined(searchValue);
        if (isRegex && isSearchNotNull) {
            isRegex = searchValue[matchSymbol] !== false;
        }
        if (isRegex) {
            if (!searchValue.global) {
                throwTypeError("searchValue must be a global regular expression");
            }
            matcher = searchValue;
        }
        else {
            replaceFn = isSearchNotNull ? searchValue[replaceSymbol] : null;
            if (isFunction(replaceFn)) {
                return replaceFn.call(searchValue, theValue, replaceValue);
            }
            var search = isString(searchValue) ? searchValue : asString(searchValue);
            matcher = createLiteralRegex(search);
        }
        return strReplace(theValue, matcher, replaceValue);
    }

    function polyObjFromEntries(entries) {
        var result = {};
        function _defineProtoValue(value) {
            Object.defineProperty(result, __PROTO__, {
                value: value,
                enumerable: true,
                configurable: true,
                writable: true
            });
        }
        function addEntry(entry) {
            if (isArray(entry) && entry.length >= 2) {
                if (entry[0] === __PROTO__) {
                    _defineProtoValue(entry[1]);
                }
                else {
                    result[entry[0]] = entry[1];
                }
            }
        }
        if (isArray(entries)) {
            arrForEach(entries, addEntry);
        }
        else if (isIterable(entries)) {
            iterForOf(entries, addEntry);
        }
        return result;
    }

    var _recursionCheckOwnDescriptors;
    var _recursionCheckOwnSymbols;
    var _objGetOwnPropertyNames = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, GET_OWN_PROPERTY_NAMES)), _returnEmptyArray));
    var _objGetOwnPropertyDescriptor = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, GET_OWN_PROPERTY_DESCRIPTOR)), _returnNothing));
    function polyObjGetOwnPropertyDescriptors(obj) {
        var result = {};
        _throwIfNullOrUndefined(obj);
        if (!_recursionCheckOwnDescriptors) {
            try {
                _recursionCheckOwnDescriptors = true;
                arrForEach(_objGetOwnPropertyNames(obj), function (propName) {
                    var descriptor = _objGetOwnPropertyDescriptor(obj, propName);
                    if (descriptor !== undefined) {
                        result[propName] = descriptor;
                    }
                });
                arrForEach(_polyObjGetOwnPropertySymbols(obj), function (sym) {
                    var descriptor = _objGetOwnPropertyDescriptor(obj, sym);
                    if (descriptor !== undefined) {
                        result[sym] = descriptor;
                    }
                });
            }
            finally {
                _recursionCheckOwnDescriptors = false;
            }
        }
        return result;
    }
    function _polyObjGetOwnPropertySymbols(obj) {
        var result = [];
        var objHasOwn = ObjClass.hasOwn || polyObjHasOwn;
        if (!_recursionCheckOwnSymbols) {
            try {
                _recursionCheckOwnSymbols = true;
                var symEnum = 0 ;
                while (symEnum <= 12 ) {
                    var sym = getKnownSymbol(symEnum);
                    if (sym && objHasOwn(obj, sym)) {
                        result.push(sym);
                    }
                    symEnum++;
                }
            }
            finally {
                _recursionCheckOwnSymbols = false;
            }
        }
        return result;
    }
    function _polyObjGetOwnPropertyNames(obj) {
        var result = [];
        _throwIfNullOrUndefined(obj);
        for (var key in obj) {
            if (ObjProto.hasOwnProperty.call(obj, key)) {
                result.push(key);
            }
        }
        if (isArray(obj) || isString(obj)) {
            if (arrIndexOf(result, LENGTH) === -1) {
                result.push(LENGTH);
            }
        }
        return result;
    }

    function polyObjPreventExtensions(obj) {
        _throwIfNullOrUndefined(obj);
        if (!isObject(obj) && !isFunction(obj)) {
            throwTypeError("objPreventExtensions can only be called on Objects");
        }
        return obj;
    }

    function polyObjIsExtensible(obj) {
        if (isStrictNullOrUndefined(obj) || (!isObject(obj) && !isFunction(obj))) {
            return false;
        }
        return true;
    }

    var objGetOwnPropertyDescriptor = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, GET_OWN_PROPERTY_DESCRIPTOR)), _returnNothing));

    function polyObjIsFrozen(obj) {
        if (isStrictNullOrUndefined(obj) || (!isObject(obj) && !isFunction(obj))) {
            return true;
        }
        if (isFunction(obj)) {
            return false;
        }
        for (var prop in obj) {
            var desc = objGetOwnPropertyDescriptor(obj, prop);
            if (desc && (desc.configurable || (desc.writable !== false && "value" in desc))) {
                return false;
            }
        }
        return true;
    }

    function polyObjIsSealed(obj) {
        if (isStrictNullOrUndefined(obj) || (!isObject(obj) && !isFunction(obj))) {
            return true;
        }
        if (isFunction(obj)) {
            return false;
        }
        for (var prop in obj) {
            var desc = objGetOwnPropertyDescriptor(obj, prop);
            if (desc && desc.configurable) {
                return false;
            }
        }
        return true;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function polyArrAt(theArray, index) {
        var result;
        if (isArrayLike(theArray)) {
            var len = theArray.length;
            var idx = index;
            if (idx < 0) {
                idx = len + idx;
            }
            if (idx >= 0 && idx < len) {
                result = theArray[idx];
            }
        }
        return result;
    }

    var getLength = (/*#__PURE__*/_unwrapProp(LENGTH));

    /*#__NO_SIDE_EFFECTS__*/
    function polyArrFill(theArray, value, start, end) {
        if (isArrayLike(theArray)) {
            var len = getLength(theArray);
            var startIdx = start === UNDEF_VALUE ? 0 : start;
            var endIdx = end === UNDEF_VALUE ? len : end;
            if (startIdx < 0) {
                startIdx = mathMax(len + startIdx, 0);
            }
            else {
                startIdx = mathMin(startIdx, len);
            }
            if (endIdx < 0) {
                endIdx = mathMax(len + endIdx, 0);
            }
            else {
                endIdx = mathMin(endIdx, len);
            }
            for (var i = startIdx; i < endIdx; i++) {
                theArray[i] = value;
            }
        }
        return theArray;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function polyArrFlatMap(theArray, callbackFn, thisArg) {
        _throwIfNullOrUndefined(theArray);
        if (!isFunction(callbackFn)) {
            throwTypeError("callbackFn must be a function");
        }
        var result = [];
        var callbackThis = arguments.length > 2 ? thisArg : undefined;
        arrForEach(theArray, function (theValue, index) {
            var value = fnCall(callbackFn, callbackThis, theValue, index, theArray);
            if (isArray(value)) {
                arrForEach(value, function (mappedValue) {
                    result.push(mappedValue);
                });
            }
            else {
                result.push(value);
            }
        });
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function polyArrWith(theArray, index, value) {
        var result;
        if (!isArrayLike(theArray)) {
            throwRangeError("Invalid array");
        }
        var len = getLength(theArray);
        var idx = index;
        if (idx < 0) {
            idx = len + idx;
        }
        if (idx < 0 || idx >= len) {
            throwRangeError("Index out of bounds");
        }
        result = arrSlice(theArray);
        result[idx] = value;
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function polyStrAt(value, index) {
        _throwIfNullOrUndefined(value);
        return polyArrAt(asString(value), mathToInt(index));
    }

    /*#__NO_SIDE_EFFECTS__*/
    function createIterableIterator(ctx) {
        var iterator = createIterator(ctx);
        var itSymbol = getKnownSymbol(3 );
        function _createIterator() {
            return iterator;
        }
        iterator[itSymbol] = _createIterator;
        return iterator;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function createIterator(ctx) {
        var isDone = false;
        function _value() {
            return ctx.v;
        }
        function _next() {
            if (!isDone) {
                isDone = (ctx.n ? ctx.n(arguments) : true);
            }
            var result = {
                done: isDone
            };
            if (!isDone) {
                objDefine(result, "value", { g: _value });
            }
            return result;
        }
        function _return(value) {
            isDone = true;
            return {
                done: true,
                value: ctx.r && ctx.r(value)
            };
        }
        function _throw(e) {
            isDone = true;
            return {
                done: true,
                value: ctx.t && ctx.t(e)
            };
        }
        var theIterator = {
            next: _next
        };
        if (ctx.r) {
            theIterator.return = _return;
        }
        if (ctx.t) {
            theIterator.throw = _throw;
        }
        return theIterator;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function _cloneRegExp(theRegex) {
        var flags = theRegex.flags;
        if (flags === undefined) {
            flags = EMPTY;
            theRegex.global && (flags += "g");
            theRegex.ignoreCase && (flags += "i");
            theRegex.multiline && (flags += "m");
            theRegex.dotAll && (flags += "s");
            theRegex.unicode && (flags += "u");
            theRegex.sticky && (flags += "y");
        }
        var result = new RegExp(theRegex.source, flags);
        result.lastIndex = mathMax(0, theRegex.lastIndex);
        return result;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _advanceStringIndex(value, index, unicode) {
        var newIndex = index + 1;
        if (unicode) {
            if (index < value.length) {
                var first = value.charCodeAt(index);
                if (first >= 0xD800 && first <= 0xDBFF) {
                    var second = value.charCodeAt(index + 1);
                    if (second >= 0xDC00 && second <= 0xDFFF) {
                        newIndex++;
                    }
                }
            }
        }
        return newIndex;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrMatchAll(value, matcher) {
        _throwIfNullOrUndefined(value);
        var result;
        var matchSym = getKnownSymbol(4 );
        var isMatcherRegExp = isRegExp(matcher)
            && (!matcher || isStrictNullOrUndefined(matcher[matchSym]) || matcher[matchSym] !== false);
        if (isMatcherRegExp && !matcher.global) {
            throwTypeError("matcher must be a global regular expression");
        }
        var theValue = asString(value);
        var matchAllFn = matcher && matcher[getKnownSymbol(5 )];
        if (isFunction(matchAllFn)) {
            result = matchAllFn.call(matcher, theValue);
        }
        else {
            var theRegex_1 = isMatcherRegExp ? _cloneRegExp(matcher) : new RegExp(matcher, "g");
            var ctx_1 = {
                n: function () {
                    var match = theRegex_1.exec(theValue);
                    if (!match) {
                        return true;
                    }
                    if (match[0] === EMPTY) {
                        theRegex_1.lastIndex = _advanceStringIndex(theValue, theRegex_1.lastIndex, !!theRegex_1.unicode);
                    }
                    ctx_1.v = match;
                    return false;
                },
                v: undefined
            };
            result = createIterableIterator(ctx_1);
        }
        return result;
    }

    (function () {
        var objectPolyfills = {
            "keys": polyObjKeys,
            "hasOwn": polyObjHasOwn,
            "is": polyObjIs,
            "isExtensible": polyObjIsExtensible,
            "isFrozen": polyObjIsFrozen,
            "isSealed": polyObjIsSealed,
            "fromEntries": polyObjFromEntries,
            "entries": polyObjEntries,
            "values": polyObjValues,
            "getOwnPropertyDescriptors": polyObjGetOwnPropertyDescriptors,
            GET_OWN_PROPERTY_NAMES: _polyObjGetOwnPropertyNames,
            GET_OWN_PROPERTY_SYMBOLS: _polyObjGetOwnPropertySymbols,
            "preventExtensions": polyObjPreventExtensions
        };
        var stringPolyfills = {
            "startsWith": polyStrStartsWith,
            "endsWith": polyStrEndsWith,
            "padStart": polyStrPadStart,
            "padEnd": polyStrPadEnd,
            "trim": polyStrTrim,
            "trimStart": polyStrTrimStart,
            "trimLeft": polyStrTrimStart,
            "trimEnd": polyStrTrimEnd,
            "trimRight": polyStrTrimEnd,
            "substr": polyStrSubstr,
            "includes": polyStrIncludes,
            "replaceAll": polyStrReplaceAll,
            "at": polyStrAt,
            "matchAll": polyStrMatchAll
        };
        var arrayClsPolyfills = {
            "isArray": polyIsArray,
            "from": polyArrFrom
        };
        var arrayPolyfills = {
            "at": polyArrAt,
            "fill": polyArrFill,
            "includes": polyArrIncludes,
            "find": polyArrFind,
            "findIndex": polyArrFindIndex,
            "findLast": polyArrFindLast,
            "findLastIndex": polyArrFindLastIndex,
            "flatMap": polyArrFlatMap,
            "with": polyArrWith
        };
        arrForEach(polyObjKeys(objectPolyfills), function (key) {
            if (!ObjClass[key]) {
                ObjClass[key] = makePolyFn(objectPolyfills[key]);
            }
        });
        arrForEach(polyObjKeys(arrayClsPolyfills), function (key) {
            if (!ArrCls[key]) {
                ArrCls[key] = makePolyFn(arrayClsPolyfills[key]);
            }
        });
        arrForEach(polyObjKeys(arrayPolyfills), function (key) {
            if (!ArrProto[key]) {
                ArrProto[key] = makePolyFn(arrayPolyfills[key]);
            }
        });
        arrForEach(polyObjKeys(stringPolyfills), function (key) {
            if (!StrProto[key]) {
                StrProto[key] = makePolyFn(stringPolyfills[key]);
            }
        });
    })();

    exports.polyArrAt = polyArrAt;
    exports.polyArrFill = polyArrFill;
    exports.polyArrFlatMap = polyArrFlatMap;
    exports.polyArrWith = polyArrWith;
    exports.polyStrReplaceAll = polyStrReplaceAll;

    return exports;

})({});
//# sourceMappingURL=ts-polyfills-utils.js.map
