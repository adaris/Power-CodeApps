/*! https://github.com/nevware21/ts-utils v0.15.0 */
/*
 * Copyright (c) NevWare21 Solutions LLC and contributors. All rights reserved.
 * Licensed under the MIT license.
 */
this.nevware21 = this.nevware21 || {};
this.nevware21["ts-utils"] = (function (exports) {
    'use strict';

    /*#__NO_SIDE_EFFECTS__*/
    function _pureAssign(func1, func2) {
        return func1 || func2;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _pureRef(value, name) {
        return value !== null && value !== undefined ? value[name] : undefined;
    }

    const UNDEF_VALUE = undefined;
    const NULL_VALUE = null;
    const EMPTY = "";
    const FUNCTION = "function";
    const OBJECT = "object";
    const PROTOTYPE = "prototype";
    const __PROTO__ = "__proto__";
    const UNDEFINED = "undefined";
    const CONSTRUCTOR = "constructor";
    const SYMBOL = "Symbol";
    const LENGTH = "length";
    const NAME = "name";
    const CALL = "call";
    const TO_STRING = "toString";
    const GET_OWN_PROPERTY_DESCRIPTOR = "getOwnPropertyDescriptor";
    const GET_OWN_PROPERTY_NAMES = "getOwnPropertyNames";
    const GET_OWN_PROPERTY_SYMBOLS = "getOwnPropertySymbols";
    const ObjClass = (/*#__PURE__*/_pureAssign(Object));
    const ObjProto = (/*#__PURE__*/_pureRef(ObjClass, PROTOTYPE));
    const StrCls = (/*#__PURE__*/_pureAssign(String));
    const StrProto = (/*#__PURE__*/_pureRef(StrCls, PROTOTYPE));
    const MathCls = (/*#__PURE__*/_pureAssign(Math));
    const ArrCls = (/*#__PURE__*/_pureAssign(Array));
    const ArrProto = (/*#__PURE__*/_pureRef(ArrCls, PROTOTYPE));
    const ArrSlice = (/*#__PURE__*/_pureRef(ArrProto, "slice"));
    const NumberCls = (/*#__PURE__*/_pureAssign(Number));
    const NumberProto = (/*#__PURE__*/_pureRef(NumberCls, PROTOTYPE));
    const FuncCls = (/*#__PURE__*/_pureAssign(Function));
    const FuncProto = (/*#__PURE__*/_pureRef(FuncCls, PROTOTYPE));
    const DateCls = (/*#__PURE__*/_pureAssign(Date));
    const DateProto = (/*#__PURE__*/_pureRef(DateCls, PROTOTYPE));
    const RegExpCls = (/*#__PURE__*/_pureAssign(RegExp));
    const RegExpProto = (/*#__PURE__*/_pureRef(RegExpCls, PROTOTYPE));
    const BooleanCls = (/*#__PURE__*/_pureAssign(Boolean));
    const BooleanProto = (/*#__PURE__*/_pureRef(BooleanCls, PROTOTYPE));
    const ErrorCls = (/*#__PURE__*/_pureAssign(Error));
    const ErrorProto = (/*#__PURE__*/_pureRef(ErrorCls, PROTOTYPE));

    const POLYFILL_TAG = "_polyfill";
    const POLYFILL_TYPE_NAME = "__nw21$polytype__";
    function _isPolyfill(obj) {
        return !!(obj && obj[POLYFILL_TAG]);
    }
    function _isPolyfillType(obj, polyfillTypeName) {
        return !!(obj && obj[POLYFILL_TYPE_NAME] === polyfillTypeName);
    }

    function safe(func, argArray) {
        try {
            return {
                v: func.apply(this, argArray)
            };
        }
        catch (e) {
            return { e };
        }
    }

    /*#__NO_SIDE_EFFECTS__*/
    function safeGet(cb, defValue, argArray) {
        let result = safe(cb, argArray);
        return result.e ? defValue : result.v;
    }

    let _primitiveTypes;
    /*#__NO_SIDE_EFFECTS__*/
    function _createIs(theType) {
        return function (value) {
            return typeof value === theType;
        };
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _createIsWithPoly(theType) {
        return function (value) {
            return typeof value === theType || _isPolyfillType(value, theType);
        };
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _createObjIs(theName) {
        const theType = "[object " + theName + "]";
        return function (value) {
            return !!(value && objToString(value) === theType);
        };
    }
    /*#__NO_SIDE_EFFECTS__*/
    function objToString(value) {
        return ObjProto[TO_STRING].call(value);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isTypeof(value, theType) {
        return typeof value === theType;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isUndefined(value) {
        return typeof value === UNDEFINED || value === UNDEFINED;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isStrictUndefined(arg) {
        return arg === UNDEF_VALUE;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isNullOrUndefined(value) {
        return value === NULL_VALUE || isUndefined(value);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isStrictNullOrUndefined(value) {
        return value === NULL_VALUE || value === UNDEF_VALUE;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isDefined(arg) {
        return !!arg || arg !== UNDEF_VALUE;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isPrimitive(value) {
        return value === NULL_VALUE || isPrimitiveType(typeof value);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isPrimitiveType(theType) {
        !_primitiveTypes && (_primitiveTypes = ["string", "number", "boolean", UNDEFINED, "symbol", "bigint"]);
        return !!(theType !== OBJECT && _primitiveTypes.indexOf(theType) !== -1);
    }
    const isString = (/*#__PURE__*/_createIs("string"));
    const isFunction = (/*#__PURE__*/_createIs(FUNCTION));
    const isAsyncFunction = (/*#__PURE__*/_createObjIs("AsyncFunction"));
    const isGenerator = (/*#__PURE__*/_createObjIs("GeneratorFunction"));
    const isAsyncGenerator = (/*#__PURE__*/_createObjIs("AsyncGeneratorFunction"));
    /*#__NO_SIDE_EFFECTS__*/
    function isObject(value) {
        if (!value && isNullOrUndefined(value)) {
            return false;
        }
        return !!value && typeof value === OBJECT;
    }
    const isArray = (/*#__PURE__*/_pureRef(ArrCls, "isArray"));
    /*#__NO_SIDE_EFFECTS__*/
    function isArrayLike(arg) {
        return !isStrictNullOrUndefined(arg) && !isFunction(arg) && isNumber(arg[LENGTH]) && arg[LENGTH] >= 0;
    }
    const isDate = (/*#__PURE__*/_createObjIs("Date"));
    const isNumber = (/*#__PURE__*/_createIs("number"));
    const isBoolean = (/*#__PURE__*/_createIs("boolean"));
    const isRegExp = (/*#__PURE__*/_createObjIs("RegExp"));
    const isFile = (/*#__PURE__*/_createObjIs("File"));
    const isFormData = (/*#__PURE__*/_createObjIs("FormData"));
    const isBlob = (/*#__PURE__*/_createObjIs("Blob"));
    const isArrayBuffer = (/*#__PURE__*/_createObjIs("ArrayBuffer"));
    const isError = (/*#__PURE__*/_createObjIs("Error"));
    /*#__NO_SIDE_EFFECTS__*/
    function isPromiseLike(value) {
        return !!(value && value.then && isFunction(value.then));
    }
    const isThenable = isPromiseLike;
    /*#__NO_SIDE_EFFECTS__*/
    function isPromise(value) {
        return !!(value && value.then && value.catch && isFunction(value.then) && isFunction(value.catch));
    }
    const isMap = (/*#__PURE__*/_createObjIs("Map"));
    const isWeakMap = (/*#__PURE__*/_createObjIs("WeakMap"));
    const isSet = (/*#__PURE__*/_createObjIs("Set"));
    const isWeakSet = (/*#__PURE__*/_createObjIs("WeakSet"));
    /*#__NO_SIDE_EFFECTS__*/
    function isMapLike(value) {
        return !!(value &&
            isFunction(value.get) &&
            isFunction(value.set) &&
            isFunction(value.has) &&
            isFunction(value.delete) &&
            isNumber(value.size));
    }
    function isSetLike(value) {
        return !!(value &&
            isFunction(value.add) &&
            isFunction(value.has) &&
            isFunction(value.delete) &&
            isNumber(value.size));
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isNotTruthy(value) {
        return !value || !isTruthy(value);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isTruthy(value) {
        return !(!value || safeGet(() => !(value && (0 + value)), !value));
    }
    const isBigInt = (/*#__PURE__*/_createIsWithPoly("bigint"));

    function _returnNothing() {
        return;
    }
    function _returnEmptyArray() {
        return [];
    }
    function _returnFalse() {
        return false;
    }

    const asString = (/*#__PURE__*/_pureAssign(StrCls));

    const ERROR_TYPE = "[object Error]";
    /*#__NO_SIDE_EFFECTS__*/
    function dumpObj(object, format) {
        let propertyValueDump = EMPTY;
        const objType = ObjProto[TO_STRING][CALL](object);
        if (objType === ERROR_TYPE) {
            object = { stack: asString(object.stack), message: asString(object.message), name: asString(object.name) };
        }
        try {
            propertyValueDump = JSON.stringify(object, NULL_VALUE, format ? ((typeof format === "number") ? format : 4) : UNDEF_VALUE);
            propertyValueDump = (propertyValueDump ? propertyValueDump.replace(/"(\w+)"\s*:\s{0,1}/g, "$1: ") : NULL_VALUE) || asString(object);
        }
        catch (e) {
            propertyValueDump = " - " + dumpObj(e, format);
        }
        return objType + ": " + propertyValueDump;
    }

    function throwError(message) {
        throw new Error(message);
    }
    function throwTypeError(message) {
        throw new TypeError(message);
    }
    function throwRangeError(message) {
        throw new RangeError(message);
    }

    function _throwIfNullOrUndefined(obj) {
        if (isStrictNullOrUndefined(obj)) {
            throwTypeError("Cannot convert undefined or null to object");
        }
    }
    function _throwIfNotString(value) {
        if (!isString(value)) {
            throwTypeError("'" + dumpObj(value) + "' is not a string");
        }
    }

    /*#__NO_SIDE_EFFECTS__*/
    function objHasOwnProperty(obj, prop) {
        return !!obj && ObjProto.hasOwnProperty[CALL](obj, prop);
    }

    const _objGetOwnPropertyDescriptor$2 = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, GET_OWN_PROPERTY_DESCRIPTOR)), _returnNothing));
    const objHasOwn = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, "hasOwn")), polyObjHasOwn));
    /*#__NO_SIDE_EFFECTS__*/
    function polyObjHasOwn(obj, prop) {
        _throwIfNullOrUndefined(obj);
        return objHasOwnProperty(obj, prop) || !!_objGetOwnPropertyDescriptor$2(obj, prop);
    }

    /*#__NO_SIDE_EFFECTS__*/
    function isUnsafePropKey(key) {
        return key === __PROTO__ || key === CONSTRUCTOR || key === PROTOTYPE;
    }

    function objForEachKey(theObject, callbackfn, thisArg) {
        if (theObject && (isObject(theObject) || isFunction(theObject))) {
            for (const prop in theObject) {
                if (objHasOwn(theObject, prop)) {
                    if (callbackfn[CALL](isStrictNullOrUndefined(thisArg) ? theObject : thisArg, prop, theObject[prop]) === -1) {
                        break;
                    }
                }
            }
        }
    }
    function objForEachKeySafe(theObject, callbackfn, thisArg) {
        objForEachKey(theObject, (key, value) => {
            if (!isUnsafePropKey(key)) {
                return callbackfn[CALL](isStrictNullOrUndefined(thisArg) ? theObject : thisArg, key, value);
            }
        }, thisArg);
    }

    function arrForEach(theArray, callbackfn, thisArg) {
        if (theArray) {
            const len = theArray[LENGTH] >>> 0;
            for (let idx = 0; idx < len; idx++) {
                if (idx in theArray) {
                    if (callbackfn[CALL](isStrictNullOrUndefined(thisArg) ? theArray : thisArg, theArray[idx], idx, theArray) === -1) {
                        break;
                    }
                }
            }
        }
    }

    const _unwrapFunction = _unwrapFunctionWithPoly;
    /*#__NO_SIDE_EFFECTS__*/
    function _unwrapFunctionWithPoly(funcName, clsProto, polyFunc) {
        let clsFn = clsProto ? clsProto[funcName] : NULL_VALUE;
        return function (thisArg) {
            let theFunc = (thisArg ? thisArg[funcName] : NULL_VALUE) || clsFn;
            if (theFunc || polyFunc) {
                let theArgs = arguments;
                return (theFunc || polyFunc).apply(thisArg, theFunc ? ArrSlice[CALL](theArgs, 1) : theArgs);
            }
            throwTypeError("\"" + asString(funcName) + "\" not defined for " + dumpObj(thisArg));
        };
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _unwrapFunctionNoInstWithPoly(funcName, clsProto, polyFunc) {
        let clsFn = clsProto ? clsProto[funcName] : NULL_VALUE;
        return function (thisArg) {
            let theFunc = clsFn;
            if (theFunc || polyFunc) {
                let theArgs = arguments;
                return (theFunc || polyFunc).apply(thisArg, theFunc ? ArrSlice[CALL](theArgs, 1) : theArgs);
            }
            throwTypeError("\"" + asString(funcName) + "\" not defined for " + dumpObj(thisArg));
        };
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _unwrapProp(propName) {
        return function (thisArg) {
            return thisArg[propName];
        };
    }

    function _objPropertyIsEnum(obj, propKey) {
        let desc;
        let fn = ObjClass.getOwnPropertyDescriptor;
        if (!isStrictNullOrUndefined(obj) && fn) {
            desc = safe(fn, [obj, propKey]).v || NULL_VALUE;
        }
        if (!desc && !isStrictNullOrUndefined(obj)) {
            desc = safe(() => {
                for (const key in obj) {
                    if (key == propKey) {
                        return { enumerable: objHasOwnProperty(obj, key) };
                    }
                }
            }).v;
        }
        return (desc && desc.enumerable) || false;
    }
    const objPropertyIsEnumerable = (/*#__PURE__*/_unwrapFunctionWithPoly("propertyIsEnumerable", NULL_VALUE, _objPropertyIsEnum));
    const _objPropertyIsEnumerable = (/*#__PURE__*/_unwrapFunctionNoInstWithPoly("propertyIsEnumerable", ObjProto, _objPropertyIsEnum));

    const _objGetOwnPropertyDescriptor$1 = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, GET_OWN_PROPERTY_DESCRIPTOR)), _returnNothing));
    const _objGetOwnPropertySymbols = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, GET_OWN_PROPERTY_SYMBOLS)), _returnEmptyArray));
    const propMap = {
        e: "enumerable",
        c: "configurable",
        v: "value",
        w: "writable",
        g: "get",
        s: "set"
    };
    /*#__NO_SIDE_EFFECTS__*/
    function _createProp(value) {
        let prop = {};
        prop[propMap["c"]] = true;
        prop[propMap["e"]] = true;
        if (value.l) {
            prop.get = () => value.l.v;
            let desc = _objGetOwnPropertyDescriptor$1(value.l, "v");
            if (desc && desc.set) {
                prop.set = (newValue) => {
                    value.l.v = newValue;
                };
            }
        }
        objForEachKey(value, (key, value) => {
            prop[propMap[key]] = isStrictUndefined(value) ? prop[propMap[key]] : value;
        });
        return prop;
    }
    const objDefineProp = (/*#__PURE__*/_pureRef(ObjClass, "defineProperty"));
    const objDefineProperties = (/*#__PURE__*/_pureRef(ObjClass, "defineProperties"));
    function objDefineGet(target, key, value, configurable, enumerable) {
        return objDefineProp(target, key, _createProp({
            e: enumerable,
            c: configurable,
            [isFunction(value) ? "g" : "v"]: value
        }));
    }
    function objDefineAccessors(target, prop, getProp, setProp, configurable, enumerable) {
        let desc = {
            e: enumerable,
            c: configurable
        };
        if (getProp) {
            desc.g = getProp;
        }
        if (setProp) {
            desc.s = setProp;
        }
        return objDefineProp(target, prop, _createProp(desc));
    }
    function objDefine(target, key, propDesc) {
        return objDefineProp(target, key, _createProp(propDesc));
    }
    function objDefineProps(target, propDescMap) {
        let props = {};
        objForEachKey(propDescMap, (key, value) => {
            props[key] = _createProp(value);
        });
        arrForEach(_objGetOwnPropertySymbols(propDescMap), (sym) => {
            if (_objPropertyIsEnumerable(propDescMap, sym)) {
                props[sym] = _createProp(propDescMap[sym]);
            }
        });
        return objDefineProperties(target, props);
    }

    /*#__NO_SIDE_EFFECTS__*/
    function _createKeyValueMap(values, keyType, valueType, completeFn, writable) {
        let theMap = {};
        objForEachKey(values, (key, value) => {
            _assignMapValue(theMap, key, keyType ? value : key);
            _assignMapValue(theMap, value, valueType ? value : key);
        });
        return completeFn ? completeFn(theMap) : theMap;
    }
    function _assignMapValue(theMap, key, value, writable) {
        objDefineProp(theMap, key, {
            value: value,
            enumerable: true,
            writable: false
        });
    }

    function _objIterateEntries(obj, mapper) {
        const result = [];
        objForEachKey(obj, (key, val) => {
            result.push(mapper(key, val));
        });
        return result;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyObjKeys(obj) {
        _throwIfNullOrUndefined(obj);
        if (!isObject(obj)) {
            throwTypeError("non-object " + dumpObj(obj));
        }
        return _objIterateEntries(obj, (k, _) => k);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyObjEntries(value) {
        return _objIterateEntries(value, (k, v) => [k, v]);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyObjValues(value) {
        return _objIterateEntries(value, (_, v) => v);
    }

    function polyObjIs(value1, value2) {
        if (value1 !== value1) {
            return value2 !== value2;
        }
        if (value1 === 0 && value2 === 0) {
            return 1 / value1 === 1 / value2;
        }
        return value1 === value2;
    }

    const objIsFrozen = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, "isFrozen")), _returnFalse));
    const objIsSealed = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, "isSealed")), _returnFalse));

    const _objFreeze = (/*#__PURE__*/_pureRef(ObjClass, "freeze"));
    function _doNothing(value) {
        return value;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _getProto(value) {
        _throwIfNullOrUndefined(value);
        return value[__PROTO__] || NULL_VALUE;
    }
    const objAssign = (/*#__PURE__*/_pureRef(ObjClass, "assign"));
    const objKeys = (/*#__PURE__*/_pureRef(ObjClass, "keys"));
    function _deepFreeze(val, visited) {
        if ((isArray(val) || isObject(val) || isFunction(val)) && !objIsFrozen(val)) {
            for (let lp = 0; lp < visited.length; lp++) {
                if (visited[lp] === val) {
                    return val;
                }
            }
            visited.push(val);
            objForEachKey(val, (_key, propValue) => {
                _deepFreeze(propValue, visited);
            });
            objFreeze(val);
        }
        return val;
    }
    function objDeepFreeze(value) {
        return _objFreeze ? _deepFreeze(value, []) : value;
    }
    const objFreeze = (/*#__PURE__*/_pureAssign(_objFreeze, _doNothing));
    const objSeal = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, "seal")), _doNothing));
    const objGetPrototypeOf = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, "getPrototypeOf")), _getProto));
    const objEntries = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, "entries")), polyObjEntries));
    const objValues = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, "values")), polyObjValues));
    const objIs = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, "is")), polyObjIs));

    /*#__NO_SIDE_EFFECTS__*/
    function createEnum(values) {
        return _createKeyValueMap(values, 1 , 0 , objFreeze);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function createEnumKeyMap(values) {
        return _createKeyValueMap(values, 0 , 0 , objFreeze);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function createEnumValueMap(values) {
        return _createKeyValueMap(values, 1 , 1 , objFreeze);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function createSimpleMap(values) {
        let mapClass = {};
        objForEachKey(values, (key, value) => {
            _assignMapValue(mapClass, key, value[1]);
            _assignMapValue(mapClass, value[0], value[1]);
        });
        return objFreeze(mapClass);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function createTypeMap(values) {
        return createSimpleMap(values);
    }

    const _wellKnownSymbolMap = (/*#__PURE__*/createEnumKeyMap({
        asyncIterator: 0 ,
        hasInstance: 1 ,
        isConcatSpreadable: 2 ,
        iterator: 3 ,
        match: 4 ,
        matchAll: 5 ,
        replace: 6 ,
        search: 7 ,
        species: 8 ,
        split: 9 ,
        toPrimitive: 10 ,
        toStringTag: 11 ,
        unscopables: 12
    }));

    const GLOBAL_CONFIG_KEY = "__tsUtils$gblCfg";
    let _globalCfg;
    /*#__NO_SIDE_EFFECTS__*/
    function _getGlobalValue() {
        var result;
        if (typeof globalThis !== UNDEFINED) {
            result = globalThis;
        }
        if (!result && typeof self !== UNDEFINED) {
            result = self;
        }
        if (!result && typeof window !== UNDEFINED) {
            result = window;
        }
        if (!result && typeof global !== UNDEFINED) {
            result = global;
        }
        return result;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _getGlobalConfig() {
        if (!_globalCfg) {
            let gbl = safe(_getGlobalValue).v || {};
            _globalCfg = gbl[GLOBAL_CONFIG_KEY] = gbl[GLOBAL_CONFIG_KEY] || {};
        }
        return _globalCfg;
    }

    const mathMin = (/*#__PURE__*/_pureRef(MathCls, "min"));
    const mathMax = (/*#__PURE__*/_pureRef(MathCls, "max"));

    const strSlice = (/*#__PURE__*/_unwrapFunction("slice", StrProto));

    const strSubstring = (/*#__PURE__*/_unwrapFunction("substring", StrProto));
    const strSubstr = (/*#__PURE__*/_unwrapFunctionWithPoly("substr", StrProto, polyStrSubstr));
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrSubstr(value, start, length) {
        _throwIfNullOrUndefined(value);
        if (length < 0) {
            return EMPTY;
        }
        start = start || 0;
        if (start < 0) {
            start = mathMax(start + value[LENGTH], 0);
        }
        if (isUndefined(length)) {
            return strSlice(value, start);
        }
        return strSlice(value, start, start + length);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function strLeft(value, count) {
        return strSubstring(value, 0, count);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function strRight(value, count) {
        return count <= 0 ? EMPTY : (value[LENGTH] > count ? strSlice(value, -count) : value);
    }

    function _tagAsPolyfill(target, polyfillTypeName) {
        if (target) {
            safe(() => {
                target[POLYFILL_TAG] = true;
                target[POLYFILL_TYPE_NAME] = polyfillTypeName;
            });
            safe(objDefine, [target, POLYFILL_TAG, {
                    v: true,
                    w: false,
                    e: false
                }]);
            safe(objDefine, [target, POLYFILL_TYPE_NAME, {
                    v: polyfillTypeName,
                    w: false,
                    e: false
                }]);
        }
        return target;
    }

    const objCreate = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, "create")), polyObjCreate));
    /*#__NO_SIDE_EFFECTS__*/
    function polyObjCreate(obj, properties) {
        let newObj = null;
        function tempFunc() { }
        if (!isStrictNullOrUndefined(obj)) {
            let type = typeof obj;
            if (type !== OBJECT && type !== FUNCTION) {
                throwTypeError("Prototype must be an Object or function: " + dumpObj(obj));
            }
            tempFunc[PROTOTYPE] = obj;
            safe(() => {
                tempFunc[__PROTO__] = obj;
            });
            newObj = new tempFunc();
        }
        else {
            newObj = {};
        }
        if (properties) {
            safe(objDefineProperties, [newObj, properties]);
        }
        return newObj;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function utcNow() {
        return (Date.now || polyUtcNow)();
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyUtcNow() {
        return new Date().getTime();
    }

    function fnApply(fn, thisArg, argArray) {
        return fn.apply(thisArg, argArray);
    }
    function fnCall(fn, thisArg) {
        return fn.apply(thisArg, ArrSlice[CALL](arguments, 2));
    }
    /*#__NO_SIDE_EFFECTS__*/
    function fnBind(fn, thisArg) {
        return fn.bind.apply(fn, ArrSlice[CALL](arguments, 1));
    }

    let _globalLazyTestHooks;
    function _initTestHooks() {
        _globalLazyTestHooks = _getGlobalConfig();
    }
    /*#__NO_SIDE_EFFECTS__*/
    function getLazy(cb, argArray) {
        let lazyValue = {};
        !_globalLazyTestHooks && _initTestHooks();
        lazyValue.b = _globalLazyTestHooks.lzy;
        objDefineProp(lazyValue, "v", {
            configurable: true,
            get: function () {
                let result = fnApply(cb, null, argArray);
                if (!_globalLazyTestHooks.lzy) {
                    objDefineProp(lazyValue, "v", {
                        value: result
                    });
                }
                lazyValue.b = _globalLazyTestHooks.lzy;
                return result;
            }
        });
        return lazyValue;
    }
    function setBypassLazyCache(newValue) {
        !_globalLazyTestHooks && _initTestHooks();
        _globalLazyTestHooks.lzy = newValue;
    }
    function getWritableLazy(cb, argArray) {
        let lazyValue = {};
        !_globalLazyTestHooks && _initTestHooks();
        lazyValue.b = _globalLazyTestHooks.lzy;
        let _setValue = (newValue) => {
            objDefineProp(lazyValue, "v", {
                value: newValue,
                writable: true
            });
            if (lazyValue.b) {
                delete lazyValue.b;
            }
        };
        objDefineProp(lazyValue, "v", {
            configurable: true,
            get: function () {
                let result = fnApply(cb, null, argArray);
                if (!_globalLazyTestHooks.lzy) {
                    _setValue(result);
                }
                if (_globalLazyTestHooks.lzy && lazyValue.b !== _globalLazyTestHooks.lzy) {
                    lazyValue.b = _globalLazyTestHooks.lzy;
                }
                return result;
            },
            set: _setValue
        });
        return lazyValue;
    }

    const mathRandom = (/*#__PURE__*/_pureRef(MathCls, "random"));

    let _uniqueInstanceId = (/*#__PURE__*/getLazy(() => {
        let value = (utcNow().toString(36).slice(2));
        while (value.length < 16) {
            value += mathRandom().toString(36).slice(2);
        }
        value = value.substring(0, 16);
        return value;
    }));

    const UNIQUE_REGISTRY_ID = "_urid";
    const POLY_SYM = "$nw21sym";
    let _polySymbols;
    let _polyId = 0;
    /*#__NO_SIDE_EFFECTS__*/
    function _globalSymbolRegistry() {
        if (!_polySymbols) {
            let gblCfg = _getGlobalConfig();
            _polySymbols = gblCfg.gblSym = gblCfg.gblSym || { k: {}, s: {} };
        }
        return _polySymbols;
    }
    let _wellKnownSymbolCache;
    /*#__NO_SIDE_EFFECTS__*/
    function polyNewSymbol(description) {
        const uniqueId = "_" + _polyId++ + "_" + _uniqueInstanceId.v;
        const symString = SYMBOL + "(" + description + ")";
        function _setProp(name, value) {
            objDefine(theSymbol, name, {
                v: value,
                e: false,
                w: false
            });
        }
        let theSymbol = objCreate(null);
        _setProp("description", asString(description));
        _setProp(TO_STRING, () => symString + POLY_SYM + uniqueId);
        _setProp("valueOf", () => theSymbol);
        _setProp("v", symString);
        _setProp("_uid", uniqueId);
        return _tagAsPolyfill(theSymbol, "symbol");
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polySymbolFor(key) {
        let registry = _globalSymbolRegistry();
        if (!objHasOwn(registry.k, key)) {
            let newSymbol = polyNewSymbol(key);
            let regId = objKeys(registry.s).length;
            newSymbol[UNIQUE_REGISTRY_ID] = () => regId + "_" + newSymbol[TO_STRING]();
            registry.k[key] = newSymbol;
            registry.s[newSymbol[UNIQUE_REGISTRY_ID]()] = asString(key);
        }
        return registry.k[key];
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polySymbolKeyFor(sym) {
        if (!sym || !sym[TO_STRING] || strSubstring(sym[TO_STRING](), 0, 6) != SYMBOL) {
            throwTypeError(sym + " is not a symbol");
        }
        const regId = _isPolyfill(sym) && sym[UNIQUE_REGISTRY_ID] && sym[UNIQUE_REGISTRY_ID]();
        return regId ? _globalSymbolRegistry().s[regId] : undefined;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyGetKnownSymbol(name) {
        !_wellKnownSymbolCache && (_wellKnownSymbolCache = {});
        let result;
        let knownName = _wellKnownSymbolMap[name];
        if (knownName) {
            result = _wellKnownSymbolCache[knownName] = _wellKnownSymbolCache[knownName] || polyNewSymbol(SYMBOL + "." + knownName);
        }
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function createCachedValue(value) {
        return objDefineProp({
            toJSON: () => value
        }, "v", { value });
    }
    const createDeferredCachedValue = getDeferred;
    /*#__NO_SIDE_EFFECTS__*/
    function getDeferred(cb, argArray) {
        let theValue = {
            toJSON: () => theValue.v
        };
        return objDefineProp(theValue, "v", {
            get: () => {
                let result = fnApply(cb, null, argArray);
                cb = NULL_VALUE;
                objDefineProp(theValue, "v", { value: result });
                return result;
            },
            configurable: true
        });
    }
    /*#__NO_SIDE_EFFECTS__*/
    function getWritableDeferred(cb, argArray) {
        let theValue = {
            toJSON: () => theValue.v
        };
        let _setValue = (newValue) => {
            objDefineProp(theValue, "v", {
                value: newValue,
                writable: true
            });
        };
        return objDefineProp(theValue, "v", {
            get: () => {
                let result = fnApply(cb, null, argArray);
                _setValue(result);
                cb = NULL_VALUE;
                return result;
            },
            set: _setValue,
            configurable: true
        });
    }

    const WINDOW = "window";
    let _cachedGlobal;
    function _getGlobalInstFn(getFn, theArgs) {
        let cachedValue;
        return function () {
            !_globalLazyTestHooks && _initTestHooks();
            if (!cachedValue || _globalLazyTestHooks.lzy) {
                cachedValue = createCachedValue(safe(getFn, theArgs).v);
            }
            return cachedValue.v;
        };
    }
    /*#__NO_SIDE_EFFECTS__*/
    function lazySafeGetInst(name) {
        return getLazy(() => safe((getInst), [name]).v || UNDEF_VALUE);
    }
    function getGlobal(useCached) {
        !_globalLazyTestHooks && _initTestHooks();
        if (!_cachedGlobal || useCached === false || _globalLazyTestHooks.lzy) {
            _cachedGlobal = createCachedValue(safe(_getGlobalValue).v || NULL_VALUE);
        }
        return _cachedGlobal.v;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function getInst(name, useCached) {
        let gbl;
        if (!_cachedGlobal || useCached === false) {
            gbl = getGlobal(useCached);
        }
        else {
            gbl = _cachedGlobal.v;
        }
        if (gbl && gbl[name]) {
            return gbl[name];
        }
        if (name === WINDOW) {
            try {
                return window;
            }
            catch (e) {
            }
        }
        return NULL_VALUE;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function hasDocument() {
        return !!getDocument();
    }
    const getDocument = (/*#__PURE__*/_getGlobalInstFn(getInst, ["document"]));
    /*#__NO_SIDE_EFFECTS__*/
    function hasWindow() {
        return !!getWindow();
    }
    const getWindow = (/*#__PURE__*/_getGlobalInstFn(getInst, [WINDOW]));
    /*#__NO_SIDE_EFFECTS__*/
    function hasNavigator() {
        return !!getNavigator();
    }
    const getNavigator = (/*#__PURE__*/_getGlobalInstFn(getInst, ["navigator"]));
    /*#__NO_SIDE_EFFECTS__*/
    function hasHistory() {
        return !!getHistory();
    }
    const getHistory = (/*#__PURE__*/_getGlobalInstFn(getInst, ["history"]));
    const isNode = (/*#__PURE__*/_getGlobalInstFn(() => {
        return !!safe(() => {
            let processInst = getInst("process");
            return processInst && (processInst.versions || {}).node;
        }).v;
    }));
    const isWebWorker = (/*#__PURE__*/_getGlobalInstFn(() => {
        return !!safe(() => self && self instanceof WorkerGlobalScope).v;
    }));
    const getQueueMicrotask = (/*#__PURE__*/_getGlobalInstFn(getInst, ["queueMicrotask"]));
    /*#__NO_SIDE_EFFECTS__*/
    function hasQueueMicrotask() {
        return !!(/*#__PURE__*/getQueueMicrotask());
    }

    let _symbol;
    let _symbolFor;
    let _symbolKeyFor;
    /*#__NO_SIDE_EFFECTS__*/
    function _initSymbol() {
        _symbol = (/*#__PURE__*/createCachedValue(safe((getInst), [SYMBOL]).v));
        return _symbol;
    }
    function _getSymbolKey(key) {
        let gblSym = ((!_globalLazyTestHooks.lzy ? _symbol : 0) || _initSymbol());
        return (gblSym.v ? gblSym.v[key] : UNDEF_VALUE);
    }
    const isSymbol = (/*#__PURE__*/_createIsWithPoly("symbol"));
    /*#__NO_SIDE_EFFECTS__*/
    function hasSymbol() {
        return !!getSymbol();
    }
    /*#__NO_SIDE_EFFECTS__*/
    function getSymbol() {
        !_globalLazyTestHooks && _initTestHooks();
        return ((!_globalLazyTestHooks.lzy ? _symbol : 0) || _initSymbol()).v;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function getKnownSymbol(name, noPoly) {
        let knownName = _wellKnownSymbolMap[name];
        !_globalLazyTestHooks && _initTestHooks();
        let sym = ((!_globalLazyTestHooks.lzy ? _symbol : 0) || _initSymbol());
        return sym.v ? sym.v[knownName || name] : (!noPoly ? polyGetKnownSymbol(name) : UNDEF_VALUE);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function newSymbol(description, noPoly) {
        !_globalLazyTestHooks && _initTestHooks();
        let sym = ((!_globalLazyTestHooks.lzy ? _symbol : 0) || _initSymbol());
        return sym.v ? sym.v(description) : (!noPoly ? polyNewSymbol(description) : NULL_VALUE);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function symbolFor(key) {
        !_globalLazyTestHooks && _initTestHooks();
        _symbolFor = ((!_globalLazyTestHooks.lzy ? _symbolFor : 0) || (/*#__PURE__*/createCachedValue(safe((_getSymbolKey), ["for"]).v)));
        return (_symbolFor.v || polySymbolFor)(key);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function symbolKeyFor(sym) {
        !_globalLazyTestHooks && _initTestHooks();
        _symbolKeyFor = ((!_globalLazyTestHooks.lzy ? _symbolKeyFor : 0) || (/*#__PURE__*/createCachedValue(safe((_getSymbolKey), ["keyFor"]).v)));
        return (_symbolKeyFor.v || polySymbolKeyFor)(sym);
    }

    /*#__NO_SIDE_EFFECTS__*/
    function isIterator(value) {
        return !!value && isFunction(value.next);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isIterable(value) {
        return !isStrictNullOrUndefined(value) && isFunction(value[getKnownSymbol(3 )]);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isAsyncIterable(value) {
        return !isStrictNullOrUndefined(value) && isFunction(value[getKnownSymbol(0 )]);
    }

    let _iterSymbol$1;
    function iterForOf(iter, callbackfn, thisArg) {
        if (iter) {
            if (!isIterator(iter)) {
                !_iterSymbol$1 && (_iterSymbol$1 = createCachedValue(getKnownSymbol(3 )));
                iter = iter[_iterSymbol$1.v] ? iter[_iterSymbol$1.v]() : NULL_VALUE;
            }
            if (isIterator(iter)) {
                let err = UNDEF_VALUE;
                let iterResult = UNDEF_VALUE;
                try {
                    let count = 0;
                    while (!(iterResult = iter.next()).done) {
                        if (callbackfn[CALL](isStrictNullOrUndefined(thisArg) ? iter : thisArg, iterResult.value, count, iter) === -1) {
                            break;
                        }
                        count++;
                    }
                }
                catch (failed) {
                    err = { e: failed };
                    if (iter.throw) {
                        iterResult = NULL_VALUE;
                        iter.throw(err);
                    }
                }
                finally {
                    try {
                        if (iterResult && !iterResult.done) {
                            iter.return && iter.return(iterResult);
                        }
                    }
                    finally {
                        if (err) {
                            throw err.e;
                        }
                    }
                }
            }
        }
    }

    function arrAppend(target, elms) {
        if (!isUndefined(elms) && target) {
            if (isArray(elms)) {
                fnApply(target.push, target, elms);
            }
            else if (isIterator(elms) || isIterable(elms)) {
                iterForOf(elms, (elm) => {
                    target.push(elm);
                });
            }
            else {
                target.push(elms);
            }
        }
        return target;
    }

    const arrConcat = (/*#__PURE__*/_unwrapFunction("concat", ArrProto));

    const arrAt = /*#__PURE__*/ _unwrapFunctionWithPoly("at", ArrProto, polyArrAt);
    /*#__NO_SIDE_EFFECTS__*/
    function polyArrAt(theArray, index) {
        let result;
        if (isArrayLike(theArray)) {
            const len = theArray.length;
            let idx = index;
            if (idx < 0) {
                idx = len + idx;
            }
            if (idx >= 0 && idx < len) {
                result = theArray[idx];
            }
        }
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function arrToMap(values, keySelector, valueSelector) {
        let result = {};
        function _processValue(value, index) {
            let valueIndex = index || 0;
            let key = keySelector(value, valueIndex);
            let keyValue = key + "";
            if (!isUnsafePropKey(keyValue)) {
                result[keyValue] = valueSelector ? valueSelector(value, valueIndex) : value;
            }
        }
        if (isArrayLike(values)) {
            arrForEach(values, _processValue);
        }
        else {
            iterForOf(values, _processValue);
        }
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function arrChunk(theArray, size) {
        const result = [];
        if (isArrayLike(theArray) && size > 0) {
            let idx = 0;
            let chunkIdx = -1;
            arrForEach(theArray, (item) => {
                if (idx % size === 0) {
                    result.push([]);
                    chunkIdx++;
                }
                result[chunkIdx].push(item);
                idx++;
            });
        }
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function arrCompact(theArray) {
        const result = [];
        if (isArrayLike(theArray)) {
            arrForEach(theArray, (item) => {
                if (item) {
                    result.push(item);
                }
            });
        }
        return result;
    }

    const arrIndexOf = (/*#__PURE__*/_unwrapFunction("indexOf", ArrProto));
    const arrLastIndexOf = (/*#__PURE__*/_unwrapFunction("lastIndexOf", ArrProto));

    const arrMap = (/*#__PURE__*/_unwrapFunction("map", ArrProto));

    function arrSlice(theArray, start, end) {
        return ((theArray ? theArray["slice"] : NULL_VALUE) || ArrSlice).apply(theArray, ArrSlice[CALL](arguments, 1));
    }

    /*#__NO_SIDE_EFFECTS__*/
    function polyIsArray(value) {
        if (isNullOrUndefined(value)) {
            return false;
        }
        return objToString(value) === "[object Array]";
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyArrIncludes(theArray, searchElement, fromIndex) {
        return arrIndexOf(theArray, searchElement, fromIndex) !== -1;
    }
    function polyArrFind(theArray, callbackFn, thisArg) {
        let result;
        let idx = polyArrFindIndex(theArray, callbackFn, thisArg);
        return idx !== -1 ? theArray[idx] : result;
    }
    function polyArrFindIndex(theArray, callbackFn, thisArg) {
        let result = -1;
        arrForEach(theArray, (value, index) => {
            if (callbackFn[CALL](isStrictNullOrUndefined(thisArg) ? theArray : thisArg, value, index, theArray)) {
                result = index;
                return -1;
            }
        });
        return result;
    }
    function polyArrFindLast(theArray, callbackFn, thisArg) {
        let result;
        let idx = polyArrFindLastIndex(theArray, callbackFn, thisArg);
        return idx !== -1 ? theArray[idx] : result;
    }
    function polyArrFindLastIndex(theArray, callbackFn, thisArg) {
        let result = -1;
        let len = theArray[LENGTH] >>> 0;
        for (let idx = len - 1; idx >= 0; idx--) {
            if (idx in theArray && callbackFn[CALL](isStrictNullOrUndefined(thisArg) ? theArray : thisArg, theArray[idx], idx, theArray)) {
                result = idx;
                break;
            }
        }
        return result;
    }
    function polyArrFrom(theValue, mapFn, thisArg) {
        if (isArray(theValue)) {
            let result = arrSlice(theValue);
            return mapFn ? arrMap(result, mapFn, thisArg) : result;
        }
        let result = [];
        iterForOf(theValue, (value, cnt) => {
            return result.push(mapFn ? mapFn[CALL](thisArg, value, cnt) : value);
        });
        return result;
    }

    const arrIncludes = (/*#__PURE__*/_unwrapFunctionWithPoly("includes", ArrProto, polyArrIncludes));
    const arrContains = arrIncludes;

    /*#__NO_SIDE_EFFECTS__*/
    function arrDifference(theArray, ...excludeArrays) {
        let result = [];
        if (isArrayLike(theArray)) {
            arrForEach(theArray, (item) => {
                let excluded = false;
                for (let lp = 0; lp < excludeArrays.length; lp++) {
                    let exclValue = excludeArrays[lp];
                    if (isArrayLike(exclValue) && arrIncludes(exclValue, item)) {
                        excluded = true;
                        break;
                    }
                }
                if (!excluded) {
                    result.push(item);
                }
            });
        }
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function arrDrop(theArray, count) {
        return arrSlice(theArray, mathMax(0, count));
    }

    /*#__NO_SIDE_EFFECTS__*/
    function arrDropWhile(theArray, callbackFn, thisArg) {
        let result;
        if (isArrayLike(theArray)) {
            arrForEach(theArray, (item, index) => {
                if (!fnCall(callbackFn, thisArg, item, index, theArray)) {
                    result = arrSlice(theArray, index);
                    return -1;
                }
            });
        }
        return result || [];
    }

    const arrEvery = /*#__PURE__*/ _unwrapFunction("every", ArrProto);
    const arrFilter = /*#__PURE__*/ _unwrapFunction("filter", ArrProto);

    const getLength = (/*#__PURE__*/_unwrapProp(LENGTH));

    const arrFill = /*#__PURE__*/ _unwrapFunctionWithPoly("fill", ArrProto, polyArrFill);
    /*#__NO_SIDE_EFFECTS__*/
    function polyArrFill(theArray, value, start, end) {
        if (isArrayLike(theArray)) {
            const len = getLength(theArray);
            let startIdx = start === UNDEF_VALUE ? 0 : start;
            let endIdx = end === UNDEF_VALUE ? len : end;
            if (startIdx < 0) {
                startIdx = mathMax(len + startIdx, 0);
            }
            else {
                startIdx = mathMin(startIdx, len);
            }
            if (endIdx < 0) {
                endIdx = mathMax(len + endIdx, 0);
            }
            else {
                endIdx = mathMin(endIdx, len);
            }
            for (let i = startIdx; i < endIdx; i++) {
                theArray[i] = value;
            }
        }
        return theArray;
    }

    const arrFind = /*#__PURE__*/ _unwrapFunctionWithPoly("find", ArrProto, polyArrFind);
    const arrFindIndex = /*#__PURE__*/ _unwrapFunctionWithPoly("findIndex", ArrProto, polyArrFindIndex);
    const arrFindLast = /*#__PURE__*/ _unwrapFunctionWithPoly("findLast", ArrProto, polyArrFindLast);
    const arrFindLastIndex = /*#__PURE__*/ _unwrapFunctionWithPoly("findLastIndex", ArrProto, polyArrFindLastIndex);

    const arrFlatMap = /*#__PURE__*/ _unwrapFunctionWithPoly("flatMap", ArrProto, polyArrFlatMap);
    /*#__NO_SIDE_EFFECTS__*/
    function polyArrFlatMap(theArray, callbackFn, thisArg) {
        _throwIfNullOrUndefined(theArray);
        if (!isFunction(callbackFn)) {
            throwTypeError("callbackFn must be a function");
        }
        let result = [];
        let callbackThis = arguments.length > 2 ? thisArg : undefined;
        arrForEach(theArray, (theValue, index) => {
            let value = fnCall(callbackFn, callbackThis, theValue, index, theArray);
            if (isArray(value)) {
                arrForEach(value, (mappedValue) => {
                    result.push(mappedValue);
                });
            }
            else {
                result.push(value);
            }
        });
        return result;
    }

    function _addItems(result, arr, d) {
        const arrLen = arr.length;
        let arrIdx = 0;
        while (arrIdx < arrLen) {
            const item = arr[arrIdx];
            if (d > 0 && isArray(item)) {
                _addItems(result, item, d - 1);
            }
            else {
                result.push(item);
            }
            arrIdx++;
        }
    }
    /*#__NO_SIDE_EFFECTS__*/
    function arrFlatten(theArray, depth) {
        const result = [];
        if (isArrayLike(theArray)) {
            const d = isUndefined(depth) ? 1 : depth;
            arrForEach(theArray, (item) => {
                if (d > 0 && isArray(item)) {
                    _addItems(result, item, d - 1);
                }
                else {
                    result.push(item);
                }
            });
        }
        return result;
    }

    const arrFrom = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ArrCls, "from")), polyArrFrom));

    /*#__NO_SIDE_EFFECTS__*/
    function arrGroupBy(theArray, callbackFn, thisArg) {
        const result = {};
        if (isArrayLike(theArray) && isFunction(callbackFn)) {
            arrForEach(theArray, (item, idx) => {
                const keyVal = callbackFn.call(thisArg, item, idx, theArray);
                const theKey = isSymbol(keyVal) ? keyVal : asString(keyVal);
                if (!objHasOwn(result, theKey)) {
                    if (isUnsafePropKey(theKey)) {
                        objDefine(result, theKey, { v: [] });
                    }
                    else {
                        result[theKey] = [];
                    }
                }
                result[theKey].push(item);
            });
        }
        return result;
    }

    function arrIntersection() {
        const result = [];
        let theArrays = arguments;
        if (theArrays.length > 0) {
            const firstArray = theArrays[0];
            if (isArrayLike(firstArray)) {
                arrForEach(firstArray, (item) => {
                    let inAll = true;
                    arrForEach(theArrays, (arr, index) => {
                        if (index > 0 && !arrIncludes(arr, item)) {
                            inAll = false;
                            return -1;
                        }
                    });
                    if (inAll && !arrIncludes(result, item)) {
                        result.push(item);
                    }
                });
            }
        }
        return result;
    }

    const mathFloor = (/*#__PURE__*/_pureRef(MathCls, "floor"));
    const mathCeil = (/*#__PURE__*/_pureRef(MathCls, "ceil"));

    const mathTrunc = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(MathCls, "trunc")), polyMathTrunc));
    /*#__NO_SIDE_EFFECTS__*/
    function polyMathTrunc(value) {
        let theValue = +value;
        return (theValue > 0 ? mathFloor : mathCeil)(theValue);
    }

    /*#__NO_SIDE_EFFECTS__*/
    function mathToInt(value, throwInfinity) {
        let result = +value;
        if (throwInfinity && (result === Infinity || result == Infinity)) {
            throwRangeError("invalid value [" + dumpObj(value) + "]");
        }
        return result !== result || result === 0 ? 0 : mathTrunc(result);
    }

    /*#__NO_SIDE_EFFECTS__*/
    function arrIndexKeys(value) {
        _throwIfNullOrUndefined(value);
        let keys = [];
        let len = mathToInt(getLength(value));
        if (len > 0) {
            for (let lp = 0; lp < len; lp++) {
                if (objHasOwn(value, lp)) {
                    keys.push(lp);
                }
            }
        }
        return keys;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function createIterable(ctx) {
        return makeIterable({}, ctx);
    }
    function makeIterable(target, ctx) {
        let itSymbol = getKnownSymbol(3 );
        function _createIterator() {
            return createIterator(ctx);
        }
        target[itSymbol] = _createIterator;
        return target;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function createIterableIterator(ctx) {
        let iterator = createIterator(ctx);
        let itSymbol = getKnownSymbol(3 );
        function _createIterator() {
            return iterator;
        }
        iterator[itSymbol] = _createIterator;
        return iterator;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function createIterator(ctx) {
        let isDone = false;
        function _value() {
            return ctx.v;
        }
        function _next() {
            if (!isDone) {
                isDone = (ctx.n ? ctx.n(arguments) : true);
            }
            let result = {
                done: isDone
            };
            if (!isDone) {
                objDefine(result, "value", { g: _value });
            }
            return result;
        }
        function _return(value) {
            isDone = true;
            return {
                done: true,
                value: ctx.r && ctx.r(value)
            };
        }
        function _throw(e) {
            isDone = true;
            return {
                done: true,
                value: ctx.t && ctx.t(e)
            };
        }
        let theIterator = {
            next: _next
        };
        if (ctx.r) {
            theIterator.return = _return;
        }
        if (ctx.t) {
            theIterator.throw = _throw;
        }
        return theIterator;
    }

    const arrKeys = /*#__PURE__*/ _unwrapFunctionWithPoly("keys", ArrProto, polyArrKeys);
    /*#__NO_SIDE_EFFECTS__*/
    function polyArrKeys(value) {
        _throwIfNullOrUndefined(value);
        let idx = -1;
        let len = mathToInt(value.length);
        if (len < 0) {
            len = 0;
        }
        return createIterableIterator({
            n: function () {
                idx++;
                let isDone = idx >= len;
                if (!isDone) {
                    this.v = idx;
                }
                return isDone;
            }
        });
    }

    /*#__NO_SIDE_EFFECTS__*/
    function arrPartition(theArray, callbackFn, thisArg) {
        const truthy = [];
        const falsy = [];
        if (isArrayLike(theArray)) {
            arrForEach(theArray, (value, index, array) => {
                if (callbackFn.call(thisArg, value, index, array)) {
                    truthy.push(value);
                }
                else {
                    falsy.push(value);
                }
            });
        }
        return [truthy, falsy];
    }

    const arrReduce = (/*#__PURE__*/_unwrapFunction("reduce", ArrProto));

    const arrReverse = (/*#__PURE__*/_unwrapFunction("reverse", ArrProto));

    /*#__NO_SIDE_EFFECTS__*/
    function arrRotate(theArray, count) {
        let result;
        if (isArrayLike(theArray)) {
            const len = theArray.length;
            if (!(len === 0 || count === 0)) {
                let rotations = count % len;
                if (rotations < 0) {
                    rotations = len + rotations;
                }
                if (rotations !== 0) {
                    result = [];
                    arrAppend(result, arrSlice(theArray, rotations));
                    arrAppend(result, arrSlice(theArray, 0, rotations));
                }
            }
            if (!result) {
                result = arrSlice(theArray);
            }
        }
        return result || [];
    }

    /*#__NO_SIDE_EFFECTS__*/
    function arrSample(theArray) {
        let result;
        if (isArrayLike(theArray)) {
            const len = getLength(theArray);
            if (len !== 0) {
                const index = mathFloor(mathRandom() * len);
                result = theArray[index];
            }
        }
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function arrShuffle(theArray) {
        const result = arrSlice(theArray);
        const len = getLength(result);
        for (let i = len - 1; i > 0; i--) {
            const swapVal = result[i];
            const j = mathFloor(mathRandom() * (i + 1));
            result[i] = result[j];
            result[j] = swapVal;
        }
        return result;
    }

    const arrSome = (/*#__PURE__*/_unwrapFunction("some", ArrProto));

    /*#__NO_SIDE_EFFECTS__*/
    function arrTake(theArray, count) {
        return arrSlice(theArray, 0, mathMax(0, count));
    }

    /*#__NO_SIDE_EFFECTS__*/
    function arrTakeWhile(theArray, callbackFn, thisArg) {
        const result = [];
        if (isArrayLike(theArray)) {
            arrForEach(theArray, (value, idx) => {
                if (!callbackFn.call(thisArg, value, idx, theArray)) {
                    return -1;
                }
                result.push(value);
            });
        }
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function arrUnique(theArray) {
        const result = [];
        if (isArrayLike(theArray)) {
            const seen = objCreate(null);
            arrForEach(theArray, (item) => {
                const key = ((typeof item) + "_" + item);
                if (!objHasOwn(seen, key)) {
                    seen[key] = 1;
                    result.push(item);
                }
            });
        }
        return result;
    }

    function arrUnion() {
        let combined = [];
        let theArgs = arguments;
        arrForEach(theArgs, (arr) => {
            combined = arrAppend(combined, arrSlice(arr));
        });
        return arrUnique(combined);
    }

    /*#__NO_SIDE_EFFECTS__*/
    function arrUnzip(theArray) {
        let result;
        if (isArrayLike(theArray)) {
            const len = getLength(theArray);
            if (len !== 0) {
                let maxLen = 0;
                arrForEach(theArray, (subArray) => {
                    if (isArrayLike(subArray)) {
                        const subLen = getLength(subArray);
                        if (subLen > maxLen) {
                            maxLen = subLen;
                        }
                    }
                });
                if (maxLen !== 0) {
                    result = [];
                    for (let lp = 0; lp < maxLen; lp++) {
                        result.push([]);
                    }
                    arrForEach(theArray, (subArray) => {
                        if (isArrayLike(subArray)) {
                            for (let lp = 0; lp < maxLen; lp++) {
                                result[lp].push(lp < getLength(subArray) ? subArray[lp] : UNDEF_VALUE);
                            }
                        }
                    });
                }
            }
        }
        return result || [];
    }

    const arrWith = /*#__PURE__*/ _unwrapFunctionWithPoly("with", ArrProto, polyArrWith);
    /*#__NO_SIDE_EFFECTS__*/
    function polyArrWith(theArray, index, value) {
        let result;
        if (!isArrayLike(theArray)) {
            throwRangeError("Invalid array");
        }
        const len = getLength(theArray);
        let idx = index;
        if (idx < 0) {
            idx = len + idx;
        }
        if (idx < 0 || idx >= len) {
            throwRangeError("Index out of bounds");
        }
        result = arrSlice(theArray);
        result[idx] = value;
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function arrZip(...arrays) {
        let result;
        if (arrays.length !== 0) {
            const validArrays = [];
            for (let i = 0; i < arrays.length; i++) {
                if (isArrayLike(arrays[i])) {
                    validArrays.push(arrays[i]);
                }
            }
            if (validArrays.length !== 0) {
                let minLen = Infinity;
                for (let lp = 0; lp < validArrays.length; lp++) {
                    minLen = mathMin(minLen, getLength(validArrays[lp]));
                }
                if (isFinite(minLen) && minLen !== 0) {
                    result = [];
                    for (let lp = 0; lp < minLen; lp++) {
                        const group = [];
                        for (let j = 0; j < validArrays.length; j++) {
                            group.push(validArrays[j][lp]);
                        }
                        result.push(group);
                    }
                }
            }
        }
        return result || [];
    }

    /*#__NO_SIDE_EFFECTS__*/
    function fnBindArgs(fn, thisArg, argArray) {
        return fn.bind.apply(fn, (argArray ? [thisArg].concat(argArray) : [thisArg]));
    }

    /*#__NO_SIDE_EFFECTS__*/
    function createFnDeferredProxy(hostFn, funcName) {
        return function () {
            var theArgs = ArrSlice[CALL](arguments);
            let theHost = hostFn();
            return fnApply(theHost[funcName], theHost, theArgs);
        };
    }
    function createProxyFuncs(target, host, funcDefs) {
        if (target && host && isArray(funcDefs)) {
            let isDeferred = isFunction(host);
            arrForEach(funcDefs, (funcDef) => {
                let targetName = (funcDef.as || funcDef.n);
                if (funcDef.rp === false && target[targetName]) {
                    return;
                }
                target[targetName] = isDeferred ?
                    createFnDeferredProxy(host, funcDef.n) :
                    fnBind(host[funcDef.n], host);
            });
        }
        return target;
    }

    let _iterSymbol;
    /*#__NO_SIDE_EFFECTS__*/
    function readArgs(theArgs, start, end) {
        if (!objHasOwn(theArgs, LENGTH)) {
            !_iterSymbol && (_iterSymbol = createCachedValue(hasSymbol() && getKnownSymbol(3 )));
            let iterFn;
            if (_iterSymbol.v) {
                iterFn = theArgs[_iterSymbol.v];
            }
            if (iterFn) {
                let values = [];
                let from = (start === UNDEF_VALUE || start < 0) ? 0 : start;
                let to = end < 0 || start < 0 ? UNDEF_VALUE : end;
                iterForOf(iterFn[CALL](theArgs), (value, cnt) => {
                    if (to !== UNDEF_VALUE && cnt >= to) {
                        return -1;
                    }
                    if (cnt >= from) {
                        values.push(value);
                    }
                });
                if ((start === UNDEF_VALUE || start >= 0) && (end === UNDEF_VALUE || end >= 0)) {
                    return values;
                }
                theArgs = values;
            }
        }
        return arrSlice(theArgs, start, end);
    }

    let _isProtoArray;
    const objSetPrototypeOf = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, "setPrototypeOf")), _polyObjSetPrototypeOf));
    function _polyObjSetPrototypeOf(obj, proto) {
        !_isProtoArray && (_isProtoArray = createCachedValue({ } instanceof Array));
        _isProtoArray.v ? obj[__PROTO__] = proto : objForEachKey(proto, (key, value) => obj[key] = value);
        return obj;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function _createCustomError(name, d, b) {
        safe(objDefine, [d, NAME, { v: name, c: true, e: false }]);
        d = objSetPrototypeOf(d, b);
        function __() {
            this[CONSTRUCTOR] = d;
            safe(objDefine, [this, NAME, { v: name, c: true, e: false }]);
        }
        d[PROTOTYPE] = b === NULL_VALUE ? objCreate(b) : (__[PROTOTYPE] = b[PROTOTYPE], new __());
        return d;
    }
    function _setName(baseClass, name) {
        name && (baseClass[NAME] = name);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function createCustomError(name, constructCb, errorBase, superArgsFn) {
        let theBaseClass = errorBase || Error;
        let orgName = theBaseClass[PROTOTYPE][NAME];
        let captureFn = Error.captureStackTrace;
        return _createCustomError(name, function () {
            let _this = this;
            let theArgs = arguments;
            try {
                safe(_setName, [theBaseClass, name]);
                let _self = fnApply(theBaseClass, _this, superArgsFn ? superArgsFn(theArgs) : ArrSlice[CALL](theArgs)) || _this;
                if (_self !== _this) {
                    let orgProto = objGetPrototypeOf(_this);
                    if (orgProto !== objGetPrototypeOf(_self)) {
                        objSetPrototypeOf(_self, orgProto);
                    }
                }
                captureFn && captureFn(_self, _this[CONSTRUCTOR]);
                constructCb && constructCb(_self, theArgs);
                return _self;
            }
            finally {
                safe(_setName, [theBaseClass, orgName]);
            }
        }, theBaseClass);
    }
    let _unsupportedError;
    function throwUnsupported(message) {
        if (!_unsupportedError) {
            _unsupportedError = createCustomError("UnsupportedError");
        }
        throw new _unsupportedError(message);
    }

    function isElement(value) {
        return !!value && value.nodeType === 1 &&
            !!value.nodeName &&
            !!(typeof Element !== "undefined" && value instanceof Element);
    }
    function isElementLike(value) {
        return !!value && value.nodeType === 1 && !!value.nodeName;
    }

    function isEmpty(value) {
        let result = isStrictNullOrUndefined(value);
        if (!result) {
            if (isString(value) || isArray(value)) {
                result = (value.length === 0);
            }
            else if (isMapLike(value) || isSetLike(value)) {
                result = (value.size === 0);
            }
            else if (isObject(value)) {
                result = objKeys(value).length === 0;
            }
        }
        return result;
    }

    const strReplace = (/*#__PURE__*/_unwrapFunction("replace", StrProto));

    /*#__NO_SIDE_EFFECTS__*/
    function _createTrimFn(exp) {
        return function _doTrim(value) {
            _throwIfNullOrUndefined(value);
            value = asString(value);
            if (value) {
                value = strReplace(value, exp, EMPTY);
            }
            return value;
        };
    }
    const polyStrTrim = (/*#__PURE__*/_createTrimFn(/^\s+|(?=\s)\s+$/g));
    const polyStrTrimStart = (/*#__PURE__*/_createTrimFn(/^\s+/g));
    const polyStrTrimEnd = (/*#__PURE__*/_createTrimFn(/(?=\s)\s+$/g));

    const strTrim = (/*#__PURE__*/_unwrapFunctionWithPoly("trim", StrProto, polyStrTrim));
    const strTrimStart = (/*#__PURE__*/_unwrapFunctionWithPoly("trimStart", StrProto, polyStrTrimStart));
    const strTrimLeft = (/*#__PURE__*/_pureAssign(strTrimStart));
    const strTrimEnd = (/*#__PURE__*/_unwrapFunctionWithPoly("trimEnd", StrProto, polyStrTrimEnd));
    const strTrimRight = (/*#__PURE__*/_pureAssign(strTrimEnd));

    const strUpper = (/*#__PURE__*/_unwrapFunction("toUpperCase", StrProto));
    const strLower = (/*#__PURE__*/_unwrapFunction("toLowerCase", StrProto));

    /*#__NO_SIDE_EFFECTS__*/
    function _convertCase(value, newPrefix, upperWord) {
        return strReplace(strTrim(asString(value)), /((_|\W)+(\w){0,1}|([a-z])([A-Z]))/g, (_match, _g1, _g2, wordStart, upperPrefix, upperLetter) => {
            let convertMatch = wordStart || upperLetter || EMPTY;
            if (upperWord) {
                convertMatch = strUpper(convertMatch);
            }
            return (upperPrefix || EMPTY) + newPrefix + convertMatch;
        });
    }
    /*#__NO_SIDE_EFFECTS__*/
    function strLetterCase(value) {
        return strReplace(asString(value), /(_|\b)\w/g, strUpper);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function strCapitalizeWords(value) {
        return strLetterCase(strLower(asString(value)));
    }
    /*#__NO_SIDE_EFFECTS__*/
    function strCamelCase(value, upperFirst) {
        let result = _convertCase(value, "", true);
        return strReplace(result, /^\w/, upperFirst ? strUpper : strLower);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function strKebabCase(value, scream) {
        let result = _convertCase(value, "-");
        return (scream ? strUpper : strLower)(result);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function strSnakeCase(value, scream) {
        let result = _convertCase(value, "_");
        return (scream ? strUpper : strLower)(result);
    }

    const strRepeat = (/*#__PURE__*/_unwrapFunctionWithPoly("repeat", StrProto, polyStrRepeat));
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrRepeat(value, count) {
        _throwIfNullOrUndefined(value);
        count = mathToInt(count, true);
        if (count < 0) {
            throwRangeError("invalid count must be >= 0 && < Infinity");
        }
        let pad = isString(value) ? value : asString(value);
        let result = EMPTY;
        for (; count > 0; (count >>>= 1) && (pad += pad)) {
            if (count & 1) {
                result += pad;
            }
        }
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function _padValue(value, targetLength, padString) {
        let result = EMPTY;
        targetLength = mathToInt(targetLength, true);
        targetLength >>= 0;
        let len = value[LENGTH];
        if (len < targetLength) {
            result = isNullOrUndefined(padString) ? " " : asString(padString);
            targetLength = targetLength - len;
            if (targetLength > result[LENGTH]) {
                result = strRepeat(result, mathCeil(targetLength / result[LENGTH]));
            }
            if (result[LENGTH] > targetLength) {
                result = strSubstring(result, 0, targetLength);
            }
        }
        return result;
    }
    const strPadStart = (/*#__PURE__*/_unwrapFunctionWithPoly("padStart", StrProto, polyStrPadStart));
    const strPadEnd = (/*#__PURE__*/_unwrapFunctionWithPoly("padEnd", StrProto, polyStrPadEnd));
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrPadStart(value, targetLength, padString) {
        return _padValue(value, targetLength, padString) + value;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrPadEnd(value, targetLength, padString) {
        return value + _padValue(value, targetLength, padString);
    }

    /*#__NO_SIDE_EFFECTS__*/
    function safeGetLazy(cb, defValue, argArray) {
        return getLazy(() => {
            let result = safe(cb, argArray);
            return result.e ? defValue : result.v;
        });
    }
    /*#__NO_SIDE_EFFECTS__*/
    function safeGetWritableLazy(cb, defValue, argArray) {
        return getWritableLazy(() => {
            let result = safe(cb, argArray);
            return result.e ? defValue : result.v;
        });
    }
    /*#__NO_SIDE_EFFECTS__*/
    function safeGetDeferred(cb, defValue, argArray) {
        return getDeferred(() => {
            let result = safe(cb, argArray);
            return result.e ? defValue : result.v;
        });
    }
    /*#__NO_SIDE_EFFECTS__*/
    function safeGetWritableDeferred(cb, defValue, argArray) {
        return getWritableDeferred(() => {
            let result = safe(cb, argArray);
            return result.e ? defValue : result.v;
        });
    }

    const DBL_QUOTE = "\"";
    const INVALID_JS_NAME = /([^\w\d_$])/g;
    const BASE64_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const HEX_CHARS = "0123456789abcdef";
    let _btoa;
    let _atob;
    let _htmlEntityCache;
    let _base64Cache;
    /*#__NO_SIDE_EFFECTS__*/
    function normalizeJsName(jsName, camelCase) {
        let result = strReplace(asString(jsName), INVALID_JS_NAME, "_");
        return !isUndefined(camelCase) ? strCamelCase(result, !camelCase) : result;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function encodeAsJson(value, format) {
        let result;
        if (isString(value)) {
            result = DBL_QUOTE + strReplace(value, /[^\w .,\-!@#$%\^&*\(\)_+={}\[\]:;|<>?]/g, (match) => {
                if (match === DBL_QUOTE || match === "\\") {
                    return "\\" + match;
                }
                var hex = match.charCodeAt(0)[TO_STRING](16);
                return "\\u" + strPadStart(strUpper(hex), 4, "0");
            }) + DBL_QUOTE;
        }
        else {
            try {
                result = JSON.stringify(value, NULL_VALUE, format ? (isNumber(format) ? format : 4) : UNDEF_VALUE);
            }
            catch (e) {
                result = DBL_QUOTE + dumpObj(e) + DBL_QUOTE;
            }
        }
        return result;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function encodeAsHtml(value) {
        !_htmlEntityCache && (_htmlEntityCache = {
            "&": "amp",
            "<": "lt",
            ">": "gt",
            "\"": "quot",
            "'": "#39"
        });
        return strReplace(asString(value), /[&<>"']/g, match => "&" + _htmlEntityCache[match] + ";");
    }
    /*#__NO_SIDE_EFFECTS__*/
    function encodeAsBase64(value) {
        let result;
        if (value || !isStrictNullOrUndefined(value)) {
            result = asString(value);
            try {
                !_btoa && (_btoa = safeGetDeferred(() => !isUndefined(btoa) ? btoa : _encodeBase64Polyfill, _encodeBase64Polyfill));
                result = _btoa.v(result);
            }
            catch (e) {
                result = _encodeBase64Polyfill(result);
            }
        }
        return result || EMPTY;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function decodeBase64(value) {
        let result;
        if (value || !isStrictNullOrUndefined(value)) {
            result = asString(value);
            try {
                !_atob && (_atob = safeGetDeferred(() => !isUndefined(atob) ? atob : _decodeBase64Polyfill, _decodeBase64Polyfill));
                result = _atob.v(result);
            }
            catch (e) {
                result = _decodeBase64Polyfill(result);
            }
        }
        return result || value || EMPTY;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function encodeAsBase64Url(value) {
        let encoded = encodeAsBase64(value);
        if (encoded) {
            encoded = strReplace(strReplace(strReplace(encoded, /\+/g, "-"), /\//g, "_"), /=/g, "");
        }
        return encoded || EMPTY;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function decodeBase64Url(value) {
        let result;
        if (value || !isStrictNullOrUndefined(value)) {
            result = asString(value);
            let pad = 4 - (result.length % 4);
            if (pad && pad !== 4) {
                result = result + strRepeat("=", pad);
            }
            result = decodeBase64(strReplace(strReplace(result, /-/g, "+"), /_/g, "/")) || EMPTY;
        }
        return result || value || EMPTY;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function encodeAsHex(value) {
        let result;
        if (value || !isStrictNullOrUndefined(value)) {
            result = asString(value);
            let hex = [];
            for (let idx = 0; idx < result.length; idx++) {
                let code = result.charCodeAt(idx);
                hex.push(HEX_CHARS[(code >> 4) & 0xf]);
                hex.push(HEX_CHARS[code & 0xf]);
            }
            result = hex.join("");
        }
        return result || value || EMPTY;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function decodeHex(value) {
        let result = [];
        if (value || !isStrictNullOrUndefined(value)) {
            let theValue = asString(value);
            for (let idx = 0; idx < theValue.length; idx += 2) {
                result.push(String.fromCharCode(parseInt(strSubstr(theValue, idx, 2), 16)));
            }
        }
        return result.join("");
    }
    /*#__NO_SIDE_EFFECTS__*/
    function encodeAsUri(value) {
        let result;
        if (value || !isStrictNullOrUndefined(value)) {
            try {
                result = encodeURIComponent(asString(value));
            }
            catch (e) {
            }
        }
        return result || value || EMPTY;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function decodeUri(value) {
        let result;
        if (value || !isStrictNullOrUndefined(value)) {
            try {
                result = decodeURIComponent(asString(value));
            }
            catch (e) {
            }
        }
        return result || value || EMPTY;
    }
    function _encodeBase64Polyfill(str) {
        let result = [];
        if (str || !isStrictNullOrUndefined(str)) {
            str = asString(str);
            let len = str.length;
            let lp = 0;
            while (lp < len) {
                let a = str.charCodeAt(lp++);
                let hasB = lp < len;
                let b = hasB ? str.charCodeAt(lp++) : 0;
                let hasC = lp < len;
                let c = hasC ? str.charCodeAt(lp++) : 0;
                let bitmap = (a << 16) | (b << 8) | c;
                result.push(BASE64_CHARS[(bitmap >> 18) & 63]);
                result.push(BASE64_CHARS[(bitmap >> 12) & 63]);
                if (hasB) {
                    result.push(BASE64_CHARS[(bitmap >> 6) & 63]);
                }
                else {
                    result.push("=");
                }
                if (hasC) {
                    result.push(BASE64_CHARS[bitmap & 63]);
                }
                else {
                    result.push("=");
                }
            }
        }
        return result.join("");
    }
    function _decodeBase64Polyfill(str) {
        let result = [];
        if (str || !isStrictNullOrUndefined(str)) {
            str = asString(str);
            let len = str.length;
            !_base64Cache && (_base64Cache = {});
            if (!_base64Cache["A"]) {
                for (let i = 0; i < BASE64_CHARS.length; i++) {
                    _base64Cache[BASE64_CHARS[i]] = i;
                }
            }
            let idx = 0;
            while (idx < len) {
                let a = _base64Cache[str[idx++]] || 0;
                let b = _base64Cache[str[idx++]] || 0;
                let c = _base64Cache[str[idx++]] || 0;
                let d = _base64Cache[str[idx++]] || 0;
                let bitmap = (a << 18) | (b << 12) | (c << 6) | d;
                result.push(String.fromCharCode((bitmap >> 16) & 255));
                if (str[idx - 2] !== "=") {
                    result.push(String.fromCharCode((bitmap >> 8) & 255));
                }
                if (str[idx - 1] !== "=") {
                    result.push(String.fromCharCode(bitmap & 255));
                }
            }
        }
        return result.join("");
    }

    let _recursionCheckOwnDescriptors;
    let _recursionCheckOwnSymbols;
    const _objGetOwnPropertyNames = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, GET_OWN_PROPERTY_NAMES)), _returnEmptyArray));
    const _objGetOwnPropertyDescriptor = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, GET_OWN_PROPERTY_DESCRIPTOR)), _returnNothing));
    function polyObjGetOwnPropertyDescriptors(obj) {
        const result = {};
        _throwIfNullOrUndefined(obj);
        if (!_recursionCheckOwnDescriptors) {
            try {
                _recursionCheckOwnDescriptors = true;
                arrForEach(_objGetOwnPropertyNames(obj), (propName) => {
                    const descriptor = _objGetOwnPropertyDescriptor(obj, propName);
                    if (descriptor !== undefined) {
                        result[propName] = descriptor;
                    }
                });
                arrForEach(_polyObjGetOwnPropertySymbols(obj), (sym) => {
                    const descriptor = _objGetOwnPropertyDescriptor(obj, sym);
                    if (descriptor !== undefined) {
                        result[sym] = descriptor;
                    }
                });
            }
            finally {
                _recursionCheckOwnDescriptors = false;
            }
        }
        return result;
    }
    function _polyObjGetOwnPropertySymbols(obj) {
        let result = [];
        let objHasOwn = ObjClass.hasOwn || polyObjHasOwn;
        if (!_recursionCheckOwnSymbols) {
            try {
                _recursionCheckOwnSymbols = true;
                let symEnum = 0 ;
                while (symEnum <= 12 ) {
                    var sym = getKnownSymbol(symEnum);
                    if (sym && objHasOwn(obj, sym)) {
                        result.push(sym);
                    }
                    symEnum++;
                }
            }
            finally {
                _recursionCheckOwnSymbols = false;
            }
        }
        return result;
    }

    const objGetOwnPropertyDescriptor = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, GET_OWN_PROPERTY_DESCRIPTOR)), _returnNothing));
    const objGetOwnPropertyDescriptors = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, "getOwnPropertyDescriptors")), polyObjGetOwnPropertyDescriptors));
    const objGetOwnPropertyNames = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, GET_OWN_PROPERTY_NAMES)), _returnEmptyArray));
    const objGetOwnPropertySymbols = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, GET_OWN_PROPERTY_SYMBOLS)), _returnEmptyArray));

    function forEachOwnKey(theObject, callbackfn, thisArg) {
        if (theObject !== NULL_VALUE && theObject !== UNDEF_VALUE) {
            for (const prop in theObject) {
                if (objHasOwn(theObject, prop)) {
                    if (callbackfn[CALL](isStrictNullOrUndefined(thisArg) ? theObject : thisArg, prop, theObject[prop]) === -1) {
                        return;
                    }
                }
            }
            arrForEach(objGetOwnPropertySymbols(theObject), (key) => {
                if (_objPropertyIsEnumerable(theObject, key)) {
                    if (callbackfn[CALL](isStrictNullOrUndefined(thisArg) ? theObject : thisArg, key, theObject[key]) === -1) {
                        return -1;
                    }
                }
            });
        }
    }
    function forEachOwnKeySafe(theObject, callbackfn, thisArg) {
        forEachOwnKey(theObject, (key, value) => {
            if (!isUnsafePropKey(key)) {
                return callbackfn[CALL](isStrictNullOrUndefined(thisArg) ? theObject : thisArg, key, value);
            }
        }, thisArg);
    }

    let _fnToString;
    let _objCtrFnString;
    let _gblWindow;
    /*#__NO_SIDE_EFFECTS__*/
    function isPlainObject(value) {
        if (!value || typeof value !== OBJECT) {
            return false;
        }
        if (!_gblWindow) {
            _gblWindow = hasWindow() ? getWindow() : true;
        }
        let result = false;
        if (value !== _gblWindow) {
            if (!_objCtrFnString) {
                _fnToString = Function[PROTOTYPE][TO_STRING];
                _objCtrFnString = _fnToString[CALL](ObjClass);
            }
            try {
                let proto = objGetPrototypeOf(value);
                result = !proto;
                if (!result) {
                    if (objHasOwnProperty(proto, CONSTRUCTOR)) {
                        proto = proto[CONSTRUCTOR];
                    }
                    result = !!(proto && typeof proto === FUNCTION && _fnToString[CALL](proto) === _objCtrFnString);
                }
            }
            catch (ex) {
            }
        }
        return result;
    }

    let _unsafeTargets;
    /*#__NO_SIDE_EFFECTS__*/
    function _addTarget(targets, target) {
        if (target) {
            targets.push(target);
        }
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _addTargetProto(targets, ctor) {
        if (ctor) {
            _addTarget(targets, ctor[PROTOTYPE]);
        }
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _getUnsafeTargets() {
        let targets = [
            ObjProto,
            StrProto,
            ArrProto,
            NumberProto,
            FuncProto,
            DateProto,
            RegExpProto,
            BooleanProto,
            ErrorProto
        ];
        _addTargetProto(targets, safe(getInst, ["Map"]).v);
        _addTargetProto(targets, safe(getInst, ["Set"]).v);
        _addTargetProto(targets, safe(getInst, ["WeakMap"]).v);
        _addTargetProto(targets, safe(getInst, ["WeakSet"]).v);
        _addTargetProto(targets, safe(getInst, ["Promise"]).v);
        _addTargetProto(targets, safe(getInst, ["Symbol"]).v);
        _addTargetProto(targets, safe(getInst, ["ArrayBuffer"]).v);
        _addTargetProto(targets, safe(getInst, ["SharedArrayBuffer"]).v);
        _addTargetProto(targets, safe(getInst, ["DataView"]).v);
        _addTargetProto(targets, safe(getInst, ["Int8Array"]).v);
        _addTargetProto(targets, safe(getInst, ["Uint8Array"]).v);
        _addTargetProto(targets, safe(getInst, ["Uint8ClampedArray"]).v);
        _addTargetProto(targets, safe(getInst, ["Int16Array"]).v);
        _addTargetProto(targets, safe(getInst, ["Uint16Array"]).v);
        _addTargetProto(targets, safe(getInst, ["Int32Array"]).v);
        _addTargetProto(targets, safe(getInst, ["Uint32Array"]).v);
        _addTargetProto(targets, safe(getInst, ["Float32Array"]).v);
        _addTargetProto(targets, safe(getInst, ["Float64Array"]).v);
        _addTargetProto(targets, safe(getInst, ["BigInt64Array"]).v);
        _addTargetProto(targets, safe(getInst, ["BigUint64Array"]).v);
        _addTargetProto(targets, safe(getInst, ["WeakRef"]).v);
        _addTargetProto(targets, safe(getInst, ["FinalizationRegistry"]).v);
        return targets;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isUnsafeTarget(target) {
        if (!_unsafeTargets) {
            _unsafeTargets = createCachedValue(_getUnsafeTargets());
        }
        return arrIndexOf(_unsafeTargets.v, target) >= 0;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function _defaultDeepCopyHandler(details) {
        details.value && plainObjDeepCopyHandler(details);
        return true;
    }
    const defaultDeepCopyHandlers = [
        arrayDeepCopyHandler,
        plainObjDeepCopyHandler,
        functionDeepCopyHandler,
        dateDeepCopyHandler
    ];
    /*#__NO_SIDE_EFFECTS__*/
    function _getSetVisited(visitMap, source, newPath, cb) {
        let theEntry;
        arrForEach(visitMap, (entry) => {
            if (entry.k === source) {
                theEntry = entry;
                return -1;
            }
        });
        if (!theEntry) {
            theEntry = { k: source, v: source };
            visitMap.push(theEntry);
            cb(theEntry);
        }
        return theEntry.v;
    }
    function _deepCopy(visitMap, value, ctx, key) {
        let userHandler = ctx.handler;
        let newPath = ctx.path ? (key ? ctx.path.concat(key) : ctx.path) : [];
        let newCtx = {
            handler: ctx.handler,
            src: ctx.src,
            path: newPath
        };
        const theType = typeof value;
        let isPlain = false;
        let isPrim = value === NULL_VALUE;
        if (!isPrim) {
            if (value && theType === OBJECT) {
                isPlain = isPlainObject(value);
            }
            else {
                isPrim = isPrimitiveType(theType);
            }
        }
        let details = {
            type: theType,
            isPrim: isPrim,
            isPlain: isPlain,
            value: value,
            result: value,
            path: newPath,
            origin: ctx.src,
            copy: (source, newKey) => {
                return _deepCopy(visitMap, source, newKey ? newCtx : ctx, newKey);
            },
            copyTo: (target, source) => {
                return _copyProps(visitMap, target, source, newCtx);
            }
        };
        if (!details.isPrim) {
            return _getSetVisited(visitMap, value, newPath, (newEntry) => {
                objDefine(details, "result", {
                    g: function () {
                        return newEntry.v;
                    },
                    s: function (newValue) {
                        newEntry.v = newValue;
                    }
                });
                let idx = 0;
                let handler = userHandler;
                while (!(handler || (idx < defaultDeepCopyHandlers.length ? defaultDeepCopyHandlers[idx++] : _defaultDeepCopyHandler))[CALL](ctx, details)) {
                    handler = NULL_VALUE;
                }
            });
        }
        if (userHandler && userHandler[CALL](ctx, details)) {
            return details.result;
        }
        return value;
    }
    function _copyProps(visitMap, target, source, ctx) {
        if (!isUnsafeTarget(source)) {
            forEachOwnKeySafe(source, (key, value) => {
                target[key] = _deepCopy(visitMap, value, ctx, key);
            });
        }
        return target;
    }
    function objCopyProps(target, source, handler) {
        let ctx = {
            handler: handler,
            src: source,
            path: []
        };
        return _copyProps([], target, source, ctx);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function objDeepCopy(source, handler) {
        let ctx = {
            handler: handler,
            src: source
        };
        return _deepCopy([], source, ctx);
    }
    function arrayDeepCopyHandler(details) {
        let value = details.value;
        if (isArray(value)) {
            let target = details.result = [];
            target.length = value.length;
            details.copyTo(target, value);
            return true;
        }
        return false;
    }
    function dateDeepCopyHandler(details) {
        let value = details.value;
        if (isDate(value)) {
            details.result = new Date(value.getTime());
            return true;
        }
        return false;
    }
    function functionDeepCopyHandler(details) {
        if (details.type === FUNCTION) {
            return true;
        }
        return false;
    }
    function plainObjDeepCopyHandler(details) {
        let value = details.value;
        if (value && details.isPlain) {
            let target = details.result = {};
            details.copyTo(target, value);
            return true;
        }
        return false;
    }

    function _doExtend(target, theArgs) {
        arrForEach(theArgs, (theArg) => {
            objCopyProps(target, theArg);
        });
        return target;
    }
    function deepExtend(target, obj1, obj2, obj3, obj4, obj5, obj6) {
        return _doExtend(objDeepCopy(target) || {}, ArrSlice[CALL](arguments));
    }
    function objExtend(target, obj1, obj2, obj3, obj4, obj5, obj6) {
        return _doExtend(target || {}, ArrSlice[CALL](arguments));
    }

    /*#__NO_SIDE_EFFECTS__*/
    function polyStrSymSplit(value, splitter, limit) {
        let splitFn = splitter ? splitter[getKnownSymbol(9 )] : UNDEF_VALUE;
        return splitFn ? splitFn(value, limit) : [value];
    }

    const strSplit = (/*#__PURE__*/_unwrapFunction("split", StrProto));
    const strSymSplit = (/*#__PURE__*/_unwrapFunctionWithPoly("split", StrProto, polyStrSymSplit));

    /*#__NO_SIDE_EFFECTS__*/
    function getValueByKey(target, path, defValue) {
        if (!path || !target) {
            return defValue;
        }
        let parts = strSplit(path, ".");
        let cnt = parts.length;
        for (let lp = 0; lp < cnt && !isNullOrUndefined(target); lp++) {
            target = target[parts[lp]];
        }
        return (!isNullOrUndefined(target) ? target : defValue);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function getValueByIter(target, iter, defValue) {
        if (!iter || !target) {
            return defValue;
        }
        iterForOf(iter, (value) => {
            if (isNullOrUndefined(target)) {
                return -1;
            }
            target = target[value];
        });
        return (!isNullOrUndefined(target) ? target : defValue);
    }
    function setValueByKey(target, path, value) {
        if (target && path) {
            let parts = strSplit(path, ".");
            let lastKey = parts.pop();
            let isValidPath = true;
            let addedTarget;
            let addedKey;
            arrForEach(parts, (key) => {
                if (isUnsafeTarget(target) || isUnsafePropKey(key)) {
                    isValidPath = false;
                    return -1;
                }
                if (isNullOrUndefined(target[key])) {
                    target[key] = {};
                    if (!addedTarget) {
                        addedTarget = target;
                        addedKey = key;
                    }
                }
                target = target[key];
            });
            if (isValidPath && !isStrictNullOrUndefined(lastKey) && !isUnsafeTarget(target) && !isUnsafePropKey(lastKey)) {
                target[lastKey] = value;
            }
            else if (addedTarget) {
                try {
                    delete addedTarget[addedKey];
                }
                catch (e) {
                }
            }
        }
    }
    function setValueByIter(target, iter, value) {
        if (target && iter) {
            let lastKey;
            let isValidPath = true;
            let firstAddedTarget;
            let firstAddedKey;
            iterForOf(iter, (key) => {
                if (isUnsafeTarget(target) || isUnsafePropKey(key)) {
                    isValidPath = false;
                    return -1;
                }
                if (lastKey) {
                    if (isNullOrUndefined(target[lastKey])) {
                        target[lastKey] = {};
                        if (isNullOrUndefined(firstAddedTarget)) {
                            firstAddedTarget = target;
                            firstAddedKey = lastKey;
                        }
                    }
                    target = target[lastKey];
                }
                lastKey = key;
            });
            if (isValidPath && !isUnsafeTarget(target) && typeof lastKey === "string" && !isUnsafePropKey(lastKey)) {
                target[lastKey] = value;
            }
            else if (!isNullOrUndefined(firstAddedTarget) && typeof firstAddedKey === "string") {
                try {
                    delete firstAddedTarget[firstAddedKey];
                }
                catch (e) {
                }
            }
        }
    }

    /*#__NO_SIDE_EFFECTS__*/
    function getIntValue(value, defValue) {
        try {
            let theValue = value;
            if (!isNumber(value)) {
                theValue = parseInt(asString(value), 10);
            }
            return (isNullOrUndefined(value) || isNaN(theValue)) ? defValue : theValue;
        }
        catch (e) {
        }
        return defValue;
    }
    const isInteger = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(NumberCls, "isInteger")), _polyNumberIsInteger));
    /*#__NO_SIDE_EFFECTS__*/
    function isIntegerInRange(value, min, max) {
        return isInteger(value) && isInteger(min) && isInteger(max) && min <= max && value >= min && value <= max;
    }
    function _polyNumberIsInteger(value) {
        return isNumber(value) && !isNaN(value) &&
            isFinite(value) &&
            mathFloor(value) === value;
    }
    function isFiniteNumber(value) {
        return isNumber(value) && !isNaN(value) && isFinite(value);
    }

    let _perf;
    /*#__NO_SIDE_EFFECTS__*/
    function hasPerformance() {
        return !!getPerformance();
    }
    /*#__NO_SIDE_EFFECTS__*/
    function getPerformance() {
        !_globalLazyTestHooks && _initTestHooks();
        if (!_perf || _globalLazyTestHooks.lzy) {
            _perf = createCachedValue(safe((getInst), ["performance"]).v);
        }
        return _perf.v;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function perfNow() {
        let perf = getPerformance();
        if (perf && perf.now) {
            return perf.now();
        }
        return utcNow();
    }
    /*#__NO_SIDE_EFFECTS__*/
    function elapsedTime(startTime) {
        return perfNow() - startTime;
    }

    const MATCH_ANY = "(.*)";
    const MATCH_SINGLE = "(.)";
    function _createRegExp(value, escapeRgx, replaceFn, ignoreCase, fullMatch) {
        return new RegExp((fullMatch ? "^" : EMPTY) + replaceFn(strReplace(value, escapeRgx, "\\$1")) + (fullMatch ? "$" : EMPTY), ignoreCase ? "i" : "");
    }
    /*#__NO_SIDE_EFFECTS__*/
    function createWildcardRegex(value, ignoreCase, fullMatch) {
        return _createRegExp(asString(value), /([-+|^$#\.\?{}()\[\]\\\/\"\'])/g, (value) => {
            return strReplace(value, /\*/g, MATCH_ANY);
        }, !!ignoreCase, fullMatch);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function createFilenameRegex(value, ignoreCase, fullMatch) {
        return _createRegExp(asString(value), /([-+|^$#\.{}()\\\/\[\]\"\'])/g, (value) => {
            return strReplace(value, /(\\\\|\\\/|\*|\?)/g, function (_all, g1) {
                if (g1 == "\\/" || g1 == "\\\\") {
                    return "[\\\\\\/]{1}";
                }
                return g1 == "*" ? MATCH_ANY : MATCH_SINGLE;
            });
        }, !!ignoreCase, fullMatch);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function makeGlobRegex(value, ignoreCase, fullMatch) {
        return _createRegExp(asString(value), /([-+|^$#\.{}()\\\/\[\]\"\'])/g, (value) => {
            return strReplace(value, /(\*\*\\[\\\/]|\\\\|\\\/|\*\*|\*|\?)/g, function (_all, g1) {
                if (g1 == "**\\/" || g1 == "**\\\\") {
                    return "(.*[\\\\\\/])*";
                }
                if (g1 === "\\/" || g1 == "\\\\") {
                    return "[\\\\\\/]{1}";
                }
                if (g1 === "**") {
                    return MATCH_ANY;
                }
                return g1 === "*" ? "([^\\\\\\/]*)" : "([^\\\\\\/]{1})";
            });
        }, !!ignoreCase, fullMatch);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function createLiteralRegex(matcher) {
        return new RegExp(strReplace(asString(matcher), /[.*+?^${}()|[\]\\]/g, "\\$&") || "(?:)", "g");
    }

    /*#__NO_SIDE_EFFECTS__*/
    function _checkLength(value, props) {
        let result;
        arrForEach(props, (prop) => {
            if (prop in value) {
                let propValue = value[prop];
                result = (isFunction(propValue) ? propValue() : propValue) > 0;
                return -1;
            }
        });
        return result;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _hasValue(value, depth) {
        let result = value === false || value === 0;
        if (!result && !isNullOrUndefined(value)) {
            if (isArray(value)) {
                result = value[LENGTH] > 0;
            }
            else if (isDate(value)) {
                result = !isNaN(value.getTime());
            }
            else if (isBoolean(value)) {
                return true;
            }
            else if (isObject(value)) {
                try {
                    let chkValue = _checkLength(value, [LENGTH, "byteLength", "size", "count"]);
                    if (isBoolean(chkValue)) {
                        return chkValue;
                    }
                    if (isFunction(value.valueOf) && depth < 5) {
                        return _hasValue(value.valueOf(), ++depth);
                    }
                }
                catch (e) {
                }
                return !!objKeys(value)[LENGTH];
            }
            else {
                result = isTruthy(value);
            }
        }
        return result;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function hasValue(value) {
        return _hasValue(value, 0);
    }

    /*#__NO_SIDE_EFFECTS__*/
    function createArrayIterator(values) {
        let idx = -1;
        let theValues = values ? values.slice() : [];
        let len = theValues[LENGTH];
        function _value() {
            if (idx >= 0 && idx < len) {
                return theValues[idx];
            }
        }
        function _getNext() {
            idx++;
            return idx >= len;
        }
        let ctx = {
            n: _getNext
        };
        objDefine(ctx, "v", { g: _value });
        return createIterator(ctx);
    }

    function _asIterator(iter) {
        if (isIterator(iter)) {
            return iter;
        }
        if (isArrayLike(iter)) {
            return createArrayIterator(arrSlice(iter));
        }
        if (isIterable(iter)) {
            let iteratorFn = iter[getKnownSymbol(3 )];
            if (iteratorFn) {
                return fnCall(iteratorFn, iter);
            }
        }
        return createIterableIterator({
            n: function () {
                return true;
            }
        });
    }
    function _getIteratorThisArg(source, thisArg) {
        return isStrictNullOrUndefined(thisArg) ? source : thisArg;
    }
    function _doIteratorReturn(source, value) {
        source.return && source.return(value);
        return value;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function iterMap(iter, callbackfn, thisArg) {
        let source = _asIterator(iter);
        let index = 0;
        let isDone = false;
        return createIterableIterator({
            n: function () {
                if (!isDone) {
                    let next = source.next();
                    isDone = !!next.done;
                    if (!isDone) {
                        this.v = fnCall(callbackfn, _getIteratorThisArg(source, thisArg), next.value, index);
                        index++;
                    }
                }
                return isDone;
            },
            r: function (value) {
                return _doIteratorReturn(source, value);
            }
        });
    }

    /*#__NO_SIDE_EFFECTS__*/
    function iterFilter(iter, callbackfn, thisArg) {
        let source = _asIterator(iter);
        let index = 0;
        let isDone = false;
        return createIterableIterator({
            n: function () {
                let hasValue = false;
                while (!isDone && !hasValue) {
                    let next = source.next();
                    isDone = !!next.done;
                    if (!isDone) {
                        hasValue = !!fnCall(callbackfn, _getIteratorThisArg(source, thisArg), next.value, index);
                        if (hasValue) {
                            this.v = next.value;
                        }
                        index++;
                    }
                }
                return !hasValue;
            },
            r: function (value) {
                return _doIteratorReturn(source, value);
            }
        });
    }

    /*#__NO_SIDE_EFFECTS__*/
    function iterTake(iter, count) {
        let source = _asIterator(iter);
        let remaining = count > 0 ? mathFloor(count) : 0;
        let complete = false;
        function _complete(value) {
            if (!complete) {
                complete = true;
                return _doIteratorReturn(source, value);
            }
            return value;
        }
        return createIterableIterator({
            n: function () {
                let isDone = true;
                if (!complete) {
                    if (remaining <= 0) {
                        _complete();
                    }
                    else {
                        let next = source.next();
                        if (next.done) {
                            complete = true;
                        }
                        else {
                            this.v = next.value;
                            remaining--;
                            if (remaining <= 0) {
                                _complete();
                            }
                            isDone = false;
                        }
                    }
                }
                return isDone;
            },
            r: function (value) {
                return _complete(value);
            }
        });
    }

    /*#__NO_SIDE_EFFECTS__*/
    function iterReduce(iter, callbackfn, initialValue) {
        let source = _asIterator(iter);
        let hasAccumulator = arguments.length > 2;
        let accumulator = initialValue;
        iterForOf(source, (value, count) => {
            if (!hasAccumulator) {
                accumulator = value;
                hasAccumulator = true;
            }
            else {
                accumulator = callbackfn(accumulator, value, count, source);
            }
        });
        if (!hasAccumulator) {
            throwTypeError("Reduce of empty iterator with no initial value");
        }
        return accumulator;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function iterSome(iter, callbackfn, thisArg) {
        let source = _asIterator(iter);
        let matched = false;
        iterForOf(source, (value, count) => {
            if (fnCall(callbackfn, _getIteratorThisArg(source, thisArg), value, count)) {
                matched = true;
                return -1;
            }
        });
        return matched;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function iterEvery(iter, callbackfn, thisArg) {
        let source = _asIterator(iter);
        let allMatched = true;
        iterForOf(source, (value, count) => {
            if (!fnCall(callbackfn, _getIteratorThisArg(source, thisArg), value, count)) {
                allMatched = false;
                return -1;
            }
        });
        return allMatched;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function iterToArray(iter, mapFn, thisArg) {
        let source = _asIterator(iter);
        let values = [];
        if (isFunction(mapFn)) {
            iterForOf(source, (value, count) => {
                values.push(fnCall(mapFn, _getIteratorThisArg(source, thisArg), value, count || 0));
            });
        }
        else {
            iterForOf(source, (value) => {
                values.push(value);
            });
        }
        return values;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function iterUnion(...iters) {
        let result = [];
        for (let lp = 0; lp < iters.length; lp++) {
            iterForOf(iters[lp], (value) => {
                if (!arrIncludes(result, value)) {
                    result.push(value);
                }
            });
        }
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function iterIntersection(...iters) {
        if (iters.length === 0) {
            return [];
        }
        let result = [];
        let firstValues = iterToArray(iters[0]);
        let otherValues = [];
        for (let lp = 1; lp < iters.length; lp++) {
            otherValues.push(iterToArray(iters[lp]));
        }
        arrForEach(firstValues, (value) => {
            let inAll = true;
            arrForEach(otherValues, (other) => {
                if (!arrIncludes(other, value)) {
                    inAll = false;
                    return -1;
                }
            });
            if (inAll && !arrIncludes(result, value)) {
                result.push(value);
            }
        });
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function iterDifference(iter, ...excludeIters) {
        let sourceValues = iterToArray(iter);
        let excludedValues = [];
        arrForEach(excludeIters, (excludeIter) => {
            iterForOf(excludeIter, (value) => {
                if (!arrIncludes(excludedValues, value)) {
                    excludedValues.push(value);
                }
            });
        });
        let result = [];
        arrForEach(sourceValues, (value) => {
            if (!arrIncludes(excludedValues, value)) {
                result.push(value);
            }
        });
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function createRangeIterator(start, end, step) {
        let nextValue = start;
        let theValue = UNDEF_VALUE;
        if (isNullOrUndefined(end)) {
            end = start;
        }
        let theStep = step;
        if (!theStep) {
            theStep = (start <= end) ? 1 : -1;
        }
        function _value() {
            return theValue;
        }
        function _getNext() {
            let isDone = (theStep > 0) ? (nextValue > end) : (nextValue < end);
            if (!isDone) {
                theValue = nextValue;
                nextValue += theStep;
            }
            return isDone;
        }
        return createIterator(objDefine({
            n: _getNext
        }, "v", { g: _value }));
    }

    const mathAbs = (/*#__PURE__*/_pureRef(MathCls, "abs"));

    const mathExp = (/*#__PURE__*/_pureRef(MathCls, "exp"));
    const mathLog = (/*#__PURE__*/_pureRef(MathCls, "log"));

    const mathAsin = (/*#__PURE__*/_pureRef(MathCls, "asin"));
    const mathAcos = (/*#__PURE__*/_pureRef(MathCls, "acos"));
    const mathAtan = (/*#__PURE__*/_pureRef(MathCls, "atan"));
    const mathAtan2 = (/*#__PURE__*/_pureRef(MathCls, "atan2"));

    const mathPow = (/*#__PURE__*/_pureRef(MathCls, "pow"));
    const mathSqrt = (/*#__PURE__*/_pureRef(MathCls, "sqrt"));

    const mathRound = (/*#__PURE__*/_pureRef(MathCls, "round"));

    const mathSin = (/*#__PURE__*/_pureRef(MathCls, "sin"));
    const mathCos = (/*#__PURE__*/_pureRef(MathCls, "cos"));
    const mathTan = (/*#__PURE__*/_pureRef(MathCls, "tan"));

    function polyObjFromEntries(entries) {
        const result = {};
        function _defineProtoValue(value) {
            Object.defineProperty(result, __PROTO__, {
                value: value,
                enumerable: true,
                configurable: true,
                writable: true
            });
        }
        function addEntry(entry) {
            if (isArray(entry) && entry.length >= 2) {
                if (entry[0] === __PROTO__) {
                    _defineProtoValue(entry[1]);
                }
                else {
                    result[entry[0]] = entry[1];
                }
            }
        }
        if (isArray(entries)) {
            arrForEach(entries, addEntry);
        }
        else if (isIterable(entries)) {
            iterForOf(entries, addEntry);
        }
        return result;
    }

    const objFromEntries = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, "fromEntries")), polyObjFromEntries));

    const objPreventExtensions = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, "preventExtensions")), _doNothing));
    const objIsExtensible = (/*#__PURE__*/_pureAssign((/*#__PURE__*/_pureRef(ObjClass, "isExtensible")), _returnFalse));

    function objPick(source, keys) {
        const result = objCreate(null);
        if (source && isArrayLike(keys)) {
            arrForEach(keys, (key) => {
                if (objHasOwn(source, key) && _objPropertyIsEnumerable(source, key)) {
                    result[key] = source[key];
                }
            });
        }
        return result;
    }
    function objOmit(source, keys) {
        const result = objCreate(null);
        if (source && isArrayLike(keys)) {
            forEachOwnKey(source, (key, value) => {
                let hasKey = arrIndexOf(keys, key) !== -1;
                if (!hasKey && isString(key)) {
                    const numericKey = +key;
                    if (key === numericKey + "") {
                        if (numericKey === numericKey) {
                            hasKey = arrIndexOf(keys, numericKey) !== -1;
                        }
                        else {
                            arrForEach(keys, (candidate) => {
                                if (candidate !== candidate) {
                                    hasKey = true;
                                }
                            });
                        }
                    }
                }
                if (!hasKey) {
                    result[key] = value;
                }
            });
        }
        return result;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function objPickBy(source, predicate) {
        const result = objCreate(null);
        forEachOwnKey(source, (key, value) => {
            if (predicate(key, value)) {
                result[key] = value;
            }
        });
        return result;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function objOmitBy(source, predicate) {
        const result = objCreate(null);
        forEachOwnKey(source, (key, value) => {
            if (!predicate(key, value)) {
                result[key] = value;
            }
        });
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function objMapValues(source, mapper) {
        const result = objCreate(null);
        forEachOwnKey(source, (key, value) => {
            result[key] = mapper(value, key);
        });
        return result;
    }

    function objMergeIf(target, source, predicate) {
        if (target && source && !isUnsafeTarget(target)) {
            forEachOwnKeySafe(source, (key, value) => {
                if (predicate(key, value, target[key])) {
                    target[key] = value;
                }
            });
        }
        return target;
    }
    function objDefaults(target, ...sources) {
        if (target && !isUnsafeTarget(target)) {
            arrForEach(sources, (source) => {
                if (source) {
                    forEachOwnKeySafe(source, (key, value) => {
                        if (isStrictUndefined(target[key])) {
                            target[key] = value;
                        }
                    });
                }
            });
        }
        return target;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function objDiff(base, modified) {
        const result = objCreate(null);
        if (!isStrictNullOrUndefined(base)) {
            forEachOwnKey(modified, (key, value) => {
                const hasBase = objHasOwn(base, key);
                const baseVal = hasBase ? base[key] : undefined;
                if (!hasBase || baseVal !== value) {
                    result[key] = value;
                }
            });
        }
        return result;
    }

    const strIndexOf = (/*#__PURE__*/_unwrapFunction("indexOf", StrProto));
    const strLastIndexOf = (/*#__PURE__*/_unwrapFunction("lastIndexOf", StrProto));

    /*#__NO_SIDE_EFFECTS__*/
    function strCount(value, searchString) {
        _throwIfNullOrUndefined(value);
        let count = 0;
        let pos = 0;
        let matcher = asString(searchString);
        if (matcher !== EMPTY) {
            let theValue = asString(value);
            while ((pos = strIndexOf(theValue, matcher, pos)) !== -1) {
                count++;
                pos += matcher[LENGTH];
            }
        }
        return count;
    }

    const strAt = (/*#__PURE__*/_unwrapFunctionWithPoly("at", StrProto, polyStrAt));
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrAt(value, index) {
        _throwIfNullOrUndefined(value);
        return polyArrAt(asString(value), mathToInt(index));
    }

    const strEndsWith = (/*#__PURE__*/_unwrapFunctionWithPoly("endsWith", StrProto, polyStrEndsWith));
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrEndsWith(value, searchString, length) {
        _throwIfNotString(value);
        let searchValue = isString(searchString) ? searchString : asString(searchString);
        let end = (!isUndefined(length) && length < value[LENGTH]) ? length : value[LENGTH];
        return strSubstring(value, end - searchValue[LENGTH], end) === searchValue;
    }

    const strIncludes = (/*#__PURE__*/_unwrapFunctionWithPoly("includes", StrProto, polyStrIncludes));
    const strContains = (/*#__PURE__*/_pureAssign(strIncludes));
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrIncludes(value, searchString, position) {
        if (isRegExp(searchString)) {
            throwTypeError("'searchString' must not be a regular expression" + dumpObj(searchString));
        }
        return strIndexOf(value, asString(searchString), position) !== -1;
    }

    const strMatchAll = (/*#__PURE__*/_unwrapFunctionWithPoly("matchAll", StrProto, polyStrMatchAll));
    /*#__NO_SIDE_EFFECTS__*/
    function _cloneRegExp(theRegex) {
        let flags = theRegex.flags;
        if (flags === undefined) {
            flags = EMPTY;
            theRegex.global && (flags += "g");
            theRegex.ignoreCase && (flags += "i");
            theRegex.multiline && (flags += "m");
            theRegex.dotAll && (flags += "s");
            theRegex.unicode && (flags += "u");
            theRegex.sticky && (flags += "y");
        }
        let result = new RegExp(theRegex.source, flags);
        result.lastIndex = mathMax(0, theRegex.lastIndex);
        return result;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _advanceStringIndex(value, index, unicode) {
        let newIndex = index + 1;
        if (unicode) {
            if (index < value.length) {
                let first = value.charCodeAt(index);
                if (first >= 0xD800 && first <= 0xDBFF) {
                    let second = value.charCodeAt(index + 1);
                    if (second >= 0xDC00 && second <= 0xDFFF) {
                        newIndex++;
                    }
                }
            }
        }
        return newIndex;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrMatchAll(value, matcher) {
        _throwIfNullOrUndefined(value);
        let result;
        let matchSym = getKnownSymbol(4 );
        let isMatcherRegExp = isRegExp(matcher)
            && (!matcher || isStrictNullOrUndefined(matcher[matchSym]) || matcher[matchSym] !== false);
        if (isMatcherRegExp && !matcher.global) {
            throwTypeError("matcher must be a global regular expression");
        }
        let theValue = asString(value);
        let matchAllFn = matcher && matcher[getKnownSymbol(5 )];
        if (isFunction(matchAllFn)) {
            result = matchAllFn.call(matcher, theValue);
        }
        else {
            let theRegex = isMatcherRegExp ? _cloneRegExp(matcher) : new RegExp(matcher, "g");
            let ctx = {
                n: () => {
                    let match = theRegex.exec(theValue);
                    if (!match) {
                        return true;
                    }
                    if (match[0] === EMPTY) {
                        theRegex.lastIndex = _advanceStringIndex(theValue, theRegex.lastIndex, !!theRegex.unicode);
                    }
                    ctx.v = match;
                    return false;
                },
                v: undefined
            };
            result = createIterableIterator(ctx);
        }
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function strIsNullOrWhiteSpace(value) {
        if (isString(value)) {
            return strReplace(value, /[\s\t\r\n\f]+/g, EMPTY) === EMPTY;
        }
        return isNullOrUndefined(value);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function strIsNullOrEmpty(value) {
        if (isString(value)) {
            return value === EMPTY;
        }
        return isNullOrUndefined(value);
    }

    const strReplaceAll = (/*#__PURE__*/_unwrapFunctionWithPoly("replaceAll", StrProto, polyStrReplaceAll));
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrReplaceAll(value, searchValue, replaceValue) {
        _throwIfNullOrUndefined(value);
        let matchSymbol = getKnownSymbol(4 );
        let replaceSymbol = getKnownSymbol(6 );
        let replaceFn;
        let matcher;
        let isRegex = isRegExp(searchValue);
        let theValue = isString(value) ? value : asString(value);
        let isSearchNotNull = searchValue || !isStrictNullOrUndefined(searchValue);
        if (isRegex && isSearchNotNull) {
            isRegex = searchValue[matchSymbol] !== false;
        }
        if (isRegex) {
            if (!searchValue.global) {
                throwTypeError("searchValue must be a global regular expression");
            }
            matcher = searchValue;
        }
        else {
            replaceFn = isSearchNotNull ? searchValue[replaceSymbol] : null;
            if (isFunction(replaceFn)) {
                return replaceFn.call(searchValue, theValue, replaceValue);
            }
            let search = isString(searchValue) ? searchValue : asString(searchValue);
            matcher = createLiteralRegex(search);
        }
        return strReplace(theValue, matcher, replaceValue);
    }

    const strStartsWith = (/*#__PURE__*/_unwrapFunctionWithPoly("startsWith", StrProto, polyStrStartsWith));
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrStartsWith(value, searchString, position) {
        _throwIfNotString(value);
        let searchValue = isString(searchString) ? searchString : asString(searchString);
        let pos = position > 0 ? position : 0;
        return strSubstring(value, pos, pos + searchValue[LENGTH]) === searchValue;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function strStartsWithAny(value, searchValues, position) {
        _throwIfNullOrUndefined(value);
        let result = false;
        if (searchValues && searchValues[LENGTH]) {
            arrForEach(searchValues, (searchValue) => {
                if (strStartsWith(value, searchValue, position)) {
                    result = true;
                    return -1;
                }
            });
        }
        return result;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function strEndsWithAny(value, searchValues, length) {
        _throwIfNullOrUndefined(value);
        let result = false;
        if (searchValues && searchValues[LENGTH]) {
            arrForEach(searchValues, (searchValue) => {
                if (strEndsWith(value, searchValue, length)) {
                    result = true;
                    return -1;
                }
            });
        }
        return result;
    }

    const _validNewlines = ["\n", "\r\n", "\r", "\n\r"];
    /*#__NO_SIDE_EFFECTS__*/
    function strNormalizeNewlines(value, newlineType) {
        _throwIfNullOrUndefined(value);
        let target = newlineType !== undefined ? newlineType : "\n";
        if (arrIndexOf(_validNewlines, target) === -1) {
            throwTypeError("Unsupported newlineType value");
        }
        return strReplace(asString(value), /\r\n|\n\r|\r|\n/g, target);
    }

    /*#__NO_SIDE_EFFECTS__*/
    function strTruncate(value, maxLength, suffix) {
        _throwIfNullOrUndefined(value);
        let result;
        let length = mathToInt(maxLength);
        if (length > 0) {
            result = asString(value);
            if (result[LENGTH] > length) {
                let theSuffix = (!suffix && isNullOrUndefined(suffix)) ? EMPTY : asString(suffix);
                if (theSuffix[LENGTH] >= length) {
                    result = strLeft(theSuffix, length);
                }
                else {
                    result = strLeft(result, length - theSuffix[LENGTH]) + theSuffix;
                }
            }
        }
        return result || EMPTY;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function strWrap(value, prefix, suffix) {
        _throwIfNullOrUndefined(value);
        return prefix + asString(value) + (isNullOrUndefined(suffix) ? prefix : suffix);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function strUnwrap(value, prefix, suffix) {
        _throwIfNullOrUndefined(value);
        let theValue = asString(value);
        let close = isNullOrUndefined(suffix) ? prefix : suffix;
        if (strStartsWith(theValue, prefix) && strEndsWith(theValue, close) && theValue[LENGTH] >= (prefix[LENGTH] + close[LENGTH])) {
            theValue = strSubstring(theValue, prefix[LENGTH], theValue[LENGTH] - close[LENGTH]);
        }
        return theValue;
    }

    const REF = "ref";
    const UNREF = "unref";
    const HAS_REF = "hasRef";
    const ENABLED = "enabled";
    /*#__NO_SIDE_EFFECTS__*/
    function _createTimerHandler(startTimer, refreshFn, cancelFn) {
        let ref = true;
        let timerId = startTimer ? refreshFn(NULL_VALUE) : NULL_VALUE;
        let theTimerHandler;
        function _unref() {
            ref = false;
            timerId && timerId[UNREF] && timerId[UNREF]();
            return theTimerHandler;
        }
        function _cancel() {
            timerId && cancelFn(timerId);
            timerId = NULL_VALUE;
        }
        function _refresh() {
            timerId = refreshFn(timerId);
            if (!ref) {
                _unref();
            }
            return theTimerHandler;
        }
        function _setEnabled(value) {
            !value && timerId && _cancel();
            value && !timerId && _refresh();
        }
        theTimerHandler = {
            cancel: _cancel,
            refresh: _refresh
        };
        theTimerHandler[HAS_REF] = () => {
            if (timerId && timerId[HAS_REF]) {
                return timerId[HAS_REF]();
            }
            return ref;
        };
        theTimerHandler[REF] = () => {
            ref = true;
            timerId && timerId[REF] && timerId[REF]();
            return theTimerHandler;
        };
        theTimerHandler[UNREF] = _unref;
        theTimerHandler = objDefineProp(theTimerHandler, ENABLED, {
            get: () => !!timerId,
            set: _setEnabled
        });
        return {
            h: theTimerHandler,
            dn: () => {
                timerId = NULL_VALUE;
            }
        };
    }

    let _setTimeoutFn;
    let _clearTimeoutFn;
    let _microtaskCallback;
    function _resolveTimeoutFn(timeoutFn) {
        let result = isFunction(timeoutFn) ? timeoutFn : _setTimeoutFn;
        if (!result) {
            let globalOverrides = _getGlobalConfig().tmOut || [];
            if (isArray(globalOverrides) && globalOverrides.length > 0 && isFunction(globalOverrides[0])) {
                result = globalOverrides[0];
            }
        }
        return result || setTimeout;
    }
    function _resolveClearTimeoutFn(timeoutFn) {
        let result = isFunction(timeoutFn) ? timeoutFn : _clearTimeoutFn;
        if (!result) {
            let globalOverrides = _getGlobalConfig().tmOut || [];
            if (isArray(globalOverrides) && globalOverrides.length > 1 && isFunction(globalOverrides[1])) {
                result = globalOverrides[1];
            }
        }
        return result || clearTimeout;
    }
    function _createTimeoutWith(startTimer, overrideFn, theArgs) {
        let isArr = isArray(overrideFn);
        let len = isArr ? overrideFn.length : 0;
        let setFn = _resolveTimeoutFn(len > 0 ? overrideFn[0] : (!isArr ? overrideFn : UNDEF_VALUE));
        let clearFn = _resolveClearTimeoutFn(len > 1 ? overrideFn[1] : UNDEF_VALUE);
        let timerFn = theArgs[0];
        theArgs[0] = function () {
            let microTasksFn = _microtaskCallback;
            if (microTasksFn) {
                _microtaskCallback = UNDEF_VALUE;
                microTasksFn();
            }
            handler.dn();
            fnApply(timerFn, UNDEF_VALUE, ArrSlice[CALL](arguments));
        };
        let handler = _createTimerHandler(startTimer, (timerId) => {
            if (timerId) {
                if (timerId.refresh) {
                    timerId.refresh();
                    return timerId;
                }
                fnApply(clearFn, UNDEF_VALUE, [timerId]);
            }
            return fnApply(setFn, UNDEF_VALUE, theArgs);
        }, function (timerId) {
            fnApply(clearFn, UNDEF_VALUE, [timerId]);
        });
        return handler.h;
    }
    function _setMicrotaskCallback(queueFn) {
        if (!_microtaskCallback && isFunction(queueFn)) {
            _microtaskCallback = queueFn;
        }
    }
    function setTimeoutOverrides(overrideFn) {
        let isArr = isArray(overrideFn);
        let len = isArr ? overrideFn.length : 0;
        _setTimeoutFn = (len > 0 ? overrideFn[0] : (!isArr ? overrideFn : UNDEF_VALUE));
        _clearTimeoutFn = (len > 1 ? overrideFn[1] : UNDEF_VALUE);
    }
    function setGlobalTimeoutOverrides(overrideFn) {
        let isArr = isArray(overrideFn);
        let len = isArr ? overrideFn.length : 0;
        let globalCfg = _getGlobalConfig();
        if (!overrideFn) {
            globalCfg.tmOut = undefined;
        }
        else {
            globalCfg.tmOut = [
                (len > 0 ? overrideFn[0] : (!isArr ? overrideFn : null)),
                (len > 1 ? overrideFn[1] : null)
            ];
        }
    }
    function scheduleTimeout(callback, timeout) {
        return _createTimeoutWith(true, UNDEF_VALUE, ArrSlice[CALL](arguments));
    }
    function scheduleTimeoutWith(overrideFn, callback, timeout) {
        return _createTimeoutWith(true, overrideFn, ArrSlice[CALL](arguments, 1));
    }
    function createTimeout(callback, timeout) {
        return _createTimeoutWith(false, UNDEF_VALUE, ArrSlice[CALL](arguments));
    }
    function createTimeoutWith(overrideFn, callback, timeout) {
        return _createTimeoutWith(false, overrideFn, ArrSlice[CALL](arguments, 1));
    }

    let _defaultIdleTimeout = 100;
    let _maxExecutionTime = 50;
    /*#__NO_SIDE_EFFECTS__*/
    function hasIdleCallback() {
        return !!getIdleCallback();
    }
    const getIdleCallback = (/*#__PURE__*/_getGlobalInstFn(getInst, ["requestIdleCallback"]));
    const getCancelIdleCallback = (/*#__PURE__*/_getGlobalInstFn(getInst, ["cancelIdleCallback"]));
    function setDefaultIdleTimeout(timeout) {
        _defaultIdleTimeout = timeout;
    }
    function setDefaultMaxExecutionTime(maxTime) {
        _maxExecutionTime = maxTime;
    }
    function scheduleIdleCallback(callback, options) {
        function _createDeadline(timedOut) {
            let startTime = perfNow();
            return {
                didTimeout: timedOut,
                timeRemaining: () => {
                    return _maxExecutionTime - elapsedTime(startTime);
                }
            };
        }
        if (hasIdleCallback()) {
            let handler = _createTimerHandler(true, (idleId) => {
                idleId && getCancelIdleCallback()(idleId);
                return getIdleCallback()((deadline) => {
                    handler.dn();
                    callback(deadline || _createDeadline(false));
                }, options);
            }, (idleId) => {
                getCancelIdleCallback()(idleId);
            });
            return handler.h;
        }
        let timeout = (options || {}).timeout;
        if (isUndefined(timeout)) {
            timeout = _defaultIdleTimeout;
        }
        return scheduleTimeout(() => {
            callback(_createDeadline(true));
        }, timeout);
    }

    function scheduleInterval(callback, timeout) {
        let theArguments = ArrSlice[CALL](arguments);
        let handler = _createTimerHandler(true, (intervalId) => {
            intervalId && clearInterval(intervalId);
            return fnApply(setInterval, UNDEF_VALUE, theArguments);
        }, (intervalId) => {
            fnApply(clearInterval, UNDEF_VALUE, [intervalId]);
        });
        return handler.h;
    }

    function _createCancellableTask(callback, queueFn, maxQueuedTasks) {
        let handler;
        let currentTask = 0;
        function _scheduleTask() {
            let taskId = ++currentTask;
            let queued = queueFn(() => {
                if (taskId === currentTask) {
                    handler.dn();
                    callback();
                }
            }, maxQueuedTasks);
            if (queued === false) {
                handler.dn();
            }
            return taskId;
        }
        function _cancelTask(taskId) {
            if (taskId === currentTask) {
                currentTask++;
            }
        }
        handler = _createTimerHandler(false, _scheduleTask, _cancelTask);
        handler.h.refresh();
        return handler.h;
    }

    function _runMicroTask(callback) {
        try {
            if (callback) {
                callback();
            }
        }
        catch (e) {
            scheduleTimeout(() => {
                throw e;
            }, 0);
        }
    }

    let _taskQueues;
    function _flushQueues() {
        if (_taskQueues) {
            _taskQueues[1 ] && _flushTaskQueue(1 );
            _taskQueues[0 ] && _flushTaskQueue(0 );
        }
    }
    function _flushTaskQueue(queueType) {
        if (_taskQueues) {
            let queue = _taskQueues[queueType];
            let queueIdx = 0;
            while (queue && queue.length > queueIdx) {
                _runMicroTask(queue[queueIdx++]);
                if (queueType === 0  && _taskQueues[1 ]) {
                    _flushTaskQueue(1 );
                }
            }
            _taskQueues[queueType] = UNDEF_VALUE;
        }
    }
    function _addToQueue(queueType, callback, maxQueuedTasks) {
        let result = false;
        if (!_taskQueues) {
            _taskQueues = {};
        }
        let queue = _taskQueues[queueType];
        if (!queue) {
            queue = [];
            _taskQueues[queueType] = queue;
        }
        if (isStrictUndefined(maxQueuedTasks) || maxQueuedTasks === 0 || (queue.length < maxQueuedTasks)) {
            queue.push(callback);
            result = true;
        }
        else {
            throwRangeError("schedule" + (queueType === 0  ? "Microtask" : "NextTick") + "() queue depth exceeded [" + maxQueuedTasks + "]");
        }
        return result;
    }

    let _promiseCls;
    let _promisePending = false;
    let _pendingPromiseCls;
    let _promiseQueueFns;
    function _ensurePromiseTask(promiseCls) {
        if (_promisePending && _pendingPromiseCls !== promiseCls) {
            _promisePending = false;
        }
        if (!_promisePending) {
            _promisePending = true;
            _pendingPromiseCls = promiseCls;
            try {
                promiseCls.resolve().then(() => {
                    _promisePending = false;
                    _pendingPromiseCls = undefined;
                    _flushQueues();
                });
            }
            catch (e) {
                _promisePending = false;
                _pendingPromiseCls = undefined;
                _flushQueues();
            }
        }
    }
    function _promiseScheduleFn(promiseCls, queueType) {
        return function (callback, maxQueuedTasks) {
            let added = _addToQueue(queueType, callback, maxQueuedTasks);
            if (added) {
                _ensurePromiseTask(promiseCls);
            }
            return added;
        };
    }
    function _getPromiseQueueFn(queueType) {
        !_globalLazyTestHooks && _initTestHooks();
        if (!_promiseCls || _globalLazyTestHooks.lzy) {
            let promClass = getInst("Promise");
            if (promClass && isFunction(promClass.resolve)) {
                _promiseCls = createCachedValue(promClass);
                _promiseQueueFns = undefined;
            }
            else {
                _promiseCls = undefined;
                _promiseQueueFns = undefined;
                _promisePending = false;
                _pendingPromiseCls = undefined;
            }
        }
        let result;
        if (_promiseCls && _promiseCls.v) {
            !_promiseQueueFns && (_promiseQueueFns = {});
            result = _promiseQueueFns[queueType];
            if (!result) {
                result = _promiseScheduleFn(_promiseCls.v, queueType);
                _promiseQueueFns[queueType] = result;
            }
        }
        return result;
    }

    function _resolveScheduleFn(options, defaultOptions, taskQueueType) {
        let resolvedFn = (options && options.scheduleFn) || (defaultOptions && defaultOptions.scheduleFn);
        if (!resolvedFn) {
            let usePromise = !((options && !isStrictUndefined(options.useTimeout))
                ? options.useTimeout
                : (defaultOptions && defaultOptions.useTimeout));
            if (usePromise) {
                resolvedFn = _getPromiseQueueFn(taskQueueType);
            }
        }
        return resolvedFn;
    }

    let _sharedTimer;
    let _isFlushing = false;
    function _doFlush() {
        try {
            _isFlushing = true;
            _flushQueues();
        }
        finally {
            _isFlushing = false;
        }
    }
    function _ensureSharedTimer() {
        if (_isFlushing) {
            return;
        }
        _setMicrotaskCallback(_doFlush);
        let handler = _sharedTimer;
        if (!handler) {
            _sharedTimer = scheduleTimeout(_returnNothing, 0);
        }
        else if (!handler.enabled) {
            handler.refresh();
        }
    }
    function _addNextTickToQueue(callback, maxQueuedTasks) {
        return _addToQueueWithTimer(1 , callback, maxQueuedTasks);
    }
    function _addMicrotaskQueue(callback, maxQueuedTasks) {
        return _addToQueueWithTimer(0 , callback, maxQueuedTasks);
    }
    function _addToQueueWithTimer(queueType, callback, maxQueuedTasks) {
        let result = _addToQueue(queueType, callback, maxQueuedTasks);
        if (result) {
            _ensureSharedTimer();
        }
        return result;
    }

    let _defaultOptions$1;
    function setMicroTaskFallbackOptions(options) {
        _defaultOptions$1 = options;
    }
    function scheduleMicrotask(callback, argsOrOptions, options) {
        let callbackArgs;
        let theOptions;
        if (arguments.length > 1 && argsOrOptions && isArray(argsOrOptions)) {
            callbackArgs = argsOrOptions;
            theOptions = options;
        }
        else {
            theOptions = argsOrOptions;
        }
        let taskCallback = callbackArgs ? fnBindArgs(callback, UNDEF_VALUE, callbackArgs) : callback;
        let queueMicrotaskFn = getQueueMicrotask();
        if (!queueMicrotaskFn) {
            queueMicrotaskFn = _resolveScheduleFn(theOptions, _defaultOptions$1, 0 );
        }
        return _createCancellableTask(taskCallback, queueMicrotaskFn || _addMicrotaskQueue);
    }

    let _nextTickFn;
    function _nextTickScheduleFn(processInst) {
        return function (callback) {
            processInst.nextTick(() => {
                _runMicroTask(callback);
            });
        };
    }
    function _resolveProcessNextTickFn() {
        let processInst = getInst("process");
        return (isNode() && processInst && isFunction(processInst.nextTick)) ? _nextTickScheduleFn(processInst) : UNDEF_VALUE;
    }
    function _getProcessNextTickFn() {
        !_globalLazyTestHooks && _initTestHooks();
        if (!_nextTickFn || _globalLazyTestHooks.lzy) {
            _nextTickFn = createCachedValue(_resolveProcessNextTickFn());
        }
        return _nextTickFn.v;
    }

    let _microtaskPending = false;
    let _pendingMicrotaskFn;
    let _microtaskQueueFns;
    function _ensureMicrotask(microtaskFn) {
        if (_microtaskPending && _pendingMicrotaskFn !== microtaskFn) {
            _microtaskPending = false;
        }
        if (!_microtaskPending) {
            _microtaskPending = true;
            _pendingMicrotaskFn = microtaskFn;
            try {
                microtaskFn(() => {
                    _microtaskPending = false;
                    _pendingMicrotaskFn = undefined;
                    _flushQueues();
                });
            }
            catch (e) {
                _microtaskPending = false;
                _pendingMicrotaskFn = undefined;
                _flushQueues();
            }
        }
    }
    function _microtaskScheduleFn(microtaskFn, queueType) {
        return function (callback, maxQueuedTasks) {
            let added = _addToQueue(queueType, callback, maxQueuedTasks);
            if (added) {
                _ensureMicrotask(microtaskFn);
            }
            return added;
        };
    }
    function _getMicrotaskQueueFn(queueType) {
        let result;
        let queueFn = getQueueMicrotask();
        if (queueFn) {
            !_microtaskQueueFns && (_microtaskQueueFns = {});
            result = _microtaskQueueFns[queueType];
            if (!result) {
                result = _microtaskScheduleFn(queueFn, queueType);
                _microtaskQueueFns[queueType] = result;
            }
        }
        return result;
    }

    const _defaultMaxQueuedTasks = 1000;
    let _defaultOptions;
    function setNextTickFallbackOptions(options) {
        _defaultOptions = options;
    }
    const getProcessNextTick = (/*#__PURE__*/_getGlobalInstFn(() => {
        let processInst = getInst("process");
        return isNode() && processInst && isFunction(processInst.nextTick) ? processInst.nextTick : null;
    }));
    /*#__NO_SIDE_EFFECTS__*/
    function hasProcessNextTick() {
        return !!getProcessNextTick();
    }
    function scheduleNextTick(callback, argsOrOptions, options) {
        let callbackArgs;
        let theOptions;
        if (arguments.length > 1 && argsOrOptions && isArray(argsOrOptions)) {
            callbackArgs = argsOrOptions;
            theOptions = options;
        }
        else {
            theOptions = argsOrOptions;
        }
        let taskCallback = callbackArgs ? fnBindArgs(callback, UNDEF_VALUE, callbackArgs) : callback;
        let nextTickFn = _getProcessNextTickFn() || _getMicrotaskQueueFn(1 );
        let maxQueuedTasks = (theOptions && !isStrictUndefined(theOptions.maxQueuedTasks))
            ? theOptions.maxQueuedTasks
            : ((_defaultOptions && !isStrictUndefined(_defaultOptions.maxQueuedTasks))
                ? _defaultOptions.maxQueuedTasks
                : _defaultMaxQueuedTasks);
        if (!nextTickFn) {
            nextTickFn = _resolveScheduleFn(theOptions, _defaultOptions, 1 );
        }
        return _createCancellableTask(taskCallback, nextTickFn || _addNextTickToQueue, maxQueuedTasks);
    }

    exports.arrAppend = arrAppend;
    exports.arrAt = arrAt;
    exports.arrChunk = arrChunk;
    exports.arrCompact = arrCompact;
    exports.arrConcat = arrConcat;
    exports.arrContains = arrContains;
    exports.arrDifference = arrDifference;
    exports.arrDrop = arrDrop;
    exports.arrDropWhile = arrDropWhile;
    exports.arrEvery = arrEvery;
    exports.arrFill = arrFill;
    exports.arrFilter = arrFilter;
    exports.arrFind = arrFind;
    exports.arrFindIndex = arrFindIndex;
    exports.arrFindLast = arrFindLast;
    exports.arrFindLastIndex = arrFindLastIndex;
    exports.arrFlatMap = arrFlatMap;
    exports.arrFlatten = arrFlatten;
    exports.arrForEach = arrForEach;
    exports.arrFrom = arrFrom;
    exports.arrGroupBy = arrGroupBy;
    exports.arrIncludes = arrIncludes;
    exports.arrIndexKeys = arrIndexKeys;
    exports.arrIndexOf = arrIndexOf;
    exports.arrIntersection = arrIntersection;
    exports.arrKeys = arrKeys;
    exports.arrLastIndexOf = arrLastIndexOf;
    exports.arrMap = arrMap;
    exports.arrPartition = arrPartition;
    exports.arrReduce = arrReduce;
    exports.arrReverse = arrReverse;
    exports.arrRotate = arrRotate;
    exports.arrSample = arrSample;
    exports.arrShuffle = arrShuffle;
    exports.arrSlice = arrSlice;
    exports.arrSome = arrSome;
    exports.arrTake = arrTake;
    exports.arrTakeWhile = arrTakeWhile;
    exports.arrToMap = arrToMap;
    exports.arrUnion = arrUnion;
    exports.arrUnique = arrUnique;
    exports.arrUnzip = arrUnzip;
    exports.arrWith = arrWith;
    exports.arrZip = arrZip;
    exports.arrayDeepCopyHandler = arrayDeepCopyHandler;
    exports.asString = asString;
    exports.createArrayIterator = createArrayIterator;
    exports.createCachedValue = createCachedValue;
    exports.createCustomError = createCustomError;
    exports.createDeferredCachedValue = createDeferredCachedValue;
    exports.createEnum = createEnum;
    exports.createEnumKeyMap = createEnumKeyMap;
    exports.createEnumValueMap = createEnumValueMap;
    exports.createFilenameRegex = createFilenameRegex;
    exports.createFnDeferredProxy = createFnDeferredProxy;
    exports.createIterable = createIterable;
    exports.createIterableIterator = createIterableIterator;
    exports.createIterator = createIterator;
    exports.createLiteralRegex = createLiteralRegex;
    exports.createProxyFuncs = createProxyFuncs;
    exports.createRangeIterator = createRangeIterator;
    exports.createSimpleMap = createSimpleMap;
    exports.createTimeout = createTimeout;
    exports.createTimeoutWith = createTimeoutWith;
    exports.createTypeMap = createTypeMap;
    exports.createWildcardRegex = createWildcardRegex;
    exports.dateDeepCopyHandler = dateDeepCopyHandler;
    exports.decodeBase64 = decodeBase64;
    exports.decodeBase64Url = decodeBase64Url;
    exports.decodeHex = decodeHex;
    exports.decodeUri = decodeUri;
    exports.deepExtend = deepExtend;
    exports.dumpObj = dumpObj;
    exports.elapsedTime = elapsedTime;
    exports.encodeAsBase64 = encodeAsBase64;
    exports.encodeAsBase64Url = encodeAsBase64Url;
    exports.encodeAsHex = encodeAsHex;
    exports.encodeAsHtml = encodeAsHtml;
    exports.encodeAsJson = encodeAsJson;
    exports.encodeAsUri = encodeAsUri;
    exports.fnApply = fnApply;
    exports.fnBind = fnBind;
    exports.fnBindArgs = fnBindArgs;
    exports.fnCall = fnCall;
    exports.forEachOwnKey = forEachOwnKey;
    exports.forEachOwnKeySafe = forEachOwnKeySafe;
    exports.functionDeepCopyHandler = functionDeepCopyHandler;
    exports.getCancelIdleCallback = getCancelIdleCallback;
    exports.getDeferred = getDeferred;
    exports.getDocument = getDocument;
    exports.getGlobal = getGlobal;
    exports.getHistory = getHistory;
    exports.getIdleCallback = getIdleCallback;
    exports.getInst = getInst;
    exports.getIntValue = getIntValue;
    exports.getKnownSymbol = getKnownSymbol;
    exports.getLazy = getLazy;
    exports.getLength = getLength;
    exports.getNavigator = getNavigator;
    exports.getPerformance = getPerformance;
    exports.getProcessNextTick = getProcessNextTick;
    exports.getQueueMicrotask = getQueueMicrotask;
    exports.getSymbol = getSymbol;
    exports.getValueByIter = getValueByIter;
    exports.getValueByKey = getValueByKey;
    exports.getWindow = getWindow;
    exports.getWritableDeferred = getWritableDeferred;
    exports.getWritableLazy = getWritableLazy;
    exports.hasDocument = hasDocument;
    exports.hasHistory = hasHistory;
    exports.hasIdleCallback = hasIdleCallback;
    exports.hasNavigator = hasNavigator;
    exports.hasPerformance = hasPerformance;
    exports.hasProcessNextTick = hasProcessNextTick;
    exports.hasQueueMicrotask = hasQueueMicrotask;
    exports.hasSymbol = hasSymbol;
    exports.hasValue = hasValue;
    exports.hasWindow = hasWindow;
    exports.isArray = isArray;
    exports.isArrayBuffer = isArrayBuffer;
    exports.isArrayLike = isArrayLike;
    exports.isAsyncFunction = isAsyncFunction;
    exports.isAsyncGenerator = isAsyncGenerator;
    exports.isAsyncIterable = isAsyncIterable;
    exports.isBigInt = isBigInt;
    exports.isBlob = isBlob;
    exports.isBoolean = isBoolean;
    exports.isDate = isDate;
    exports.isDefined = isDefined;
    exports.isElement = isElement;
    exports.isElementLike = isElementLike;
    exports.isEmpty = isEmpty;
    exports.isError = isError;
    exports.isFile = isFile;
    exports.isFiniteNumber = isFiniteNumber;
    exports.isFormData = isFormData;
    exports.isFunction = isFunction;
    exports.isGenerator = isGenerator;
    exports.isInteger = isInteger;
    exports.isIntegerInRange = isIntegerInRange;
    exports.isIterable = isIterable;
    exports.isIterator = isIterator;
    exports.isMap = isMap;
    exports.isMapLike = isMapLike;
    exports.isNode = isNode;
    exports.isNotTruthy = isNotTruthy;
    exports.isNullOrUndefined = isNullOrUndefined;
    exports.isNumber = isNumber;
    exports.isObject = isObject;
    exports.isPlainObject = isPlainObject;
    exports.isPrimitive = isPrimitive;
    exports.isPrimitiveType = isPrimitiveType;
    exports.isPromise = isPromise;
    exports.isPromiseLike = isPromiseLike;
    exports.isRegExp = isRegExp;
    exports.isSet = isSet;
    exports.isSetLike = isSetLike;
    exports.isStrictNullOrUndefined = isStrictNullOrUndefined;
    exports.isStrictUndefined = isStrictUndefined;
    exports.isString = isString;
    exports.isSymbol = isSymbol;
    exports.isThenable = isThenable;
    exports.isTruthy = isTruthy;
    exports.isTypeof = isTypeof;
    exports.isUndefined = isUndefined;
    exports.isUnsafePropKey = isUnsafePropKey;
    exports.isUnsafeTarget = isUnsafeTarget;
    exports.isWeakMap = isWeakMap;
    exports.isWeakSet = isWeakSet;
    exports.isWebWorker = isWebWorker;
    exports.iterDifference = iterDifference;
    exports.iterEvery = iterEvery;
    exports.iterFilter = iterFilter;
    exports.iterForOf = iterForOf;
    exports.iterIntersection = iterIntersection;
    exports.iterMap = iterMap;
    exports.iterReduce = iterReduce;
    exports.iterSome = iterSome;
    exports.iterTake = iterTake;
    exports.iterToArray = iterToArray;
    exports.iterUnion = iterUnion;
    exports.lazySafeGetInst = lazySafeGetInst;
    exports.makeGlobRegex = makeGlobRegex;
    exports.makeIterable = makeIterable;
    exports.mathAbs = mathAbs;
    exports.mathAcos = mathAcos;
    exports.mathAsin = mathAsin;
    exports.mathAtan = mathAtan;
    exports.mathAtan2 = mathAtan2;
    exports.mathCeil = mathCeil;
    exports.mathCos = mathCos;
    exports.mathExp = mathExp;
    exports.mathFloor = mathFloor;
    exports.mathLog = mathLog;
    exports.mathMax = mathMax;
    exports.mathMin = mathMin;
    exports.mathPow = mathPow;
    exports.mathRandom = mathRandom;
    exports.mathRound = mathRound;
    exports.mathSin = mathSin;
    exports.mathSqrt = mathSqrt;
    exports.mathTan = mathTan;
    exports.mathToInt = mathToInt;
    exports.mathTrunc = mathTrunc;
    exports.newSymbol = newSymbol;
    exports.normalizeJsName = normalizeJsName;
    exports.objAssign = objAssign;
    exports.objCopyProps = objCopyProps;
    exports.objCreate = objCreate;
    exports.objDeepCopy = objDeepCopy;
    exports.objDeepFreeze = objDeepFreeze;
    exports.objDefaults = objDefaults;
    exports.objDefine = objDefine;
    exports.objDefineAccessors = objDefineAccessors;
    exports.objDefineGet = objDefineGet;
    exports.objDefineProp = objDefineProp;
    exports.objDefineProperties = objDefineProperties;
    exports.objDefineProps = objDefineProps;
    exports.objDiff = objDiff;
    exports.objEntries = objEntries;
    exports.objExtend = objExtend;
    exports.objForEachKey = objForEachKey;
    exports.objForEachKeySafe = objForEachKeySafe;
    exports.objFreeze = objFreeze;
    exports.objFromEntries = objFromEntries;
    exports.objGetOwnPropertyDescriptor = objGetOwnPropertyDescriptor;
    exports.objGetOwnPropertyDescriptors = objGetOwnPropertyDescriptors;
    exports.objGetOwnPropertyNames = objGetOwnPropertyNames;
    exports.objGetOwnPropertySymbols = objGetOwnPropertySymbols;
    exports.objGetPrototypeOf = objGetPrototypeOf;
    exports.objHasOwn = objHasOwn;
    exports.objHasOwnProperty = objHasOwnProperty;
    exports.objIs = objIs;
    exports.objIsExtensible = objIsExtensible;
    exports.objIsFrozen = objIsFrozen;
    exports.objIsSealed = objIsSealed;
    exports.objKeys = objKeys;
    exports.objMapValues = objMapValues;
    exports.objMergeIf = objMergeIf;
    exports.objOmit = objOmit;
    exports.objOmitBy = objOmitBy;
    exports.objPick = objPick;
    exports.objPickBy = objPickBy;
    exports.objPreventExtensions = objPreventExtensions;
    exports.objPropertyIsEnumerable = objPropertyIsEnumerable;
    exports.objSeal = objSeal;
    exports.objSetPrototypeOf = objSetPrototypeOf;
    exports.objToString = objToString;
    exports.objValues = objValues;
    exports.perfNow = perfNow;
    exports.plainObjDeepCopyHandler = plainObjDeepCopyHandler;
    exports.polyArrFind = polyArrFind;
    exports.polyArrFindIndex = polyArrFindIndex;
    exports.polyArrFindLast = polyArrFindLast;
    exports.polyArrFindLastIndex = polyArrFindLastIndex;
    exports.polyArrFrom = polyArrFrom;
    exports.polyArrIncludes = polyArrIncludes;
    exports.polyGetKnownSymbol = polyGetKnownSymbol;
    exports.polyIsArray = polyIsArray;
    exports.polyNewSymbol = polyNewSymbol;
    exports.polyObjEntries = polyObjEntries;
    exports.polyObjHasOwn = polyObjHasOwn;
    exports.polyObjIs = polyObjIs;
    exports.polyObjKeys = polyObjKeys;
    exports.polyStrIncludes = polyStrIncludes;
    exports.polyStrSubstr = polyStrSubstr;
    exports.polyStrSymSplit = polyStrSymSplit;
    exports.polyStrTrim = polyStrTrim;
    exports.polyStrTrimEnd = polyStrTrimEnd;
    exports.polyStrTrimStart = polyStrTrimStart;
    exports.polySymbolFor = polySymbolFor;
    exports.polySymbolKeyFor = polySymbolKeyFor;
    exports.polyUtcNow = polyUtcNow;
    exports.readArgs = readArgs;
    exports.safe = safe;
    exports.safeGet = safeGet;
    exports.safeGetDeferred = safeGetDeferred;
    exports.safeGetLazy = safeGetLazy;
    exports.safeGetWritableDeferred = safeGetWritableDeferred;
    exports.safeGetWritableLazy = safeGetWritableLazy;
    exports.scheduleIdleCallback = scheduleIdleCallback;
    exports.scheduleInterval = scheduleInterval;
    exports.scheduleMicrotask = scheduleMicrotask;
    exports.scheduleNextTick = scheduleNextTick;
    exports.scheduleTimeout = scheduleTimeout;
    exports.scheduleTimeoutWith = scheduleTimeoutWith;
    exports.setBypassLazyCache = setBypassLazyCache;
    exports.setDefaultIdleTimeout = setDefaultIdleTimeout;
    exports.setDefaultMaxExecutionTime = setDefaultMaxExecutionTime;
    exports.setGlobalTimeoutOverrides = setGlobalTimeoutOverrides;
    exports.setMicroTaskFallbackOptions = setMicroTaskFallbackOptions;
    exports.setNextTickFallbackOptions = setNextTickFallbackOptions;
    exports.setTimeoutOverrides = setTimeoutOverrides;
    exports.setValueByIter = setValueByIter;
    exports.setValueByKey = setValueByKey;
    exports.strAt = strAt;
    exports.strCamelCase = strCamelCase;
    exports.strCapitalizeWords = strCapitalizeWords;
    exports.strContains = strContains;
    exports.strCount = strCount;
    exports.strEndsWith = strEndsWith;
    exports.strEndsWithAny = strEndsWithAny;
    exports.strIncludes = strIncludes;
    exports.strIndexOf = strIndexOf;
    exports.strIsNullOrEmpty = strIsNullOrEmpty;
    exports.strIsNullOrWhiteSpace = strIsNullOrWhiteSpace;
    exports.strKebabCase = strKebabCase;
    exports.strLastIndexOf = strLastIndexOf;
    exports.strLeft = strLeft;
    exports.strLetterCase = strLetterCase;
    exports.strLower = strLower;
    exports.strMatchAll = strMatchAll;
    exports.strNormalizeNewlines = strNormalizeNewlines;
    exports.strPadEnd = strPadEnd;
    exports.strPadStart = strPadStart;
    exports.strRepeat = strRepeat;
    exports.strReplace = strReplace;
    exports.strReplaceAll = strReplaceAll;
    exports.strRight = strRight;
    exports.strSlice = strSlice;
    exports.strSnakeCase = strSnakeCase;
    exports.strSplit = strSplit;
    exports.strStartsWith = strStartsWith;
    exports.strStartsWithAny = strStartsWithAny;
    exports.strSubstr = strSubstr;
    exports.strSubstring = strSubstring;
    exports.strSymSplit = strSymSplit;
    exports.strTrim = strTrim;
    exports.strTrimEnd = strTrimEnd;
    exports.strTrimLeft = strTrimLeft;
    exports.strTrimRight = strTrimRight;
    exports.strTrimStart = strTrimStart;
    exports.strTruncate = strTruncate;
    exports.strUnwrap = strUnwrap;
    exports.strUpper = strUpper;
    exports.strWrap = strWrap;
    exports.symbolFor = symbolFor;
    exports.symbolKeyFor = symbolKeyFor;
    exports.throwError = throwError;
    exports.throwRangeError = throwRangeError;
    exports.throwTypeError = throwTypeError;
    exports.throwUnsupported = throwUnsupported;
    exports.utcNow = utcNow;

    return exports;

})({});
//# sourceMappingURL=ts-utils.js.map
