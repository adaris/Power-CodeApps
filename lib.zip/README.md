# Dataverse CLI (Preview)

A command-line tool for Microsoft Dataverse that provides authentication management, environment operations, data access, dynamic API discovery/invocation, ERP utilities, and an MCP (Model Context Protocol) server for AI assistant integration.

## Installation

### Global Installation

```bash
npm install -g @microsoft/dataverse
```

### Use with npx (No Installation Required)

```bash
npx @microsoft/dataverse <command> [options]
```

## Quick start

1. Sign in to an environment. Interactive sign-in opens a browser:

   ```bash
   dataverse auth create --environment https://myorg.crm.dynamics.com --name prod
   ```

   No browser available (SSH, container, CI)? Use the device code flow:

   ```bash
   dataverse auth create --environment https://myorg.crm.dynamics.com --deviceCode
   ```

2. Confirm the active profile and environment:

   ```bash
   dataverse auth who
   dataverse org who
   ```

3. Run a first query (`--table` takes the plural EntitySet name):

   ```bash
   dataverse data query --table accounts --select name --top 5
   ```

4. Discover commands and options with `--help` at any level:

   ```bash
   dataverse --help
   dataverse auth --help
   dataverse data query --help
   ```

Profiles are shared with the MCP server and Python SDK, so you sign in once. Switch the active profile with `dataverse auth select`, and add `--json` on supported commands (`org`, `data`, `api`, `erp`, `package`) for scriptable output.

## Prerequisites

Before you can use the Dataverse MCP server, the following setup steps must be completed by your administrators:

### 1. Azure Tenant Admin: Grant Admin Consent

An Azure tenant administrator must grant admin consent for the Dataverse MCP CLI tool application.

**Steps:**
1. Navigate to: `https://login.microsoftonline.com/{your-tenant-id}/adminconsent?client_id=0c412cc3-0dd6-449b-987f-05b053db9457`
   - Replace `{your-tenant-id}` with your actual Azure tenant ID
2. Sign in as an Azure tenant administrator
3. Review and grant the requested permissions

### 2. Dataverse Admin: Enable MCP Server

A Dataverse organization administrator must enable the MCP server feature for your environment.

**Resources:**
- [Enable Dataverse MCP (Production)](https://aka.ms/enableDataverseMcp)
- [Enable Dataverse MCP (Preview)](https://aka.ms/enableDataverseMcpPreview)

### 3. Dataverse Admin: Allow the MCP CLI Tool

A Dataverse organization administrator must add the Dataverse MCP CLI tool to the allowed client applications list.

**Steps:**
1. Follow the instructions at: [Configure MCP Client List](https://aka.ms/configuremcpclientlist)
2. Add the application with App ID: `0c412cc3-0dd6-449b-987f-05b053db9457`
   - This will appear as "Dataverse MCP CLI tool" in the UI

> **Note:** All three prerequisite steps must be completed before you can successfully authenticate and connect to your Dataverse environment.

## Updating

Running a command does not contact the npm registry. To upgrade to the newest published version, run the upgrade explicitly:

```bash
dataverse install latest
```

## Features

- Profile-based authentication compatible with PAC CLI auth profiles
- Dataverse environment commands (`org` / `env`)
- Dataverse data commands for query/get/create/update/upsert/delete/count plus associate/disassociate
- Dynamic `api` commands for Dataverse custom APIs and ERP invocable service endpoints
- ERP batch job management for linked Finance & Operations environments
- MCP server support for Claude Desktop and other MCP clients — Dataverse or Finance & Operations (ERP), auto-detected from the URL
- `--json` output on supported commands for scripting

## Command Reference

| Command | Description |
|---------|-------------|
| `auth create` | Create a new authentication profile |
| `auth select` | Select the active authentication profile |
| `auth list` | List all authentication profiles |
| `auth who` | Show the current authentication profile |
| `auth remove` | Remove an authentication profile |
| `org who` | Show current organization and user info |
| `org list` | List all accessible environments |
| `api list` | List discoverable APIs |
| `api describe` | Describe an API |
| `api invoke` | Invoke an API by name |
| `api request` | Send an authenticated HTTP request |
| `erp batch list` | List Finance & Operations batch jobs |
| `erp batch cancel` | Cancel a Finance & Operations batch job |
| `data query` | Execute an OData or FetchXML query |
| `data get` | Retrieve a single record by ID or alternate key |
| `data create` | Create a new record |
| `data update` | Update an existing record |
| `data upsert` | Create or update a record by alternate key |
| `data delete` | Delete a record |
| `data associate` | Link two records via a relationship |
| `data disassociate` | Remove a relationship between two records |
| `data count` | Count records in a table |
| `data describe` | Describe an entity's schema (Dataverse: attributes + relationships + Custom APIs; ERP: properties + bound actions + navigations) |
| `data upload` | Upload a file to a file column on an existing record |
| `mcp` | Start MCP server for Dataverse or ERP (F&O); target auto-detected from the URL |
| `mcp allow` | Allow an app as MCP client (add `--erp` for the linked F&O instance) |

## Detailed Command Guide

### `install` - Install a Specific Version

Install a specific version of the Dataverse CLI, or update to the latest version.

#### Usage

**Install latest version:**
```bash
dataverse install latest
```

**Install specific version:**
```bash
dataverse install 0.1.0
```

**With npx:**
```bash
npx @microsoft/dataverse install latest
npx @microsoft/dataverse install 0.1.0
```

This command works whether you have a global installation or are using npx. It will automatically detect your installation method and install accordingly.

### `auth` - Authentication Profile Management

Manage authentication profiles for connecting to Dataverse environments.

#### `auth create` - Create a New Profile

> `--environment` is required for interactive, device code, and username/password auth. Service principal (`--applicationId` + `--clientSecret`), managed identity (`--managedIdentity`), and federated flows (`--githubFederated` / `--azureDevOpsFederated`) may omit `--environment` when authenticating against non-BAP endpoints.

```bash
# Interactive authentication (opens browser or system dialog)
dataverse auth create --environment https://myorg.crm.dynamics.com

# Named profile
dataverse auth create --environment https://myorg.crm.dynamics.com --name prod

# Device code flow (for environments without a browser)
dataverse auth create --environment https://myorg.crm.dynamics.com --deviceCode

# Service principal with client secret
dataverse auth create --applicationId <appId> --clientSecret <secret> --tenant <tenantId>

# Custom Entra app client ID (use your own app registration instead of the default)
dataverse auth create --environment https://myorg.crm.dynamics.com --clientid <your-app-guid>
```

Run `dataverse auth create --help` for all options including certificate auth, managed identity, and federated auth.

#### `auth select` - Switch Active Profile

```bash
# Interactive picker (arrow keys, type to filter)
dataverse auth select

# Positional shortcut: index or name
dataverse auth select 1
dataverse auth select prod

# Or via named flags
dataverse auth select --index 1
dataverse auth select --name prod
```

#### `auth list` - List All Profiles

```bash
dataverse auth list
dataverse auth list --json
```

#### `auth who` - Show Current Profile

```bash
dataverse auth who
dataverse auth who --json
```

#### `auth remove` - Remove a Profile

```bash
# Remove by 1-based index (from 'auth list')
dataverse auth remove --index 1

# Remove by name
dataverse auth remove --name prod

# Remove all profiles
dataverse auth remove --all
```

### `org` (or `env`) - Environment Operations

Query Dataverse environments using the current authentication profile.

#### `org who` - Current Organization Info

```bash
dataverse org who
dataverse org who --environment https://myorg.crm.dynamics.com
dataverse org who --json
```

#### `org list` - List Accessible Environments

```bash
dataverse org list
dataverse org list --filter contoso
dataverse org list --json
```

### `api` - Dataverse and ERP API Commands

Discover, describe, invoke, and make raw authenticated requests to Dataverse custom APIs and ERP invocable service endpoints.

#### `api list` - List Discoverable APIs

```bash
dataverse api list
dataverse api list invoice --target dataverse
dataverse api list --target erp GetUserSessionInfo
dataverse api list --target erp --service-group UserSessionService --service AifUserSessionService
```

Results show the API identity, friendly name, kind, and description when available.

#### `api describe` - Show API Metadata

```bash
dataverse api describe sample_CustomAPIExample
dataverse api describe msdyn_DoesKBExist
dataverse api describe GetUserSessionInfo --target erp --service-group UserSessionService --service AifUserSessionService
```

For Dataverse custom APIs, the output includes request parameter and response property descriptions when the metadata provides them.

#### `api invoke` - Invoke an API by Name

```bash
# Dataverse function
dataverse api invoke CCaaS_GetPresence ApiVersion=1.0

# Dataverse action with spaces in a parameter value
dataverse api invoke AISummarize "Text=The customer reported intermittent login failures..."

# Preserve raw JSON output
dataverse api invoke AISummarize "Text=The customer reported intermittent login failures..." --json

# ERP custom service
dataverse api invoke GetUserSessionInfo --target erp --service-group UserSessionService --service AifUserSessionService
```

Use `name=value` syntax for parameters. If a value contains spaces, quote the whole token. Some Dataverse APIs accept a string parameter whose contents are themselves JSON; in that case, pass JSON text as the value using your shell's normal quoting/escaping rules.

By default, `api invoke` renders JSON responses in a friendly text format that keeps output property names. Use `--json` to preserve the raw JSON payload.

#### `api request` - Send a Raw Authenticated Request

```bash
dataverse api request --target dataverse --path /api/data/v9.2/sample_CustomAPIExample --body "{\"Input\":\"value\"}"
dataverse api request --target erp --path /api/services/UserSessionService/AifUserSessionService/GetUserSessionInfo --body "{}"
```

### `mcp` - MCP Server for Dataverse

Starts an MCP (Model Context Protocol) server that connects to your Dataverse environment, enabling AI assistants like Claude to interact with your Dataverse data.

#### Usage

```bash
dataverse mcp <orgUrl> [options]
```

**Arguments:**
- `<orgUrl>` - Your Dataverse organization URL (e.g., `https://myorg.crm.dynamics.com`)

**Options:**
- `--validate` - Validate MCP endpoints and authentication setup without starting the server
- `--log-level <level>` - Set logging level: Trace, Debug, Information, Warning, Error, Critical (default: Warning)
- `--log-file` - Enable logging to a file in the temp directory
- `--preview` - Use preview MCP endpoint (`api/mcp_preview` instead of `api/mcp`)

#### Examples

**Validate setup (recommended first step):**
```bash
dataverse mcp https://myorg.crm.dynamics.com --validate
```

This will test both the GA and Preview endpoints and verify that:
- Authentication is working correctly
- The MCP server is enabled
- The MCP CLI tool is in the allowed applications list

If validation fails, the output will provide specific guidance on which prerequisite steps need to be completed.

**Basic usage with stdio transport:**
```bash
dataverse mcp https://myorg.crm.dynamics.com
```

**With npx:**
```bash
npx @microsoft/dataverse mcp https://myorg.crm.dynamics.com
```

**Use preview endpoint:**
```bash
dataverse mcp https://myorg.crm.dynamics.com --preview
```

**Enable debug logging:**
```bash
dataverse mcp https://myorg.crm.dynamics.com --log-level Debug
```

**Enable file logging (useful for troubleshooting):**
```bash
dataverse mcp https://myorg.crm.dynamics.com --log-file
```

**Finance & Operations (ERP):** When the URL is an F&O host (e.g. `https://myorg.operations.dynamics.com`), `mcp` auto-routes to the ERP MCP server (mounted at `/mcp`, GA only — `--preview` is not supported). Validation and logging options work the same.

```bash
dataverse mcp https://myorg.operations.dynamics.com --validate
dataverse mcp https://myorg.operations.dynamics.com
```

### `mcp allow` - Allow an MCP Client Application

Ensures an Azure AD application is in the Dataverse MCP allowed clients list for the current profile's environment. This is an alternative to the manual admin step in Prerequisites.

```bash
dataverse mcp allow 0c412cc3-0dd6-449b-987f-05b053db9457
```

> **Note:** Requires the authenticated user to have Dataverse admin permissions on the target environment.

**Finance & Operations (ERP):** Add `--erp` to allow the application on the linked F&O instance instead of Dataverse.

```bash
dataverse mcp allow 0c412cc3-0dd6-449b-987f-05b053db9457 --erp
```

> **Note:** F&O caches the allow-list in the AOS, so a newly allowed app ID can take up to ~5 minutes to take effect.

### `erp batch` - Finance & Operations Batch Jobs

Manage batch jobs on the Finance & Operations instance linked to your Dataverse environment. Requires an auth profile connected to a Dataverse environment with a linked F&O instance.

#### `erp batch list` - List Batch Jobs

```bash
# List all batch jobs
dataverse erp batch list

# Filter by status
dataverse erp batch list --status Waiting
dataverse erp batch list --status executing --top 20
```

**Options:**

| Option | Description |
|--------|-------------|
| `--status <value>` | Filter by status: `Waiting`, `Executing`, `Ended`, `Error`, `Cancelling`, `Withhold` |
| `--top <n>` | Return at most `n` jobs (positive integer) |

#### `erp batch cancel` - Cancel a Batch Job

```bash
dataverse erp batch cancel <recid>
```

Cancels the batch job with the given RecId (use `erp batch list` to find IDs).

### `data` - Dataverse Data Operations

Use the `data` namespace for Dataverse table/entity operations:

```bash
dataverse data query --table accounts --select name,revenue --top 5
dataverse data get --table accounts --id <guid>
dataverse data create --table accounts --data '{"name":"Contoso"}'
dataverse data update --table accounts --id <guid> --data '{"name":"Updated Contoso"}'
dataverse data upsert --table accounts --key "accountnumber='ACC-100'" --data '{"name":"Contoso"}'
dataverse data delete --table accounts --id <guid>
dataverse data count --table accounts
dataverse data describe --target dataverse --table account
dataverse data describe --target erp --table BatchJobs
dataverse data upload --table account --id <guid> --column new_document --file report.pdf
```

Run `dataverse data <subcommand> --help` for full option details on query, get, create, update, upsert, delete, associate, disassociate, count, describe, and upload.

`data describe` works for both targets. ERP uses F&O's `/Metadata/PublicEntities` endpoint — one call returns properties, bound actions, and navigations together. Dataverse uses `EntityDefinitions(LogicalName='X')` with `$expand` driven by `--include` (`entity`, `properties`, `relations`, `actions`, `all`); when `--include actions` is set, a second call to `customapis` enumerates bound Custom APIs. Built-in Dataverse actions like `Assign` / `SetState` are not enumerated. Use `--json` for raw JSON output.

#### `data upload` - Upload a file to a file column on an existing record

Upload a local file into a Dataverse file (file/blob) column on an existing record. The command automatically selects single-request vs chunked upload based on file size unless `--mode` is specified.

Usage:
```
dataverse data upload [options]
```

Options:
```
  --table, -t <name>          Table schema/logical name, e.g. 'account' (required; entity set is resolved from metadata)
  --id, -i <guid>             Record GUID (required)
  --column, -c <name>         File column attribute name (required)
  --file, -f <path>           Path to the local file (required)
  --mode, -m <value>          Upload strategy: auto (default), small, or chunk
  --mime-type <type>          Explicit MIME type (default: inferred from file extension)
  --overwrite                 Overwrite existing file (default: fail if column not empty)
  --environment, -env <url>   Override environment URL
  --json                      Output raw JSON
```

Notes:

- In auto mode, files under 128 MB are uploaded in a single request and larger files use a chunked upload protocol.
- Chunked uploads use an initial session-init PATCH followed by successive PATCH requests with Content-Range headers.
- When `--mime-type` is omitted the MIME type is inferred from the file extension; unknown extensions default to `application/octet-stream`.
- With `--json` the command prints a JSON object with keys: uploaded, table, entitySet, id, column, file, size, mode, mimeType.

```bash
  dataverse data upload --table account --id <guid> --column new_document --file report.pdf
  dataverse data upload -t account -i <guid> -c new_document -f photo.jpg --overwrite
  dataverse data upload -t account -i <guid> -c new_document -f big.bin --mode chunk
```


## Using with Claude Desktop

To use the Dataverse MCP server with Claude Desktop, add it to your MCP configuration.

### Quick Setup

```bash
claude mcp add dataverse -t stdio -- npx -y @microsoft/dataverse mcp https://yourorg.crm.dynamics.com
```

### Manual Configuration

Edit your Claude Desktop MCP configuration file:

**Location:**
- Windows: `%APPDATA%\Claude\claude_desktop_config.json`
- macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`
- Linux: `~/.config/Claude/claude_desktop_config.json`

**Configuration:**
```json
{
  "mcpServers": {
    "dataverse": {
      "command": "npx",
      "args": ["-y", "@microsoft/dataverse", "mcp", "https://yourorg.crm.dynamics.com"],
      "type": "stdio"
    }
  }
}
```

**With logging enabled for troubleshooting:**
```json
{
  "mcpServers": {
    "dataverse": {
      "command": "npx",
      "args": [
        "-y",
        "@microsoft/dataverse",
        "mcp",
        "https://yourorg.crm.dynamics.com",
        "--log-level", "Debug",
        "--log-file"
      ],
      "type": "stdio"
    }
  }
}
```

**Using the preview endpoint:**
```json
{
  "mcpServers": {
    "dataverse": {
      "command": "npx",
      "args": [
        "-y",
        "@microsoft/dataverse",
        "mcp",
        "https://yourorg.crm.dynamics.com",
        "--preview"
      ],
      "type": "stdio"
    }
  }
}
```

## Authentication

The CLI uses Microsoft Authentication Library (MSAL) for authentication. Profiles and tokens are cached locally.

**First-time setup:**
```bash
dataverse auth create --environment https://myorg.crm.dynamics.com
```

This opens a browser or system authentication dialog. After signing in, the profile is saved and subsequent commands (including `mcp`) use cached tokens without re-prompting.

**Multiple environments:**
```bash
dataverse auth create --environment https://dev.crm.dynamics.com --name dev
dataverse auth create --environment https://prod.crm.dynamics.com --name prod
dataverse auth select --name dev
```

**Service principal (CI/CD):**
```bash
dataverse auth create --applicationId <appId> --clientSecret <secret> --tenant <tenantId> --environment https://myorg.crm.dynamics.com
```

## Supported Platforms

- **Windows** (x64, ARM64)
- **macOS** (x64, ARM64 / Apple Silicon)
- **Linux** (x64, ARM64)

## Troubleshooting

### Enable Logging

If you encounter issues, enable file logging to capture detailed diagnostic information:

```bash
dataverse mcp https://yourorg.crm.dynamics.com --log-level Debug --log-file
```

Log files are written to your system's temporary directory. The exact location will be displayed when logging starts.

### Common Issues

**"No compatible binary found for your platform"**
- Supported: Windows (x64, ARM64), macOS (x64, ARM64), Linux (x64, ARM64)
- For other platforms, please build from source with `dotnet publish`

**Authentication failures**
- Ensure you have access to the Dataverse environment
- Check that your organization URL is correct
- Try clearing your token cache and re-authenticating

**MCP connection issues in Claude Desktop**
- Verify the configuration JSON syntax is correct
- Check that the organization URL is accessible
- Enable `--log-file` to capture detailed error messages
- Restart Claude Desktop after configuration changes

## Getting Help

```bash
dataverse --help
dataverse auth --help
dataverse auth create --help
dataverse org --help
dataverse mcp --help
dataverse mcp allow --help
dataverse erp batch --help
```

## Supported MCP Operations

The MCP server supports the following operations:

- **Tools**: List and call Dataverse tools
- **Prompts**: List and retrieve prompts
- **Resources**: List and read Dataverse resources

## License

MIT

## Links

- [GitHub Repository](https://dev.azure.com/dynamicscrm/OneCRM/_git/DataverseCLI)
- [Model Context Protocol](https://modelcontextprotocol.io/)
- [Claude Desktop](https://claude.ai/download)
